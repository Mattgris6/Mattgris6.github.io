import os
from qgis.core import (
    QgsProject,
    QgsCoordinateReferenceSystem,
    QgsVectorLayer,
    QgsField,
    QgsFeature,
    QgsWkbTypes,
)
from qgis.utils import iface
from qgis.PyQt.QtWidgets import QProgressBar, QMessageBox
from qgis.PyQt.QtCore import QVariant
import processing
from math import ceil
import datetime
from .dictionnaire_lot1_NG import remplir_dictionnaire_1_NG


def lancement_123(enregistrer, lot, transport, openpyxl):
    # On affiche un message
    progressMessageBar = iface.messageBar().createMessage(
        "Patience! Le chiffrage est en cours de préparation..."
    )
    progress = QProgressBar()
    progress.setMaximum(100)
    progressMessageBar.layout().addWidget(progress)
    iface.messageBar().pushWidget(progressMessageBar)
    progress.setValue(0)
    # On va chercher les couches
    t_adresse = ""
    t_site, t_sro, t_nro = None, None, None
    layers = QgsProject.instance().mapLayers().values()
    for layer in layers:
        if lot == "Non Gr@ce - Lot 1":
            try:
                print(layer.name(), layer.geometryType(), QgsWkbTypes.PointGeometry)

            except:
                pass
            if layer.name() == "Prises" or layer.name() == "t_adresse":
                t_adresse = layer
            elif layer.name() == "Cables" or layer.name() == "t_cable":
                t_cable = layer
            elif "oite" in layer.name() or layer.name() == "t_ebp":
                t_ebp = layer
            elif layer.name() == "Point_tech" or layer.name() == "t_ptech":
                t_ptech = layer
            elif layer.name() == "Infra" or layer.name() == "t_cheminement":
                t_cheminement = layer
            elif layer.name() == "ZASRO" or layer.name() == "t_zsro":
                t_zsro = layer
            elif layer.name() == "ZAPBO" or layer.name() == "t_zpbo":
                t_zpbo = layer
            elif layer.name() == "ZPEC" or layer.name() == "t_zpec":
                t_zpec = layer
            elif "SITE" in layer.name() or layer.name() == "t_sitetech":
                t_site = layer
            elif (
                "SRO" in layer.name()
                and layer.geometryType() == QgsWkbTypes.PointGeometry
            ):
                t_sro = layer
            elif (
                "NRO" in layer.name()
                and layer.geometryType() == QgsWkbTypes.PointGeometry
            ):
                t_nro = layer
        else:
            if layer.name() == "t_adresse":
                t_adresse = layer
    if not transport:
        if not verif_table(t_adresse, "t_adresse"):
            QMessageBox.warning(
                None,
                "Erreur",
                f"Impossible de trouver la couche t_adresse. Veuillez l'ajouter au projet.",
            )
            return False
    if t_sro and t_nro and not t_site:
        t_site = create_union_layer(t_sro, t_nro)

    if not lot == "Non Gr@ce - Lot 1":
        myfilepath = t_adresse.dataProvider().dataSourceUri()
        repertoire_dlg = os.path.split(myfilepath)[0]
        # On va chercher les fichiers dans le DLG
        # Les csv
        uri = f"file:///{repertoire_dlg}/t_cable_patch201.csv?delimiter=%s" % (";")
        t_cable_patch = QgsVectorLayer(uri, "t_cable_patch201", "delimitedtext")
        ajouter(t_cable_patch)
        #
        uri = f"file:///{repertoire_dlg}/t_zpbo_patch201.csv?delimiter=%s" % (";")
        t_zpbo_patch201 = QgsVectorLayer(uri, "t_zpbo_patch201", "delimitedtext")
        ajouter(t_zpbo_patch201)
        #
        uri = f"file:///{repertoire_dlg}/t_cable.csv?delimiter=%s" % (";")
        t_cable = QgsVectorLayer(uri, "t_cable", "delimitedtext")
        ajouter(t_cable)
        #
        uri = f"file:///{repertoire_dlg}/t_ptech.csv?delimiter=%s" % (";")
        t_ptech = QgsVectorLayer(uri, "t_ptech", "delimitedtext")
        ajouter(t_ptech)
        #
        uri = f"file:///{repertoire_dlg}/t_ebp.csv?delimiter=%s" % (";")
        t_ebp = QgsVectorLayer(uri, "t_ebp", "delimitedtext")
        ajouter(t_ebp)
        #
        uri = f"file:///{repertoire_dlg}/t_sitetech.csv?delimiter=%s" % (";")
        t_sitetech = QgsVectorLayer(uri, "t_sitetech", "delimitedtext")
        ajouter(t_sitetech)
        #
        uri = f"file:///{repertoire_dlg}/t_reference.csv?delimiter=%s" % (";")
        t_reference = QgsVectorLayer(uri, "t_reference", "delimitedtext")
        ajouter(t_reference)
        #
        uri = f"file:///{repertoire_dlg}/t_cab_cond.csv?delimiter=%s" % (";")
        t_cab_cond = QgsVectorLayer(uri, "t_cab_cond", "delimitedtext")
        ajouter(t_cab_cond)
        #
        uri = f"file:///{repertoire_dlg}/t_cond_chem.csv?delimiter=%s" % (";")
        t_cond_chem = QgsVectorLayer(uri, "t_cond_chem", "delimitedtext")
        ajouter(t_cond_chem)
        #
        uri = f"file:///{repertoire_dlg}/t_conduite.csv?delimiter=%s" % (";")
        t_conduite = QgsVectorLayer(uri, "t_conduite", "delimitedtext")
        ajouter(t_conduite)
        #
        uri = f"file:///{repertoire_dlg}/t_suf.csv?delimiter=%s" % (";")
        t_suf = QgsVectorLayer(uri, "t_suf", "delimitedtext")
        ajouter(t_suf)
        #
        uri = f"file:///{repertoire_dlg}/t_cassette.csv?delimiter=%s" % (";")
        t_cassette = QgsVectorLayer(uri, "t_cassette", "delimitedtext")
        ajouter(t_cassette)
        #
        uri = f"file:///{repertoire_dlg}/t_position.csv?delimiter=%s" % (";")
        t_position = QgsVectorLayer(uri, "t_position", "delimitedtext")
        ajouter(t_position)
        # Les shp
        t_noeud = QgsVectorLayer(repertoire_dlg + r"/t_noeud.shp", "t_noeud", "ogr")
        ajouter(t_noeud)
        t_zpbo = QgsVectorLayer(repertoire_dlg + r"/t_zpbo.shp", "t_zpbo", "ogr")
        ajouter(t_zpbo)
        t_adresse = QgsVectorLayer(
            repertoire_dlg + r"/t_adresse.shp", "t_adresse", "ogr"
        )
        ajouter(t_adresse)
        t_cheminement = QgsVectorLayer(
            repertoire_dlg + r"/t_cheminement.shp", "t_cheminement", "ogr"
        )
        ajouter(t_cheminement)
    # On va chercher le fichier BDC indiqué par l'utilisateur
    # fichierBDC_path = dlg.fichier_bdc.filePath()
    if lot in ["1 - 2", "Non Gr@ce - Lot 1"]:
        fichierBDC_path = (
            os.path.abspath(os.path.dirname(__file__)) + r"/BPU_CD39_LOT_1.xlsx"
        )
    elif lot == "3":
        fichierBDC_path = (
            os.path.abspath(os.path.dirname(__file__)) + r"/BPU_CD39_LOT_3.xlsx"
        )
    fichierBDC = openpyxl.load_workbook(fichierBDC_path)
    # On l'enregistre dans le répertoire choisi par l'utilisateur
    chemin_sauvegarde = enregistrer + "\BDC_FMP.xlsx"
    try:
        fichierBDC.save(chemin_sauvegarde)
    except:
        QMessageBox.information(
            None,
            "Erreur",
            "Erreur lors de l'enregistrement. Un fichier du même nom est déjà ouvert? Veuillez le fermer avant de lancer l'outil.",
        )
        return False
    if not lot == "Non Gr@ce - Lot 1":
        # La table des prises
        # print('requete prise avant', datetime.datetime.now())
        if t_suf.featureCount() == 0:
            requete = "select t_zpbo.zp_code, zp_bp_code as bp_code, sum(ad_nbprhab + ad_nbprpro) as nb_prise, bp_statut, bp_avct, bp_typelog from t_zpbo, t_zpbo_patch201, t_adresse, t_ebp where t_zpbo.zp_code = t_zpbo_patch201.zp_code and t_zpbo_patch201.zp_bp_code=t_ebp.bp_code and st_within(t_adresse.geometry, t_zpbo.geometry) group by t_zpbo.zp_code, zp_bp_code"
        else:
            requete = "select t_zpbo.zp_code, zp_bp_code as bp_code, count(sf_code) as nb_prise, bp_statut, bp_avct, bp_typelog from t_zpbo, t_zpbo_patch201, t_ebp left join t_suf on sf_zp_code=t_zpbo.zp_code where t_zpbo.zp_code = t_zpbo_patch201.zp_code and t_zpbo_patch201.zp_bp_code=t_ebp.bp_code group by t_zpbo.zp_code, zp_bp_code"
        alg_params = {
            "INPUT_DATASOURCES": [],
            "INPUT_GEOMETRY_CRS": QgsCoordinateReferenceSystem("EPSG:2154"),
            "INPUT_GEOMETRY_FIELD": "",
            "INPUT_GEOMETRY_TYPE": 1,
            "INPUT_QUERY": requete,
            "INPUT_UID_FIELD": "",
            "OUTPUT": "TEMPORARY_OUTPUT",
        }
        t_nbprise = processing.run("qgis:executesql", alg_params)["OUTPUT"]
    # print('requete prise apres', datetime.datetime.now())
    # On lance les dictionnaires
    if lot in ["1 - 2"]:
        dict_rec_article = remplir_dictionnaire12(
            transport,
            t_cable,
            t_ptech,
            t_ebp,
            t_nbprise,
            t_cable_patch,
            t_sitetech,
            t_cheminement,
            "REC",
        )
        dict_exe_article = remplir_dictionnaire12(
            transport,
            t_cable,
            t_ptech,
            t_ebp,
            t_nbprise,
            t_cable_patch,
            t_sitetech,
            t_cheminement,
            "EXE",
        )
    elif lot == "3":
        dict_rec_article = remplir_dictionnaire3(
            transport,
            t_cable,
            t_ptech,
            t_ebp,
            t_nbprise,
            t_cable_patch,
            t_sitetech,
            t_cheminement,
            "REC",
        )
        dict_exe_article = remplir_dictionnaire3(
            transport,
            t_cable,
            t_ptech,
            t_ebp,
            t_nbprise,
            t_cable_patch,
            t_sitetech,
            t_cheminement,
            "EXE",
        )
    elif lot == "Non Gr@ce - Lot 1":
        dict_rec_article = remplir_dictionnaire_1_NG(
            transport, t_cable, t_ptech, t_ebp, t_cheminement, t_adresse, t_site, "REC"
        )
        dict_exe_article = remplir_dictionnaire_1_NG(
            transport, t_cable, t_ptech, t_ebp, t_cheminement, t_adresse, t_site, "EXE"
        )
        if t_sro and t_nro:
            QgsProject.instance().removeMapLayer(t_site)
    # On remplit l'excel
    colonne = 7
    ligne_depart = 7
    feuilleBDC = fichierBDC.worksheets[0]
    nrow = feuilleBDC.max_row
    print("nrow", nrow)
    for ligne in range(ligne_depart, nrow + 1):
        print("article", feuilleBDC.cell(row=ligne, column=1).value)
        # feuilleBDC.Cells(ligne, colonne).NumberFormat = "Standard"
        # feuilleBDC.Cells(ligne, colonne + 1).NumberFormat = "Standard"
        # feuilleBDC.Cells(ligne, colonne + 2).NumberFormat = "Standard"
        # feuilleBDC.Cells(ligne, colonne + 2).Value = dict_article.get(feuilleBDC.Cells(ligne, 1).Value)
        feuilleBDC.cell(
            row=ligne,
            column=colonne,
            value=dict_rec_article.get(feuilleBDC.cell(row=ligne, column=1).value),
        )
        feuilleBDC.cell(
            row=ligne,
            column=colonne + 1,
            value=dict_exe_article.get(feuilleBDC.cell(row=ligne, column=1).value),
        )
        # feuilleBDC.Cells(ligne, colonne).Borders.LineStyle = 1
        # feuilleBDC.Cells(ligne, colonne + 1).Borders.LineStyle = 1
        # feuilleBDC.Cells(ligne, colonne + 2).Borders.LineStyle = 1

    fichierBDC.save(chemin_sauvegarde)
    iface.messageBar().clearWidgets()
    iface.messageBar().pushMessage(
        "Bravo!", "L'excel de chiffrage est prêt", level=3, duration=180
    )


def verif_table(t_table, t_name):
    if t_table == "":
        return False
    else:
        return True


def remplir_dictionnaire12(
    transport,
    t_cable,
    t_ptech,
    t_ebp,
    t_nbprise,
    t_cable_patch,
    t_sitetech,
    t_cheminement,
    statut,
):
    dict_article = {}
    # Installation de chantier
    # dict_article['AC - 1.1'] = 1
    # Fourniture Poteaux créés en bois
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and pt_typephy = 'A' and regexp_match(pt_codeext ,'A39\\\\d{{4}}') and (pt_nature is null or pt_nature = 'PBOI') and (pt_a_haut < 10 or pt_a_haut is null)"
    )
    dict_article["AC - 7.5.1.3"] = t_ptech.selectedFeatureCount()
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and pt_typephy = 'A' and regexp_match(pt_codeext ,'A39\\\\d{{4}}') and (pt_nature is null or pt_nature = 'PBOI') and (pt_a_haut >= 10)"
    )
    dict_article["AC - 7.5.1.4"] = t_ptech.selectedFeatureCount()
    # Fourniture Poteaux créés en metal
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and pt_typephy = 'A' and regexp_match(pt_codeext ,'A39\\\\d{{4}}') and (pt_nature = 'PMET' or pt_nature = 'PIND') and (pt_a_haut < 10 or pt_a_haut is null)"
    )
    dict_article["AC - 7.5.4.1"] = t_ptech.selectedFeatureCount()
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and pt_typephy = 'A' and regexp_match(pt_codeext ,'A39\\\\d{{4}}') and (pt_nature = 'PMET' or pt_nature = 'PIND') and (pt_a_haut >= 10)"
    )
    dict_article["AC - 7.5.4.2"] = t_ptech.selectedFeatureCount()
    # Pose Poteaux créés en bois
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and pt_typephy = 'A' and regexp_match(pt_codeext ,'A39\\\\d{{4}}') and (pt_nature is null or pt_nature = 'PBOI')"
    )
    dict_article["AC - 7.5.6.1"] = t_ptech.selectedFeatureCount()
    # Pose Poteaux créés en metal
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and pt_typephy = 'A' and regexp_match(pt_codeext ,'A39\\\\d{{4}}') and (pt_nature = 'PMET' or pt_nature = 'PIND')"
    )
    dict_article["AC - 7.5.6.2"] = t_ptech.selectedFeatureCount()
    # Armement poteaux
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and pt_typephy = 'A' and pt_prop in ('OR210000000001', 'OR390000000001', 'OR710000000571', 'OR000000000001', 'OR215000000150', 'OR000000000005')"
    )
    dict_article["AC - 7.5.14.1"] = t_ptech.selectedFeatureCount()
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and pt_typephy = 'A' and pt_prop in ('OR000000000002')"
    )
    dict_article["AC - 7.5.14.3"] = t_ptech.selectedFeatureCount()
    # Calcul des longueurs de cable par capa et par support
    longueur_reelle = calcul_longueur(statut, t_cable, t_ptech)
    # Cable conduite modulo 6:
    dict_article["AC - 2.1.1"] = longueur_reelle["SOUTERRAIN"][6][6]
    dict_article["AC - 2.1.2"] = longueur_reelle["SOUTERRAIN"][12][6]
    dict_article["AC - 2.1.3"] = longueur_reelle["SOUTERRAIN"][24][6]
    dict_article["AC - 2.1.4"] = longueur_reelle["SOUTERRAIN"][24][12]
    dict_article["AC - 2.1.5"] = longueur_reelle["SOUTERRAIN"][36][6]
    dict_article["AC - 2.1.6"] = longueur_reelle["SOUTERRAIN"][36][12]
    dict_article["AC - 2.1.7"] = longueur_reelle["SOUTERRAIN"][48][6]
    dict_article["AC - 2.1.8"] = longueur_reelle["SOUTERRAIN"][48][12]
    dict_article["AC - 2.1.9"] = longueur_reelle["SOUTERRAIN"][72][6]
    dict_article["AC - 2.1.10"] = longueur_reelle["SOUTERRAIN"][72][12]
    dict_article["AC - 2.1.15"] = longueur_reelle["SOUTERRAIN"][144][6]
    dict_article["AC - 2.1.16"] = longueur_reelle["SOUTERRAIN"][144][12]
    dict_article["AC - 2.1.17"] = longueur_reelle["SOUTERRAIN"][288][12]
    dict_article["AC - 2.1.18"] = longueur_reelle["SOUTERRAIN"][432][12]
    dict_article["AC - 2.1.19"] = longueur_reelle["SOUTERRAIN"][576][12]
    dict_article["AC - 2.1.20"] = longueur_reelle["SOUTERRAIN"][720][12]
    # CABL300:
    dict_article["AC - 2.2.1"] = longueur_reelle["AERIEN"][6][6]
    dict_article["AC - 2.2.2"] = longueur_reelle["AERIEN"][12][6]
    dict_article["AC - 2.2.3"] = longueur_reelle["AERIEN"][24][6]
    dict_article["AC - 2.2.4"] = longueur_reelle["AERIEN"][24][12]
    dict_article["AC - 2.2.5"] = longueur_reelle["AERIEN"][36][6]
    dict_article["AC - 2.2.6"] = longueur_reelle["AERIEN"][36][12]
    dict_article["AC - 2.2.7"] = longueur_reelle["AERIEN"][48][6]
    dict_article["AC - 2.2.8"] = longueur_reelle["AERIEN"][48][12]
    dict_article["AC - 2.2.9"] = (
        longueur_reelle["AERIEN"][72][6] + longueur_reelle["FACADE"][72][6]
    )
    dict_article["AC - 2.2.10"] = (
        longueur_reelle["AERIEN"][72][12] + longueur_reelle["FACADE"][72][12]
    )
    dict_article["AC - 2.2.15"] = (
        longueur_reelle["AERIEN"][144][6] + longueur_reelle["FACADE"][144][6]
    )
    dict_article["AC - 2.2.16"] = (
        longueur_reelle["AERIEN"][144][12] + longueur_reelle["FACADE"][144][12]
    )

    dict_article["AC - 2.5.1"] = longueur_reelle["IMMEUBLE"][6][6]
    dict_article["AC - 2.5.2"] = longueur_reelle["IMMEUBLE"][12][6]
    dict_article["AC - 2.5.3"] = longueur_reelle["IMMEUBLE"][24][6]
    dict_article["AC - 2.5.4"] = longueur_reelle["IMMEUBLE"][24][12]
    dict_article["AC - 2.5.5"] = longueur_reelle["IMMEUBLE"][36][6]
    dict_article["AC - 2.5.6"] = longueur_reelle["IMMEUBLE"][36][12]
    dict_article["AC - 2.5.7"] = longueur_reelle["IMMEUBLE"][48][6]
    dict_article["AC - 2.5.8"] = longueur_reelle["IMMEUBLE"][48][12]
    dict_article["AC - 2.5.9"] = longueur_reelle["IMMEUBLE"][72][6]
    dict_article["AC - 2.5.10"] = longueur_reelle["IMMEUBLE"][72][12]
    dict_article["AC - 2.5.15"] = longueur_reelle["IMMEUBLE"][144][6]
    dict_article["AC - 2.5.16"] = longueur_reelle["IMMEUBLE"][144][12]

    dict_article["AC - 2.7.1"] = longueur_reelle["FACADE"][6][6]
    dict_article["AC - 2.7.2"] = longueur_reelle["FACADE"][12][6]
    dict_article["AC - 2.7.3"] = longueur_reelle["FACADE"][24][6]
    dict_article["AC - 2.7.4"] = longueur_reelle["FACADE"][24][12]
    dict_article["AC - 2.7.5"] = longueur_reelle["FACADE"][36][6]
    dict_article["AC - 2.7.6"] = longueur_reelle["FACADE"][36][12]
    dict_article["AC - 2.7.7"] = longueur_reelle["FACADE"][48][6]
    dict_article["AC - 2.7.8"] = longueur_reelle["FACADE"][48][12]

    # Comptage des BPE
    # BPE en chambre
    dict_article["AC - 3.1.1"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 6, "CHAMBRE", f"('{statut}')"
    )
    dict_article["AC - 3.1.2"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 12, "CHAMBRE", f"('{statut}')"
    )
    dict_article["AC - 3.1.3"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 24, "CHAMBRE", f"('{statut}')"
    )
    dict_article["AC - 3.1.4"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 36, "CHAMBRE", f"('{statut}')"
    )
    dict_article["AC - 3.1.5"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 48, "CHAMBRE", f"('{statut}')"
    )
    dict_article["AC - 3.1.6"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 72, "CHAMBRE", f"('{statut}')"
    )
    dict_article["AC - 3.1.7"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 96, "CHAMBRE", f"('{statut}')"
    )
    dict_article["AC - 3.1.8"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 108, "CHAMBRE", f"('{statut}')"
    )
    dict_article["AC - 3.1.9"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 144, "CHAMBRE", f"('{statut}')"
    )
    dict_article["AC - 3.1.10"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 288, "CHAMBRE", f"('{statut}')"
    )
    dict_article["AC - 3.1.11"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 432, "CHAMBRE", f"('{statut}')"
    )
    dict_article["AC - 3.1.12"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 576, "CHAMBRE", f"('{statut}')"
    )
    dict_article["AC - 3.1.13"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 720, "CHAMBRE", f"('{statut}')"
    )
    # BPE sur facade
    dict_article["AC - 3.2.1"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 6, "FACADE", f"('{statut}')"
    )
    dict_article["AC - 3.2.2"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 12, "FACADE", f"('{statut}')"
    )
    dict_article["AC - 3.2.3"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 24, "FACADE", f"('{statut}')"
    )
    dict_article["AC - 3.2.4"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 36, "FACADE", f"('{statut}')"
    )
    dict_article["AC - 3.2.5"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 48, "FACADE", f"('{statut}')"
    )
    dict_article["AC - 3.2.6"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 72, "FACADE", f"('{statut}')"
    )
    dict_article["AC - 3.2.7"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 96, "FACADE", f"('{statut}')"
    )
    dict_article["AC - 3.2.8"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 108, "FACADE", f"('{statut}')"
    )
    dict_article["AC - 3.2.9"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 144, "FACADE", f"('{statut}')"
    )
    # Boites sur poteau
    dict_article["AC - 3.3.1"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 6, "POTEAU", f"('{statut}')"
    )
    dict_article["AC - 3.3.2"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 12, "POTEAU", f"('{statut}')"
    )
    dict_article["AC - 3.3.3"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 24, "POTEAU", f"('{statut}')"
    )
    dict_article["AC - 3.3.4"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 36, "POTEAU", f"('{statut}')"
    )
    dict_article["AC - 3.3.5"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 48, "POTEAU", f"('{statut}')"
    )
    dict_article["AC - 3.3.6"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 72, "POTEAU", f"('{statut}')"
    )
    dict_article["AC - 3.3.7"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 96, "POTEAU", f"('{statut}')"
    )
    dict_article["AC - 3.3.8"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 108, "POTEAU", f"('{statut}')"
    )
    dict_article["AC - 3.3.9"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 144, "POTEAU", f"('{statut}')"
    )
    dict_article["AC - 3.3.10"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 288, "POTEAU", f"('{statut}')"
    )
    # BPE sur IMMEUBLE
    dict_article["AC - 3.4.1"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 6, "IMMEUBLE", f"('{statut}')"
    )
    dict_article["AC - 3.4.2"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 12, "IMMEUBLE", f"('{statut}')"
    )
    dict_article["AC - 3.4.3"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 24, "IMMEUBLE", f"('{statut}')"
    )
    dict_article["AC - 3.4.4"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 36, "IMMEUBLE", f"('{statut}')"
    )
    dict_article["AC - 3.4.5"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 48, "IMMEUBLE", f"('{statut}')"
    )
    dict_article["AC - 3.4.6"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 72, "IMMEUBLE", f"('{statut}')"
    )
    dict_article["AC - 3.4.7"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 96, "IMMEUBLE", f"('{statut}')"
    )
    dict_article["AC - 3.4.8"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 108, "IMMEUBLE", f"('{statut}')"
    )
    dict_article["AC - 3.4.9"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 144, "IMMEUBLE", f"('{statut}')"
    )
    # PBO en chambre
    dict_article["AC - 4.1.1"] = compte_pbo(
        t_ebp, t_ptech, 6, "CHAMBRE", t_nbprise, f"('{statut}')"
    )
    dict_article["AC - 4.1.3"] = compte_pbo(
        t_ebp, t_ptech, 12, "CHAMBRE", t_nbprise, f"('{statut}')"
    )
    # PBO en chambre
    dict_article["AC - 4.2.1"] = compte_pbo(
        t_ebp, t_ptech, 6, "FACADE", t_nbprise, f"('{statut}')"
    )
    dict_article["AC - 4.2.3"] = compte_pbo(
        t_ebp, t_ptech, 12, "FACADE", t_nbprise, f"('{statut}')"
    )
    # PBO en chambre
    dict_article["AC - 4.3.1"] = compte_pbo(
        t_ebp, t_ptech, 6, "POTEAU", t_nbprise, f"('{statut}')"
    )
    dict_article["AC - 4.3.3"] = compte_pbo(
        t_ebp, t_ptech, 12, "POTEAU", t_nbprise, f"('{statut}')"
    )
    # PBO en chambre
    dict_article["AC - 4.4.1"] = compte_pbo(
        t_ebp, t_ptech, 6, "IMMEUBLE", t_nbprise, f"('{statut}')"
    )
    dict_article["AC - 4.4.3"] = compte_pbo(
        t_ebp, t_ptech, 12, "IMMEUBLE", t_nbprise, f"('{statut}')"
    )

    # Comptage des raccordements et piquage
    result = compte_raccordement(
        t_cable, t_ebp, t_cable_patch, t_nbprise, f"('{statut}')"
    )
    dict_derivation = result[0]
    dict_piquage = result[1]
    dict_joint_droit = result[2]
    dict_alignement = result[3]
    # RACC100
    dict_article["AC - 6.1.1"] = dict_joint_droit[6]
    dict_article["AC - 6.1.2"] = dict_joint_droit[12]
    dict_article["AC - 6.1.3"] = dict_joint_droit[24]
    dict_article["AC - 6.1.4"] = dict_joint_droit[36]
    dict_article["AC - 6.1.5"] = dict_joint_droit[48]
    dict_article["AC - 6.1.6"] = dict_joint_droit[72]
    dict_article["AC - 6.1.9"] = dict_joint_droit[144]
    dict_article["AC - 6.1.10"] = dict_joint_droit[288]
    dict_article["AC - 6.1.11"] = dict_joint_droit[432]
    dict_article["AC - 6.1.12"] = dict_joint_droit[576]
    dict_article["AC - 6.1.13"] = dict_joint_droit[720]
    # RACC200
    dict_article["AC - 6.1.14"] = dict_derivation[6]
    dict_article["AC - 6.1.15"] = dict_derivation[12]
    dict_article["AC - 6.1.16"] = dict_derivation[24]
    dict_article["AC - 6.1.17"] = dict_derivation[36]
    dict_article["AC - 6.1.18"] = dict_derivation[48]
    dict_article["AC - 6.1.19"] = dict_derivation[72]
    dict_article["AC - 6.1.22"] = dict_derivation[144]
    dict_article["AC - 6.1.23"] = dict_derivation[288]
    dict_article["AC - 6.1.24"] = dict_derivation[432]
    dict_article["AC - 6.1.25"] = dict_derivation[576]
    dict_article["AC - 6.1.26"] = dict_derivation[720]
    # RACC300
    dict_article["AC - 6.2.1"] = dict_piquage[6]
    dict_article["AC - 6.2.2"] = dict_piquage[12]
    dict_article["AC - 6.2.3"] = dict_piquage[24]
    dict_article["AC - 6.2.4"] = dict_piquage[36]
    dict_article["AC - 6.2.5"] = dict_piquage[48]
    dict_article["AC - 6.2.6"] = dict_piquage[72]
    dict_article["AC - 6.2.9"] = dict_piquage[144]
    dict_article["AC - 6.2.10"] = dict_piquage[288]
    dict_article["AC - 6.2.11"] = dict_piquage[432]
    dict_article["AC - 6.2.12"] = dict_piquage[576]

    # Les mesures et equipements optiques
    t_cable.removeSelection()
    t_sitetech.selectByExpression(f"st_typelog = 'SRO' or st_typelog = 'NRO'")
    for site in t_sitetech.selectedFeatures():
        nd_code = site["st_nd_code"]
        t_cable.selectByExpression(
            f"(cb_nd1 = '{nd_code}' or cb_nd2 = '{nd_code}') and cb_statut in ('{statut}')",
            behavior=1,
        )
    nb36 = 0
    nb48 = 0
    nb72 = 0
    nb144 = 0
    for cable in t_cable.selectedFeatures():
        if int(cable["cb_capafo"]) <= 36:
            nb36 += 1
        elif int(cable["cb_capafo"]) == 48:
            nb48 += 1
        elif int(cable["cb_capafo"]) == 72:
            nb72 += 1
        elif int(cable["cb_capafo"]) >= 144:
            nb144 += int(cable["cb_capafo"]) // 144
    dict_article["AC - 6.3.1"] = nb36
    dict_article["AC - 6.3.2"] = nb48
    dict_article["AC - 6.3.3"] = nb72
    dict_article["AC - 6.3.4"] = nb144
    # Chambre à créer
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and pt_typephy = 'C' and regexp_match(pt_codeext ,'C39\\\\d{{4}}') and pt_nature = 'L0T'"
    )
    dict_article["AC - 7.6.1.1"] = t_ptech.selectedFeatureCount()
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and pt_typephy = 'C' and regexp_match(pt_codeext ,'C39\\\\d{{4}}') and pt_nature = 'L1T'"
    )
    dict_article["AC - 7.6.1.3"] = t_ptech.selectedFeatureCount()
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and pt_typephy = 'C' and regexp_match(pt_codeext ,'C39\\\\d{{4}}') and pt_nature = 'L2T'"
    )
    dict_article["AC - 7.6.1.5"] = t_ptech.selectedFeatureCount()
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and pt_typephy = 'C' and regexp_match(pt_codeext ,'C39\\\\d{{4}}') and pt_nature = 'L3T'"
    )
    dict_article["AC - 7.6.1.7"] = t_ptech.selectedFeatureCount()
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and pt_typephy = 'C' and regexp_match(pt_codeext ,'C39\\\\d{{4}}') and pt_nature = 'L4T'"
    )
    dict_article["AC - 7.6.1.9"] = t_ptech.selectedFeatureCount()
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and pt_typephy = 'C' and regexp_match(pt_codeext ,'C39\\\\d{{4}}') and pt_nature = 'L5T'"
    )
    dict_article["AC - 7.6.1.10"] = t_ptech.selectedFeatureCount()
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and pt_typephy = 'C' and regexp_match(pt_codeext ,'C39\\\\d{{4}}') and pt_nature = 'L6T'"
    )
    dict_article["AC - 7.6.1.11"] = t_ptech.selectedFeatureCount()
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and pt_typephy = 'C' and regexp_match(pt_codeext ,'C39\\\\d{{4}}') and pt_nature = 'L1C'"
    )
    dict_article["AC - 7.6.1.12"] = t_ptech.selectedFeatureCount()
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and pt_typephy = 'C' and regexp_match(pt_codeext ,'C39\\\\d{{4}}') and pt_nature = 'L2C'"
    )
    dict_article["AC - 7.6.1.13"] = t_ptech.selectedFeatureCount()
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and pt_typephy = 'C' and regexp_match(pt_codeext ,'C39\\\\d{{4}}') and pt_nature = 'K1C'"
    )
    dict_article["AC - 7.6.1.14"] = t_ptech.selectedFeatureCount()
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and pt_typephy = 'C' and regexp_match(pt_codeext ,'C39\\\\d{{4}}') and pt_nature = 'K2C'"
    )
    dict_article["AC - 7.6.1.15"] = t_ptech.selectedFeatureCount()
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and pt_typephy = 'C' and regexp_match(pt_codeext ,'C39\\\\d{{4}}') and pt_nature = 'K3C'"
    )
    dict_article["AC - 7.6.1.16"] = t_ptech.selectedFeatureCount()
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and pt_typephy = 'C' and regexp_match(pt_codeext ,'C39\\\\d{{4}}') and pt_nature = 'L3C'"
    )
    dict_article["AV1 - 3.2"] = t_ptech.selectedFeatureCount()
    # GC
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and cm_remblai is not NULL"
    )
    gc_total = sum([cm["cm_long"] for cm in t_cheminement.selectedFeatures()])
    dict_article["AC - 7.3"] = gc_total
    # Tranchée tradi
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and (cm_remblai like '%TT1' or cm_remblai like 'Tradi 01')"
    )
    dict_article["AC - 7.3.1.1"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and (cm_remblai like '%TT2' or cm_remblai like '%T02' or cm_remblai like 'Tradi 02')"
    )
    dict_article["AC - 7.3.1.2"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and (cm_remblai like '%TT3' or cm_remblai like 'Tradi 03')"
    )
    dict_article["AC - 7.3.1.3"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and (cm_remblai like '%TT4' or cm_remblai like 'Tradi 04')"
    )
    dict_article["AC - 7.3.1.4"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and (cm_remblai like '%TT5' or cm_remblai like 'Tradi 05')"
    )
    dict_article["AC - 7.3.1.5"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and (cm_remblai like '%TT6' or cm_remblai like 'Tradi 06')"
    )
    dict_article["AC - 7.3.1.6"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and (cm_remblai like '%TT7' or cm_remblai like 'Tradi 07')"
    )
    dict_article["AC - 7.3.1.7"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and (cm_remblai like '%TT8' or cm_remblai like 'Tradi 08')"
    )
    dict_article["AC - 7.3.1.8"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and (cm_remblai like '%TT9' or cm_remblai like 'Tradi 09')"
    )
    dict_article["AC - 7.3.1.9"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and (cm_remblai like '%TT10' or cm_remblai like 'Tradi 10')"
    )
    dict_article["AC - 7.3.1.10"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and (cm_remblai like '%TT11' or cm_remblai like 'Tradi 11')"
    )
    dict_article["AC - 7.3.1.11"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    # Tranchée meca
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and (cm_remblai like '%TC1' or cm_remblai like 'Meca 01')"
    )
    dict_article["AC - 7.3.2.1"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and (cm_remblai like '%TC2' or cm_remblai like 'Meca 02')"
    )
    dict_article["AC - 7.3.2.2"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and (cm_remblai like '%TC3' or cm_remblai like 'Meca 03')"
    )
    dict_article["AC - 7.3.2.3"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and (cm_remblai like '%TC4' or cm_remblai like 'Meca 04')"
    )
    dict_article["AC - 7.3.2.4"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and (cm_remblai like '%TC5' or cm_remblai like 'Meca 05')"
    )
    dict_article["AC - 7.3.2.5"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and (cm_remblai like '%TC6' or cm_remblai like 'Meca 06')"
    )
    dict_article["AC - 7.3.2.6"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and (cm_remblai like '%TC7' or cm_remblai like 'Meca 07')"
    )
    dict_article["AC - 7.3.2.7"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and (cm_remblai like '%TC8' or cm_remblai like 'Meca 08')"
    )
    dict_article["AC - 7.3.2.8"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and (cm_remblai like '%TC9' or cm_remblai like 'Meca 09')"
    )
    dict_article["AC - 7.3.2.9"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and (cm_remblai like '%TC10' or cm_remblai like 'Meca 10')"
    )
    dict_article["AC - 7.3.2.10"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and (cm_remblai like '%SPEC1' or cm_remblai like 'Spec 10')"
    )
    dict_article["AC - 7.3.2.17"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and (cm_remblai like '%SPEC3' or cm_remblai like 'Spec 10')"
    )
    dict_article["AC - 7.3.2.18"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    # Avenant
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and cm_remblai like '%TT1_D'"
    )
    dict_article["AV1 - 1.1.1"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and cm_remblai like '%TT2_D'"
    )
    dict_article["AV1 - 1.1.2"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and cm_remblai like '%TT3_D'"
    )
    dict_article["AV1 - 1.1.3"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and cm_remblai like '%TT4_D'"
    )
    dict_article["AV1 - 1.1.4"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and cm_remblai like '%TT5_D'"
    )
    dict_article["AV1 - 1.1.5"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and cm_remblai like '%TT6_D'"
    )
    dict_article["AV1 - 1.1.6"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and (cm_remblai like '%TT7_D'  or cm_remblai like '%TD07D' or cm_remblai like '%T07D')"
    )
    dict_article["AV1 - 1.1.7"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and cm_remblai like '%TT8_D'"
    )
    dict_article["AV1 - 1.1.8"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and cm_remblai like '%TT9_D'"
    )
    dict_article["AV1 - 1.1.9"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and cm_remblai like '%TT10_D'"
    )
    dict_article["AV1 - 1.1.10"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and cm_remblai like '%TT11_D'"
    )
    dict_article["AV1 - 1.1.11"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and (cm_remblai like '%TT12_D' or cm_remblai like '%T12D')"
    )
    dict_article["AV1 - 1.1.12"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and cm_remblai like '%TT15_D'"
    )
    dict_article["AV1 - 1.1.15"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    # Les mesures
    t_nbprise.selectByExpression(
        f"bp_statut = '{statut}' and bp_typelog = 'PBO' and nb_prise < 6 and (bp_avct in  ('E', 'C') or bp_avct is NULL)"
    )
    dict_article["AC - 8.3.1"] = t_nbprise.selectedFeatureCount()
    t_nbprise.selectByExpression(
        f"bp_statut = '{statut}' and bp_typelog = 'PBO' and nb_prise >= 6 and (bp_avct in  ('E', 'C') or bp_avct is NULL)"
    )
    dict_article["AC - 8.3.2"] = t_nbprise.selectedFeatureCount()
    return dict_article


def remplir_dictionnaire3(
    transport,
    t_cable,
    t_ptech,
    t_ebp,
    t_nbprise,
    t_cable_patch,
    t_sitetech,
    t_cheminement,
    statut,
):
    dict_article = {}
    # Installation de chantier
    # dict_article['AC - 1.1'] = 1
    # Fourniture Poteaux créés en bois
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and pt_typephy = 'A' and regexp_match(pt_codeext ,'A39\\\\d{{4}}') and (pt_nature is null or pt_nature = 'PBOI') and (pt_a_haut < 10 or pt_a_haut is null)"
    )
    dict_article["AC - 7.5.1.3"] = t_ptech.selectedFeatureCount()
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and pt_typephy = 'A' and regexp_match(pt_codeext ,'A39\\\\d{{4}}') and (pt_nature is null or pt_nature = 'PBOI') and (pt_a_haut >= 10)"
    )
    dict_article["AC - 7.5.1.4"] = t_ptech.selectedFeatureCount()
    # Fourniture Poteaux créés en metal
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and pt_typephy = 'A' and regexp_match(pt_codeext ,'A39\\\\d{{4}}') and (pt_nature = 'PMET' or pt_nature = 'PIND') and (pt_a_haut < 10 or pt_a_haut is null)"
    )
    dict_article["AC - 7.5.4.1"] = t_ptech.selectedFeatureCount()
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and pt_typephy = 'A' and regexp_match(pt_codeext ,'A39\\\\d{{4}}') and (pt_nature = 'PMET' or pt_nature = 'PIND') and (pt_a_haut >= 10)"
    )
    dict_article["AC - 7.5.4.2"] = t_ptech.selectedFeatureCount()
    # Pose Poteaux créés en bois
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and pt_typephy = 'A' and regexp_match(pt_codeext ,'A39\\\\d{{4}}') and (pt_nature is null or pt_nature = 'PBOI')"
    )
    dict_article["AC - 7.5.6.1"] = t_ptech.selectedFeatureCount()
    # Pose Poteaux créés en metal
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and pt_typephy = 'A' and regexp_match(pt_codeext ,'A39\\\\d{{4}}') and (pt_nature = 'PMET' or pt_nature = 'PIND')"
    )
    dict_article["AC - 7.5.6.2"] = t_ptech.selectedFeatureCount()
    # Armement poteaux
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and pt_typephy = 'A' and pt_prop in ('OR210000000001', 'OR390000000001', 'OR710000000571', 'OR000000000001', 'OR215000000150', 'OR000000000005')"
    )
    dict_article["AC - 7.5.14.1"] = t_ptech.selectedFeatureCount()
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and pt_typephy = 'A' and pt_prop in ('OR000000000002')"
    )
    dict_article["AC - 7.5.14.3"] = t_ptech.selectedFeatureCount()
    # Calcul des longueurs de cable par capa et par support
    longueur_reelle = calcul_longueur(statut, t_cable, t_ptech)
    # Cable conduite modulo 6:
    dict_article["AC - 2.1.1"] = longueur_reelle["SOUTERRAIN"][6][6]
    dict_article["AC - 2.1.2"] = longueur_reelle["SOUTERRAIN"][12][6]
    dict_article["AC - 2.1.3"] = longueur_reelle["SOUTERRAIN"][24][6]
    dict_article["AC - 2.1.4"] = longueur_reelle["SOUTERRAIN"][24][12]
    dict_article["AC - 2.1.5"] = longueur_reelle["SOUTERRAIN"][36][6]
    dict_article["AC - 2.1.6"] = longueur_reelle["SOUTERRAIN"][36][12]
    dict_article["AC - 2.1.7"] = longueur_reelle["SOUTERRAIN"][48][6]
    dict_article["AC - 2.1.8"] = longueur_reelle["SOUTERRAIN"][48][12]
    dict_article["AC - 2.1.9"] = longueur_reelle["SOUTERRAIN"][72][6]
    dict_article["AC - 2.1.10"] = longueur_reelle["SOUTERRAIN"][72][12]
    dict_article["AC - 2.1.15"] = longueur_reelle["SOUTERRAIN"][144][6]
    dict_article["AC - 2.1.16"] = longueur_reelle["SOUTERRAIN"][144][12]
    dict_article["AC - 2.1.17"] = longueur_reelle["SOUTERRAIN"][288][12]
    dict_article["AC - 2.1.18"] = longueur_reelle["SOUTERRAIN"][432][12]
    dict_article["AC - 2.1.19"] = longueur_reelle["SOUTERRAIN"][576][12]
    dict_article["AC - 2.1.20"] = longueur_reelle["SOUTERRAIN"][720][12]
    # CABL300:
    dict_article["AC - 2.2.1"] = longueur_reelle["AERIEN"][6][6]
    dict_article["AC - 2.2.2"] = longueur_reelle["AERIEN"][12][6]
    dict_article["AC - 2.2.3"] = longueur_reelle["AERIEN"][24][6]
    dict_article["AC - 2.2.4"] = longueur_reelle["AERIEN"][24][12]
    dict_article["AC - 2.2.5"] = longueur_reelle["AERIEN"][36][6]
    dict_article["AC - 2.2.6"] = longueur_reelle["AERIEN"][36][12]
    dict_article["AC - 2.2.7"] = longueur_reelle["AERIEN"][48][6]
    dict_article["AC - 2.2.8"] = longueur_reelle["AERIEN"][48][12]
    dict_article["AC - 2.2.9"] = (
        longueur_reelle["AERIEN"][72][6] + longueur_reelle["FACADE"][72][6]
    )
    dict_article["AC - 2.2.10"] = (
        longueur_reelle["AERIEN"][72][12] + longueur_reelle["FACADE"][72][12]
    )
    dict_article["AC - 2.2.15"] = (
        longueur_reelle["AERIEN"][144][6] + longueur_reelle["FACADE"][144][6]
    )
    dict_article["AC - 2.2.16"] = (
        longueur_reelle["AERIEN"][144][12] + longueur_reelle["FACADE"][144][12]
    )

    dict_article["AC - 2.5.1"] = longueur_reelle["IMMEUBLE"][6][6]
    dict_article["AC - 2.5.2"] = longueur_reelle["IMMEUBLE"][12][6]
    dict_article["AC - 2.5.3"] = longueur_reelle["IMMEUBLE"][24][6]
    dict_article["AC - 2.5.4"] = longueur_reelle["IMMEUBLE"][24][12]
    dict_article["AC - 2.5.5"] = longueur_reelle["IMMEUBLE"][36][6]
    dict_article["AC - 2.5.6"] = longueur_reelle["IMMEUBLE"][36][12]
    dict_article["AC - 2.5.7"] = longueur_reelle["IMMEUBLE"][48][6]
    dict_article["AC - 2.5.8"] = longueur_reelle["IMMEUBLE"][48][12]
    dict_article["AC - 2.5.9"] = longueur_reelle["IMMEUBLE"][72][6]
    dict_article["AC - 2.5.10"] = longueur_reelle["IMMEUBLE"][72][12]
    dict_article["AC - 2.5.15"] = longueur_reelle["IMMEUBLE"][144][6]
    dict_article["AC - 2.5.16"] = longueur_reelle["IMMEUBLE"][144][12]

    dict_article["AC - 2.7.1"] = longueur_reelle["FACADE"][6][6]
    dict_article["AC - 2.7.2"] = longueur_reelle["FACADE"][12][6]
    dict_article["AC - 2.7.3"] = longueur_reelle["FACADE"][24][6]
    dict_article["AC - 2.7.4"] = longueur_reelle["FACADE"][24][12]
    dict_article["AC - 2.7.5"] = longueur_reelle["FACADE"][36][6]
    dict_article["AC - 2.7.6"] = longueur_reelle["FACADE"][36][12]
    dict_article["AC - 2.7.7"] = longueur_reelle["FACADE"][48][6]
    dict_article["AC - 2.7.8"] = longueur_reelle["FACADE"][48][12]

    # Comptage des BPE
    # BPE en chambre
    dict_article["AC - 3.1.1"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 6, "CHAMBRE", f"('{statut}')"
    )
    dict_article["AC - 3.1.2"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 12, "CHAMBRE", f"('{statut}')"
    )
    dict_article["AC - 3.1.3"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 24, "CHAMBRE", f"('{statut}')"
    )
    dict_article["AC - 3.1.4"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 36, "CHAMBRE", f"('{statut}')"
    )
    dict_article["AC - 3.1.5"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 48, "CHAMBRE", f"('{statut}')"
    )
    dict_article["AC - 3.1.6"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 72, "CHAMBRE", f"('{statut}')"
    )
    dict_article["AC - 3.1.7"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 96, "CHAMBRE", f"('{statut}')"
    )
    dict_article["AC - 3.1.8"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 108, "CHAMBRE", f"('{statut}')"
    )
    dict_article["AC - 3.1.9"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 144, "CHAMBRE", f"('{statut}')"
    )
    dict_article["AC - 3.1.10"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 288, "CHAMBRE", f"('{statut}')"
    )
    dict_article["AC - 3.1.11"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 432, "CHAMBRE", f"('{statut}')"
    )
    dict_article["AC - 3.1.12"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 576, "CHAMBRE", f"('{statut}')"
    )
    dict_article["AC - 3.1.13"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 720, "CHAMBRE", f"('{statut}')"
    )
    # BPE sur facade
    dict_article["AC - 3.2.1"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 6, "FACADE", f"('{statut}')"
    )
    dict_article["AC - 3.2.2"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 12, "FACADE", f"('{statut}')"
    )
    dict_article["AC - 3.2.3"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 24, "FACADE", f"('{statut}')"
    )
    dict_article["AC - 3.2.4"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 36, "FACADE", f"('{statut}')"
    )
    dict_article["AC - 3.2.5"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 48, "FACADE", f"('{statut}')"
    )
    dict_article["AC - 3.2.6"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 72, "FACADE", f"('{statut}')"
    )
    dict_article["AC - 3.2.7"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 96, "FACADE", f"('{statut}')"
    )
    dict_article["AC - 3.2.8"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 108, "FACADE", f"('{statut}')"
    )
    dict_article["AC - 3.2.9"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 144, "FACADE", f"('{statut}')"
    )
    # Boites sur poteau
    dict_article["AC - 3.3.1"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 6, "POTEAU", f"('{statut}')"
    )
    dict_article["AC - 3.3.2"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 12, "POTEAU", f"('{statut}')"
    )
    dict_article["AC - 3.3.3"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 24, "POTEAU", f"('{statut}')"
    )
    dict_article["AC - 3.3.4"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 36, "POTEAU", f"('{statut}')"
    )
    dict_article["AC - 3.3.5"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 48, "POTEAU", f"('{statut}')"
    )
    dict_article["AC - 3.3.6"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 72, "POTEAU", f"('{statut}')"
    )
    dict_article["AC - 3.3.7"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 96, "POTEAU", f"('{statut}')"
    )
    dict_article["AC - 3.3.8"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 108, "POTEAU", f"('{statut}')"
    )
    dict_article["AC - 3.3.9"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 144, "POTEAU", f"('{statut}')"
    )
    dict_article["AC - 3.3.10"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 288, "POTEAU", f"('{statut}')"
    )
    # BPE sur IMMEUBLE
    dict_article["AC - 3.4.1"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 6, "IMMEUBLE", f"('{statut}')"
    )
    dict_article["AC - 3.4.2"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 12, "IMMEUBLE", f"('{statut}')"
    )
    dict_article["AC - 3.4.3"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 24, "IMMEUBLE", f"('{statut}')"
    )
    dict_article["AC - 3.4.4"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 36, "IMMEUBLE", f"('{statut}')"
    )
    dict_article["AC - 3.4.5"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 48, "IMMEUBLE", f"('{statut}')"
    )
    dict_article["AC - 3.4.6"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 72, "IMMEUBLE", f"('{statut}')"
    )
    dict_article["AC - 3.4.7"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 96, "IMMEUBLE", f"('{statut}')"
    )
    dict_article["AC - 3.4.8"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 108, "IMMEUBLE", f"('{statut}')"
    )
    dict_article["AC - 3.4.9"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 144, "IMMEUBLE", f"('{statut}')"
    )
    # PBO en chambre
    dict_article["AC - 4.1.1"] = compte_pbo(
        t_ebp, t_ptech, 6, "CHAMBRE", t_nbprise, f"('{statut}')"
    )
    dict_article["AC - 4.1.3"] = compte_pbo(
        t_ebp, t_ptech, 12, "CHAMBRE", t_nbprise, f"('{statut}')"
    )
    # PBO en chambre
    dict_article["AC - 4.2.1"] = compte_pbo(
        t_ebp, t_ptech, 6, "FACADE", t_nbprise, f"('{statut}')"
    )
    dict_article["AC - 4.2.3"] = compte_pbo(
        t_ebp, t_ptech, 12, "FACADE", t_nbprise, f"('{statut}')"
    )
    # PBO en chambre
    dict_article["AC - 4.3.1"] = compte_pbo(
        t_ebp, t_ptech, 6, "POTEAU", t_nbprise, f"('{statut}')"
    )
    dict_article["AC - 4.3.3"] = compte_pbo(
        t_ebp, t_ptech, 12, "POTEAU", t_nbprise, f"('{statut}')"
    )
    # PBO en chambre
    dict_article["AC - 4.4.1"] = compte_pbo(
        t_ebp, t_ptech, 6, "IMMEUBLE", t_nbprise, f"('{statut}')"
    )
    dict_article["AC - 4.4.3"] = compte_pbo(
        t_ebp, t_ptech, 12, "IMMEUBLE", t_nbprise, f"('{statut}')"
    )

    # Comptage des raccordements et piquage
    result = compte_raccordement(
        t_cable, t_ebp, t_cable_patch, t_nbprise, f"('{statut}')"
    )
    dict_derivation = result[0]
    dict_piquage = result[1]
    dict_joint_droit = result[2]
    dict_alignement = result[3]
    # RACC100
    dict_article["AC - 6.1.1"] = dict_joint_droit[6]
    dict_article["AC - 6.1.2"] = dict_joint_droit[12]
    dict_article["AC - 6.1.3"] = dict_joint_droit[24]
    dict_article["AC - 6.1.4"] = dict_joint_droit[36]
    dict_article["AC - 6.1.5"] = dict_joint_droit[48]
    dict_article["AC - 6.1.6"] = dict_joint_droit[72]
    dict_article["AC - 6.1.9"] = dict_joint_droit[144]
    dict_article["AC - 6.1.10"] = dict_joint_droit[288]
    dict_article["AC - 6.1.11"] = dict_joint_droit[432]
    dict_article["AC - 6.1.12"] = dict_joint_droit[576]
    dict_article["AC - 6.1.13"] = dict_joint_droit[720]
    # RACC200
    dict_article["AC - 6.1.14"] = dict_derivation[6]
    dict_article["AC - 6.1.15"] = dict_derivation[12]
    dict_article["AC - 6.1.16"] = dict_derivation[24]
    dict_article["AC - 6.1.17"] = dict_derivation[36]
    dict_article["AC - 6.1.18"] = dict_derivation[48]
    dict_article["AC - 6.1.19"] = dict_derivation[72]
    dict_article["AC - 6.1.22"] = dict_derivation[144]
    dict_article["AC - 6.1.23"] = dict_derivation[288]
    dict_article["AC - 6.1.24"] = dict_derivation[432]
    dict_article["AC - 6.1.25"] = dict_derivation[576]
    dict_article["AC - 6.1.26"] = dict_derivation[720]
    # RACC300
    dict_article["AC - 6.2.1"] = dict_piquage[6]
    dict_article["AC - 6.2.2"] = dict_piquage[12]
    dict_article["AC - 6.2.3"] = dict_piquage[24]
    dict_article["AC - 6.2.4"] = dict_piquage[36]
    dict_article["AC - 6.2.5"] = dict_piquage[48]
    dict_article["AC - 6.2.6"] = dict_piquage[72]
    dict_article["AC - 6.2.9"] = dict_piquage[144]
    dict_article["AC - 6.2.10"] = dict_piquage[288]
    dict_article["AC - 6.2.11"] = dict_piquage[432]
    dict_article["AC - 6.2.12"] = dict_piquage[576]

    # Les mesures et equipements optiques
    t_cable.removeSelection()
    t_sitetech.selectByExpression(f"st_typelog = 'SRO' or st_typelog = 'NRO'")
    for site in t_sitetech.selectedFeatures():
        nd_code = site["st_nd_code"]
        t_cable.selectByExpression(
            f"(cb_nd1 = '{nd_code}' or cb_nd2 = '{nd_code}') and cb_statut in ('{statut}')",
            behavior=1,
        )
    nb36 = 0
    nb48 = 0
    nb72 = 0
    nb144 = 0
    for cable in t_cable.selectedFeatures():
        if int(cable["cb_capafo"]) <= 36:
            nb36 += 1
        elif int(cable["cb_capafo"]) == 48:
            nb48 += 1
        elif int(cable["cb_capafo"]) == 72:
            nb72 += 1
        elif int(cable["cb_capafo"]) >= 144:
            nb144 += int(cable["cb_capafo"]) // 144
    dict_article["AC - 6.3.1"] = nb36
    dict_article["AC - 6.3.2"] = nb48
    dict_article["AC - 6.3.3"] = nb72
    dict_article["AC - 6.3.4"] = nb144
    # Chambre à créer
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and pt_typephy = 'C' and regexp_match(pt_codeext ,'C39\\\\d{{4}}') and pt_nature = 'L0T'"
    )
    dict_article["AC - 7.6.1.1"] = t_ptech.selectedFeatureCount()
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and pt_typephy = 'C' and regexp_match(pt_codeext ,'C39\\\\d{{4}}') and pt_nature = 'L1T'"
    )
    dict_article["AC - 7.6.1.3"] = t_ptech.selectedFeatureCount()
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and pt_typephy = 'C' and regexp_match(pt_codeext ,'C39\\\\d{{4}}') and pt_nature = 'L2T'"
    )
    dict_article["AC - 7.6.1.5"] = t_ptech.selectedFeatureCount()
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and pt_typephy = 'C' and regexp_match(pt_codeext ,'C39\\\\d{{4}}') and pt_nature = 'L3T'"
    )
    dict_article["AC - 7.6.1.7"] = t_ptech.selectedFeatureCount()
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and pt_typephy = 'C' and regexp_match(pt_codeext ,'C39\\\\d{{4}}') and pt_nature = 'L4T'"
    )
    dict_article["AC - 7.6.1.9"] = t_ptech.selectedFeatureCount()
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and pt_typephy = 'C' and regexp_match(pt_codeext ,'C39\\\\d{{4}}') and pt_nature = 'L5T'"
    )
    dict_article["AC - 7.6.1.10"] = t_ptech.selectedFeatureCount()
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and pt_typephy = 'C' and regexp_match(pt_codeext ,'C39\\\\d{{4}}') and pt_nature = 'L6T'"
    )
    dict_article["AC - 7.6.1.11"] = t_ptech.selectedFeatureCount()
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and pt_typephy = 'C' and regexp_match(pt_codeext ,'C39\\\\d{{4}}') and pt_nature = 'L1C'"
    )
    dict_article["AC - 7.6.1.12"] = t_ptech.selectedFeatureCount()
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and pt_typephy = 'C' and regexp_match(pt_codeext ,'C39\\\\d{{4}}') and pt_nature = 'L2C'"
    )
    dict_article["AC - 7.6.1.13"] = t_ptech.selectedFeatureCount()
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and pt_typephy = 'C' and regexp_match(pt_codeext ,'C39\\\\d{{4}}') and pt_nature = 'K1C'"
    )
    dict_article["AC - 7.6.1.14"] = t_ptech.selectedFeatureCount()
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and pt_typephy = 'C' and regexp_match(pt_codeext ,'C39\\\\d{{4}}') and pt_nature = 'K2C'"
    )
    dict_article["AC - 7.6.1.15"] = t_ptech.selectedFeatureCount()
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and pt_typephy = 'C' and regexp_match(pt_codeext ,'C39\\\\d{{4}}') and pt_nature = 'K3C'"
    )
    dict_article["AC - 7.6.1.16"] = t_ptech.selectedFeatureCount()
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and pt_typephy = 'C' and regexp_match(pt_codeext ,'C39\\\\d{{4}}') and pt_nature = 'L3C'"
    )
    dict_article["AV1 - 3.2"] = t_ptech.selectedFeatureCount()
    # GC
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and cm_remblai is not NULL"
    )
    gc_total = sum([cm["cm_long"] for cm in t_cheminement.selectedFeatures()])
    dict_article["AC - 7.3"] = gc_total
    # Tranchée tradi
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and cm_remblai like '%TT1'"
    )
    dict_article["AC - 7.3.1.1"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and (cm_remblai like '%TT2' or cm_remblai like '%T02')"
    )
    dict_article["AC - 7.3.1.2"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and cm_remblai like '%TT3'"
    )
    dict_article["AC - 7.3.1.3"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and cm_remblai like '%TT4'"
    )
    dict_article["AC - 7.3.1.4"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and cm_remblai like '%TT5'"
    )
    dict_article["AC - 7.3.1.5"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and cm_remblai like '%TT6'"
    )
    dict_article["AC - 7.3.1.6"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and cm_remblai like '%TT7'"
    )
    dict_article["AC - 7.3.1.7"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and cm_remblai like '%TT8'"
    )
    dict_article["AC - 7.3.1.8"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and cm_remblai like '%TT9'"
    )
    dict_article["AC - 7.3.1.9"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and cm_remblai like '%TT10'"
    )
    dict_article["AC - 7.3.1.10"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and cm_remblai like '%TT11'"
    )
    dict_article["AC - 7.3.1.11"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    # Avenant
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and cm_remblai like '%TT1_D'"
    )
    dict_article["AC - 7.3.1.19"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and cm_remblai like '%TT2_D'"
    )
    dict_article["AC - 7.3.1.20"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and cm_remblai like '%TT3_D'"
    )
    dict_article["AC - 7.3.1.21"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and cm_remblai like '%TT4_D'"
    )
    dict_article["AC - 7.3.1.22"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and cm_remblai like '%TT5_D'"
    )
    dict_article["AC - 7.3.1.23"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and cm_remblai like '%TT6_D'"
    )
    dict_article["AC - 7.3.1.24"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and (cm_remblai like '%TT7_D' or cm_remblai like '%TD07D' or cm_remblai like '%T07D')"
    )
    dict_article["AC - 7.3.1.25"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and cm_remblai like '%TT8_D'"
    )
    dict_article["AC - 7.3.1.26"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and cm_remblai like '%TT9_D'"
    )
    dict_article["AC - 7.3.1.27"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and cm_remblai like '%TT10_D'"
    )
    dict_article["AC - 7.3.1.28"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and cm_remblai like '%TT11_D'"
    )
    dict_article["AC - 7.3.1.29"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and (cm_remblai like '%TT12_D' or cm_remblai like '%T12D')"
    )
    dict_article["AC - 7.3.1.30"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and cm_remblai like '%TT13_D'"
    )
    dict_article["AC - 7.3.1.31"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and cm_remblai like '%TT15_D'"
    )
    dict_article["AC - 7.3.1.32"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    # Tranchée meca
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and cm_remblai like '%TC1'"
    )
    dict_article["AC - 7.3.2.1"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and cm_remblai like '%TC2'"
    )
    dict_article["AC - 7.3.2.2"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and cm_remblai like '%TC3'"
    )
    dict_article["AC - 7.3.2.3"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and cm_remblai like '%TC4'"
    )
    dict_article["AC - 7.3.2.4"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and cm_remblai like '%TC5'"
    )
    dict_article["AC - 7.3.2.5"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and cm_remblai like '%TC6'"
    )
    dict_article["AC - 7.3.2.6"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and cm_remblai like '%TC7'"
    )
    dict_article["AC - 7.3.2.7"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and cm_remblai like '%TC8'"
    )
    dict_article["AC - 7.3.2.8"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and cm_remblai like '%TC9'"
    )
    dict_article["AC - 7.3.2.9"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and cm_remblai like '%TC10'"
    )
    dict_article["AC - 7.3.2.10"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and cm_remblai like '%SPEC1'"
    )
    dict_article["AC - 7.3.2.17"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and cm_remblai like '%SPEC3'"
    )
    dict_article["AC - 7.3.2.18"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )

    # Les mesures
    t_nbprise.selectByExpression(
        f"bp_statut = '{statut}' and bp_typelog = 'PBO' and nb_prise < 6 and (bp_avct in  ('E', 'C') or bp_avct is NULL)"
    )
    dict_article["AC - 8.3.1"] = t_nbprise.selectedFeatureCount()
    t_nbprise.selectByExpression(
        f"bp_statut = '{statut}' and bp_typelog = 'PBO' and nb_prise >= 6 and (bp_avct in  ('E', 'C') or bp_avct is NULL)"
    )
    dict_article["AC - 8.3.2"] = t_nbprise.selectedFeatureCount()
    return dict_article


def calcul_longueur(statut, t_cable, t_ptech):
    longueur_reelle = {}
    # Pour les modes de pose
    longueur_reelle["pvc"] = 0
    longueur_reelle["pehd"] = 0
    longueur_reelle["aerien"] = 0
    longueur_reelle["facade"] = 0
    longueur_reelle["immeuble"] = 0
    # Pour les cables par capa:
    liste_type_cable = ["AERIEN", "SOUTERRAIN", "IMMEUBLE", "FACADE"]
    liste_capa = [6, 12, 24, 36, 48, 72, 96, 108, 144, 288, 432, 576, 720]
    for elem in liste_type_cable:
        longueur_reelle[elem] = {}
        for capa in liste_capa:
            longueur_reelle[elem][capa] = {6: 0, 12: 0}
    # On parcourt les cables pour répartir leur longueur
    t_cable.selectByExpression(
        f"cb_statut = '{statut}' and (cb_avct in ('E', 'C') or cb_avct is NULL)"
    )
    for cable in t_cable.selectedFeatures():
        cb_lgreel = float(str(cable["cb_lgreel"]).replace(",", ".")) or 0
        capa = cable["cb_capafo"]
        modulo = cable["cb_modulo"]
        facade = 0
        aerien = 0
        pvc = 0
        pehd = 0
        immeuble = 0
        # La table des cable-cheminement
        # print('avant requete t_cb_cm', datetime.datetime.now(), datetime.datetime.now())
        # Exécuter SQL
        alg_params = {
            "INPUT_DATASOURCES": [],
            "INPUT_GEOMETRY_CRS": QgsCoordinateReferenceSystem("EPSG:2154"),
            "INPUT_GEOMETRY_FIELD": "",
            "INPUT_GEOMETRY_TYPE": 1,
            "INPUT_QUERY": (
                f"select cb_code, cb_capafo, cb_lgreel, t_cab_cond.cc_cd_code, t_conduite.cd_prop, t_conduite.cd_type, t_cheminement.cm_code,t_cheminement.cm_typ_imp, t_conduite.cd_type, length(t_cheminement.geometry) as cm_longueur, t_cheminement.geometry "
                f"from t_cable, t_cab_cond, t_conduite, t_cond_chem, t_cheminement "
                f"where t_cab_cond.cc_cb_code = t_cable.cb_code and t_conduite.cd_code = t_cab_cond.cc_cd_code and t_cond_chem.dm_cd_code = t_conduite.cd_code and t_cheminement.cm_code=t_cond_chem.dm_cm_code and t_cable.cb_code = '{cable['cb_code']}'"
            ),
            "INPUT_UID_FIELD": "",
            "OUTPUT": "TEMPORARY_OUTPUT",
        }
        t_cb_cm = processing.run("qgis:executesql", alg_params)["OUTPUT"]
        # print('après requete t_cb_cm', datetime.datetime.now())
        # print(cable.id(), ' : ', cable.geometry().length(), ' - ', sum([entite.geometry().length() for entite in t_cheminement.selectedFeatures()]))
        # On sélectionne en fonction de la pose souhaitée
        t_cb_cm.selectByExpression("cm_typ_imp in (0,1)")
        if t_cb_cm.selectedFeatureCount() > 0:
            longueur_reelle["AERIEN"][capa][modulo] += cb_lgreel
        else:
            t_cb_cm.selectByExpression("cm_typ_imp in (2)")
            if t_cb_cm.selectedFeatureCount() > 0:
                longueur_reelle["FACADE"][capa][modulo] += cb_lgreel
            else:
                t_cb_cm.selectByExpression("cm_typ_imp in (4, 5, 6, 7, 8, 9)")
                if t_cb_cm.selectedFeatureCount() > 0:
                    longueur_reelle["SOUTERRAIN"][capa][modulo] += cb_lgreel
                else:
                    t_cb_cm.selectByExpression("cm_typ_imp in (3)")
                    if t_cb_cm.selectedFeatureCount() > 0:
                        longueur_reelle["IMMEUBLE"][capa][modulo] += cb_lgreel
                    else:
                        t_ptech.selectByExpression(f"pt_nd_code = '{cable['cb_nd1']}'")
                        for ptech in t_ptech.selectedFeatures():
                            if ptech["pt_typephy"] == "A":
                                longueur_reelle["AERIEN"][capa][modulo] += cb_lgreel
                            elif ptech["pt_typephy"] == "F":
                                longueur_reelle["AERIEN"][capa][modulo] += cb_lgreel
                            elif ptech["pt_typephy"] == "I":
                                longueur_reelle["IMMEUBLE"][capa][modulo] += cb_lgreel
                            else:
                                longueur_reelle["SOUTERRAIN"][capa][modulo] += cb_lgreel
                        if t_ptech.selectedFeatureCount() == 0:
                            longueur_reelle["IMMEUBLE"][capa][modulo] += cb_lgreel
        for cb_cm in t_cb_cm.getFeatures():
            if cb_cm["cm_typ_imp"] == "2":
                facade += cb_cm["cm_longueur"] or 0
            elif cb_cm["cm_typ_imp"] in ["0", "1"]:
                aerien += cb_cm["cm_longueur"] or 0
            elif cb_cm["cm_typ_imp"] == "3":
                immeuble += cb_cm["cm_longueur"] or 0
            else:
                if cb_cm["cd_type"] == "PEHD":
                    pehd += cb_cm["cm_longueur"] or 0
                else:
                    pvc += cb_cm["cm_longueur"] or 0
        total_cm = facade + aerien + immeuble + pvc + pehd
        if total_cm > 0:
            longueur_reelle["facade"] += facade * cb_lgreel / total_cm
            longueur_reelle["aerien"] += aerien * cb_lgreel / total_cm
            longueur_reelle["immeuble"] += immeuble * cb_lgreel / total_cm
            longueur_reelle["pvc"] += pvc * cb_lgreel / total_cm
            longueur_reelle["pehd"] += pehd * cb_lgreel / total_cm
        else:
            t_ptech.selectByExpression(f"pt_nd_code = '{cable['cb_nd1']}'")
            for ptech in t_ptech.selectedFeatures():
                if ptech["pt_typephy"] == "A":
                    longueur_reelle["aerien"] += cb_lgreel
                elif ptech["pt_typephy"] == "F":
                    longueur_reelle["facade"] += cb_lgreel
                elif ptech["pt_typephy"] == "I":
                    longueur_reelle["immeuble"] += cb_lgreel
                else:
                    longueur_reelle["pvc"] += cb_lgreel
            if t_ptech.selectedFeatureCount() == 0:
                longueur_reelle["immeuble"] += cb_lgreel

    return longueur_reelle


def compte_bpe(
    t_cable_patch201, t_cable, t_ebp, t_ptech, capacite, pose, statut="('REC','EXE')"
):
    dict_pt_typephy = {"A": "POTEAU", "C": "CHAMBRE", "F": "FACADE", "I": "IMMEUBLE"}
    nb_boite = 0
    # On sélectionne les BPE
    # t_ebp.selectByExpression("bp_statut = 'EXE' and bp_typelog = 'BPE' and (bp_avct = 'C' or bp_avct is null or bp_avct = '')")
    t_ebp.selectByExpression(
        f"bp_typelog = 'BPE' and bp_statut in {statut} and bp_avct in ('E', 'C')"
    )
    for ebp in t_ebp.selectedFeatures():
        type_ptech = "IMMEUBLE"
        # On va chercher le type de ptech
        t_ptech.selectByExpression("pt_code = '" + (ebp["bp_pt_code"] or "") + "'")
        for ptech in t_ptech.selectedFeatures():
            type_ptech = dict_pt_typephy[ptech["pt_typephy"]]
            break
        # On va chercher la capa du plus gros cable qui arrive à cette boite

        try:
            capamax = int(ebp["bp_typephy"][-3:])
        except:
            capamax = 0
            t_cable_patch201.selectByExpression(
                f"cb_bp1 = '{ebp['bp_code']}' or cb_bp2 = '{ebp['bp_code']}'"
            )
            for c in t_cable_patch201.selectedFeatures():
                t_cable.selectByExpression(f"cb_code = '{c['cb_code']}'")
                for cb in t_cable.selectedFeatures():
                    if int(cb["cb_capafo"]) > capamax:
                        capamax = int(cb["cb_capafo"])
        if capacite == capamax and type_ptech == pose:
            nb_boite += 1
    return nb_boite


def compte_pbo(t_ebp, t_ptech, capacite, pose, t_nbprise, statut="('REC','EXE')"):
    dict_pt_typephy = {"A": "POTEAU", "C": "CHAMBRE", "F": "FACADE", "I": "IMMEUBLE"}
    nb_boite = 0
    # On sélectionne les PBO
    # t_ebp.selectByExpression("bp_statut = 'EXE' and bp_typelog like 'PBO%' and (bp_avct = 'C' or bp_avct is null or bp_avct = '')")
    t_ebp.selectByExpression(
        f"bp_typelog like 'PBO%' and bp_statut in {statut} and bp_avct in ('E', 'C')"
    )
    for ebp in t_ebp.selectedFeatures():
        type_ptech = "IMMEUBLE"
        nb_prise = 0
        # On va chercher le type de ptech
        t_ptech.selectByExpression("pt_code = '" + (ebp["bp_pt_code"] or "") + "'")
        for ptech in t_ptech.selectedFeatures():
            type_ptech = dict_pt_typephy[ptech["pt_typephy"]]
            break
        t_nbprise.selectByExpression("bp_code = '" + ebp["bp_code"] + "'")
        for nbprise in t_nbprise.selectedFeatures():
            nb_prise = nbprise["nb_prise"]
            # print(ebp["bp_code"], "prise : ", nb_prise)
        if capacite == 6 and nb_prise < 6 and pose == type_ptech:
            nb_boite += 1
        elif capacite == 12 and nb_prise >= 6 and pose == type_ptech:
            nb_boite += 1
    return nb_boite


def compte_raccordement(
    t_cable, t_ebp, t_cable_patch, t_nbprise, statut="('REC','EXE')"
):
    # On initialise les dictionnaires
    dict_raccordement = {}
    dict_piquage = {}
    dict_joint_droit = {}
    dict_alignement = {}
    dict_cable = {}
    capa = [6, 12, 24, 36, 48, 72, 96, 108, 144, 288, 432, 576, 720]
    for elem in capa:
        dict_piquage[elem] = 0
        dict_raccordement[elem] = 0
        dict_joint_droit[elem] = 0
        dict_alignement[elem] = 0
    # On va chercher les types d'épissures dans t_position
    # print('avant requete racc', datetime.datetime.now())
    requete = f"select cs_bp_code, ps_fonct from (select * from t_position where ps_fonct = 'PA') as t_position, t_cassette where ps_cs_code = cs_code group by cs_bp_code, ps_fonct"
    alg_params = {
        "INPUT_DATASOURCES": [],
        "INPUT_GEOMETRY_CRS": QgsCoordinateReferenceSystem("EPSG:2154"),
        "INPUT_GEOMETRY_FIELD": "",
        "INPUT_GEOMETRY_TYPE": 1,
        "INPUT_QUERY": requete,
        "INPUT_UID_FIELD": "",
        "OUTPUT": "TEMPORARY_OUTPUT",
    }
    t_passage = processing.run("qgis:executesql", alg_params)["OUTPUT"]
    # print('apres requete racc', datetime.datetime.now())
    # On sélectionne les BPE
    t_ebp.selectAll()
    for ebp in t_ebp.selectedFeatures():
        # On va chercher les types d'épissures dans t_position
        """print('avant requete racc', datetime.datetime.now())
        requete = f"select cs_bp_code, ps_fonct from (select * from t_position where ps_fonct = 'PA') as t_position, (select * from t_cassette where cs_bp_code = '{ebp['bp_code']}') as t_cassette where ps_cs_code = cs_code group by cs_bp_code, ps_fonct"
        alg_params = {
            'INPUT_DATASOURCES': [],
            'INPUT_GEOMETRY_CRS': QgsCoordinateReferenceSystem('EPSG:2154'),
            'INPUT_GEOMETRY_FIELD': '',
            'INPUT_GEOMETRY_TYPE': 1,
            'INPUT_QUERY': requete,
            'INPUT_UID_FIELD': '',
            'OUTPUT': 'TEMPORARY_OUTPUT'
        }
        t_passage = processing.run('qgis:executesql', alg_params)['OUTPUT']
        print('apres requete racc', datetime.datetime.now())"""
        t_passage.selectByExpression(f"cs_bp_code = '{ebp['bp_code']}'")
        nbpassage = t_passage.selectedFeatureCount()
        liste_cable = []
        t_cable_patch.selectByExpression(
            "cb_bp1 = '" + ebp["bp_code"] + "' or cb_bp2 = '" + ebp["bp_code"] + "'"
        )
        for cable_patch in t_cable_patch.selectedFeatures():
            t_cable.selectByExpression(
                f"cb_code = '{cable_patch['cb_code']}' and (cb_avct in ('E', 'C') or cb_avct is NULL)"
            )
            for cable in t_cable.selectedFeatures():
                liste_cable.append(cable)
        if len(liste_cable) == 1:
            # Si c'est un PBO, c'est un fin de cable
            if ebp["bp_typelog"] == "PBO" and ebp["bp_statut"] in statut:
                capacite = 6
                t_nbprise.selectByExpression(f"bp_code = '{ebp['bp_code']}'")
                for nbprise in t_nbprise.selectedFeatures():
                    if nbprise["nb_prise"] >= 6:
                        capacite = 12
                dict_piquage[capacite] += 1
            # Si c'est une BPE, c'est un alignement de la taille du cable
            elif ebp["bp_typelog"] == "BPE" and ebp["bp_statut"] in statut:
                capacite = liste_cable[0]["cb_capafo"]
                dict_alignement[capacite] += 1
        elif len(liste_cable) == 2:
            if ebp["bp_typelog"] == "BPE" and ebp["bp_statut"] in statut:
                # Si c'est une BPE avec deux capacités identiques, c'est un joint droit de la taille du cable
                if liste_cable[0]["cb_capafo"] == liste_cable[1]["cb_capafo"]:
                    if liste_cable[0]["cb_statut"] in statut:
                        dict_joint_droit[liste_cable[0]["cb_capafo"]] += 1
                # Sinon c'est une dérivation de la taille du cable le plus petit
                else:
                    if liste_cable[0]["cb_statut"] in statut:
                        capamin = min(
                            liste_cable[0]["cb_capafo"], liste_cable[1]["cb_capafo"]
                        )
                        dict_raccordement[capamin] += 1
            elif ebp["bp_typelog"] == "PBO" and ebp["bp_statut"] in statut:
                # Si c'est un PBO avec deux capacités de cable différentes, c'est une dérivation du plus petit
                if liste_cable[0]["cb_capafo"] != liste_cable[1]["cb_capafo"]:
                    if liste_cable[0]["cb_statut"] in statut:
                        capamin = min(
                            liste_cable[0]["cb_capafo"], liste_cable[1]["cb_capafo"]
                        )
                        dict_raccordement[capamin] += 1
                # Sinon c'est un piquage en ligne de la taille du cable s'il y a du passage, ou joint droit s'il n'y a pas de passage
                else:
                    if nbpassage > 0:
                        if liste_cable[0]["cb_statut"] in statut:
                            # Si la capa est supérieure à 12, alors on le met dans 6
                            """if liste_cable[0]['cb_capafo'] > 12:
                                dict_piquage[6] += 1
                            else:"""
                            dict_piquage[liste_cable[0]["cb_capafo"]] += 1
                    else:
                        if liste_cable[0]["cb_statut"] in statut:
                            dict_joint_droit[liste_cable[0]["cb_capafo"]] += 1
        elif len(liste_cable) > 2:
            liste_capa = [cable["cb_capafo"] for cable in liste_cable]
            capamax = max(liste_capa)
            nb_capamax = liste_capa.count(capamax)
            if nb_capamax > 1:
                compteur = 0
                for cable in liste_cable:
                    if cable["cb_capafo"] == capamax and compteur < 2:
                        compteur += 1
                        if cable["cb_statut"] in statut and compteur < 2:
                            # S'il y a su passage, c'est du piquage
                            if nbpassage > 0:
                                # Si la capa est supérieure à 12, alors on le met dans 6
                                """if cable['cb_capafo'] > 12:
                                    dict_piquage[6] += 1
                                else:"""
                                dict_piquage[cable["cb_capafo"]] += 1
                            else:
                                dict_joint_droit[cable["cb_capafo"]] += 1
                    elif cable["cb_statut"] in statut:
                        dict_raccordement[cable["cb_capafo"]] += 1
            else:
                compteur = 0
                for cable in liste_cable:
                    if cable["cb_capafo"] == capamax and compteur < 1:
                        compteur += 1
                    elif cable["cb_statut"] in statut:
                        dict_raccordement[cable["cb_capafo"]] += 1
    return [dict_raccordement, dict_piquage, dict_joint_droit, dict_alignement]


def ajouter(couche):
    if not QgsProject.instance().mapLayersByName(couche.name()):
        QgsProject.instance().addMapLayer(couche)


def tete_de_cable(nb_cable):
    jusque_1 = 0
    jusque_3 = 0
    jusque_5 = nb_cable // 5
    reste = nb_cable % 5
    if reste == 0:
        pass
    elif reste == 1:
        jusque_1 = 1
    elif reste < 4:
        jusque_3 = 1
    else:
        jusque_5 += 1
    return jusque_1, jusque_3, jusque_5


def create_union_layer(t_sro, t_nro):
    crs = t_sro.crs().authid()
    t_site = QgsVectorLayer(f"Point?crs={crs}", "t_site", "memory")
    provider = t_site.dataProvider()
    provider.addAttributes([QgsField("st_typlog", QVariant.String)])
    t_site.updateFields()

    # Copie des SRO
    for feat in t_sro.getFeatures():
        print(f"Géométrie SRO : {feat.geometry().asWkt()}")
        new_feat = QgsFeature(t_site.fields())
        new_feat.setGeometry(feat.geometry())
        new_feat["st_typlog"] = "SRO"
        provider.addFeature(new_feat)

    # Copie des NRO
    for feat in t_nro.getFeatures():
        print(f"Géométrie NRO : {feat.geometry().asWkt()}")
        print(f"CRS NRO : {t_nro.crs().authid()}")
        new_feat = QgsFeature(t_site.fields())
        new_feat.setGeometry(feat.geometry())
        new_feat["st_typlog"] = "NRO"
        provider.addFeature(new_feat)

    t_site.updateExtents()
    QgsProject.instance().addMapLayer(t_site)
    return t_site

from .fonctionsGrace123 import lancement_123
from .fonctionsGraceMCR import lancement_MCR


def chiffrage_cd39(dlg, openpyxl):
    lot = dlg.lot.currentText()
    if lot in ['1 - 2', '3']:
        print('ok lancement')
        lancement_123(dlg.enregistrer.filePath(), lot, dlg.transport.isChecked(), openpyxl)
    elif lot in ['MCR']:
        lancement_MCR(dlg.enregistrer.filePath(), lot, dlg.transport.isChecked(), openpyxl)

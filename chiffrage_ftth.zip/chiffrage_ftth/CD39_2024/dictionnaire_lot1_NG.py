from math import ceil
import re
from qgis.core import Qgis

VERSION_QGIS = int(Qgis.QGIS_VERSION.split("-")[0].split(".")[1])


def remplir_dictionnaire_1_NG(
    transport, t_cable, t_ptech, t_ebp, t_cheminement, t_adresse, t_site, statut
):
    dict_couche = {
        "t_cable": t_cable,
        "t_ptech": t_ptech,
        "t_ebp": t_ebp,
        "t_cheminement": t_cheminement,
        "t_adresse": t_adresse,
        "t_site": t_site,
    }
    # On récupère le champ st_typelog
    field_names = [field.name() for field in t_site.fields()]
    l_st_typelog = ["st_typlog", "st_typelog"]
    # Vérification de l'existence du champ
    for typelog in l_st_typelog:
        if typelog in field_names:
            st_typelog = typelog

    dict_article = {}
    dict_article["AC - 1.1"] = 1
    # Fourniture Poteaux créés en bois
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and TYPE_STRUC= 'APPUI' and PROPRIETAI = 'CD39' and pt_avct = 'C' and (pt_nature is null or pt_nature = 'PBOI') "
    )
    dict_article["AC - 7.5.1.3"] = t_ptech.selectedFeatureCount()

    # Fourniture Poteaux créés en metal
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and TYPE_STRUC= 'APPUI' and PROPRIETAI = 'CD39' and pt_avct = 'C' and (pt_nature = 'PMET' or pt_nature = 'PIND')"
    )
    dict_article["AC - 7.5.4.1"] = t_ptech.selectedFeatureCount()

    # Pose poteaux bois
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and TYPE_STRUC= 'APPUI' and PROPRIETAI = 'CD39' and pt_avct = 'C' and (pt_nature is null or pt_nature = 'PBOI')"
    )
    dict_article["AC - 7.5.6.1"] = t_ptech.selectedFeatureCount()
    # Pose poteaux METAL
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and TYPE_STRUC= 'APPUI' and PROPRIETAI = 'CD39' and pt_avct = 'C' and (pt_nature = 'PMET' or pt_nature ='PIND')"
    )
    dict_article["AC - 7.5.6.2"] = t_ptech.selectedFeatureCount()
    # Armement
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and TYPE_STRUC= 'APPUI' and (PROPRIETAI <> 'ENEDIS')"
    )
    dict_article["AC - 7.5.14.1"] = t_ptech.selectedFeatureCount()
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and TYPE_STRUC= 'APPUI' and (PROPRIETAI = 'ENEDIS')"
    )
    dict_article["AC - 7.5.14.3"] = t_ptech.selectedFeatureCount()

    # Les longueurs de cable
    if transport:
        dict_article["AC - 2.1.6"] = calcul_lineaire_cable(
            dict_couche, "SOUT", 36, statut
        )
        dict_article["AC - 2.1.8"] = calcul_lineaire_cable(
            dict_couche, "SOUT", 48, statut
        )
        dict_article["AC - 2.1.10"] = calcul_lineaire_cable(
            dict_couche, "SOUT", 72, statut
        )
        dict_article["AC - 2.1.16"] = calcul_lineaire_cable(
            dict_couche, "SOUT", 144, statut
        )
        dict_article["AC - 2.1.17"] = calcul_lineaire_cable(
            dict_couche, "SOUT", 288, statut
        )
        dict_article["AC - 2.1.18"] = calcul_lineaire_cable(
            dict_couche, "SOUT", 432, statut
        )
        dict_article["AC - 2.1.19"] = calcul_lineaire_cable(
            dict_couche, "SOUT", 576, statut
        )
        dict_article["AC - 2.1.20"] = calcul_lineaire_cable(
            dict_couche, "SOUT", 720, statut
        )
        # AERIEN
        dict_article["AC - 2.2.6"] = calcul_lineaire_cable(
            dict_couche, "AER", 36, statut
        )
        dict_article["AC - 2.2.8"] = calcul_lineaire_cable(
            dict_couche, "AER", 48, statut
        )
        dict_article["AC - 2.2.10"] = calcul_lineaire_cable(
            dict_couche, "AER", 72, statut
        )
        dict_article["AC - 2.2.16"] = calcul_lineaire_cable(
            dict_couche, "AER", 144, statut
        )
    else:
        # Calcul des longueurs de cable par capa et par support en modulo 6
        # CABL100:
        dict_article["AC - 2.1.1"] = calcul_lineaire_cable(
            dict_couche, "SOUT", 6, statut
        )
        dict_article["AC - 2.1.2"] = calcul_lineaire_cable(
            dict_couche, "SOUT", 12, statut
        )
        dict_article["AC - 2.1.3"] = calcul_lineaire_cable(
            dict_couche, "SOUT", 24, statut
        )
        dict_article["AC - 2.1.5"] = calcul_lineaire_cable(
            dict_couche, "SOUT", 36, statut
        )
        dict_article["AC - 2.1.7"] = calcul_lineaire_cable(
            dict_couche, "SOUT", 48, statut
        )
        dict_article["AC - 2.1.9"] = calcul_lineaire_cable(
            dict_couche, "SOUT", 72, statut
        )
        dict_article["AC - 2.1.15"] = calcul_lineaire_cable(
            dict_couche, "SOUT", 144, statut
        )
        dict_article["AC - 2.1.17"] = calcul_lineaire_cable(
            dict_couche, "SOUT", 288, statut
        )
        dict_article["AC - 2.1.18"] = calcul_lineaire_cable(
            dict_couche, "SOUT", 432, statut
        )
        dict_article["AC - 2.1.19"] = calcul_lineaire_cable(
            dict_couche, "SOUT", 576, statut
        )
        dict_article["AC - 2.1.20"] = calcul_lineaire_cable(
            dict_couche, "SOUT", 720, statut
        )
        # CABL300:[6]
        dict_article["AC - 2.2.1"] = calcul_lineaire_cable(
            dict_couche, "AER", 6, statut
        ) + calcul_lineaire_cable(dict_couche, "FAC", 6, statut)
        dict_article["AC - 2.2.2"] = calcul_lineaire_cable(
            dict_couche, "AER", 12, statut
        ) + calcul_lineaire_cable(dict_couche, "FAC", 12, statut)
        dict_article["AC - 2.2.3"] = calcul_lineaire_cable(
            dict_couche, "AER", 24, statut
        ) + calcul_lineaire_cable(dict_couche, "FAC", 24, statut)
        dict_article["AC - 2.2.5"] = calcul_lineaire_cable(
            dict_couche, "AER", 36, statut
        ) + calcul_lineaire_cable(dict_couche, "FAC", 36, statut)
        dict_article["AC - 2.2.7"] = calcul_lineaire_cable(
            dict_couche, "AER", 48, statut
        ) + calcul_lineaire_cable(dict_couche, "FAC", 48, statut)
        dict_article["AC - 2.2.9"] = calcul_lineaire_cable(
            dict_couche, "AER", 72, statut
        ) + calcul_lineaire_cable(dict_couche, "FAC", 72, statut)
        dict_article["AC - 2.2.15"] = calcul_lineaire_cable(
            dict_couche, "AER", 144, statut
        ) + calcul_lineaire_cable(dict_couche, "FAC", 144, statut)
        # Immeuble
        dict_article["AC - 2.5.1"] = calcul_lineaire_cable(
            dict_couche, "IMB", 6, statut
        )
        dict_article["AC - 2.5.2"] = calcul_lineaire_cable(
            dict_couche, "IMB", 12, statut
        )
        dict_article["AC - 2.5.3"] = calcul_lineaire_cable(
            dict_couche, "IMB", 24, statut
        )
        dict_article["AC - 2.5.5"] = calcul_lineaire_cable(
            dict_couche, "IMB", 36, statut
        )
        dict_article["AC - 2.5.7"] = calcul_lineaire_cable(
            dict_couche, "IMB", 48, statut
        )
        dict_article["AC - 2.5.9"] = calcul_lineaire_cable(
            dict_couche, "IMB", 72, statut
        )
        dict_article["AC - 2.5.15"] = calcul_lineaire_cable(
            dict_couche, "IMB", 144, statut
        )
        # CABL300:[6]
        dict_article["AC - 2.7.1"] = calcul_lineaire_cable(
            dict_couche, "FAC", 6, statut
        )
        dict_article["AC - 2.7.2"] = calcul_lineaire_cable(
            dict_couche, "FAC", 12, statut
        )
        dict_article["AC - 2.7.3"] = calcul_lineaire_cable(
            dict_couche, "FAC", 24, statut
        )
        dict_article["AC - 2.7.5"] = calcul_lineaire_cable(
            dict_couche, "FAC", 36, statut
        )
        dict_article["AC - 2.7.7"] = calcul_lineaire_cable(
            dict_couche, "FAC", 48, statut
        )

    # Comptage des BPE
    # BPE en chambre
    dict_article["AC - 3.1.1"] = compte_bpe(
        t_ebp, t_ptech, t_adresse, t_cable, 6, "CHAMBRE", statut
    )
    dict_article["AC - 3.1.2"] = compte_bpe(
        t_ebp, t_ptech, t_adresse, t_cable, 12, "CHAMBRE", statut
    )
    dict_article["AC - 3.1.3"] = compte_bpe(
        t_ebp, t_ptech, t_adresse, t_cable, 24, "CHAMBRE", statut
    )
    dict_article["AC - 3.1.4"] = compte_bpe(
        t_ebp, t_ptech, t_adresse, t_cable, 36, "CHAMBRE", statut
    )
    dict_article["AC - 3.1.5"] = compte_bpe(
        t_ebp, t_ptech, t_adresse, t_cable, 48, "CHAMBRE", statut
    )
    dict_article["AC - 3.1.6"] = compte_bpe(
        t_ebp, t_ptech, t_adresse, t_cable, 72, "CHAMBRE", statut
    )
    dict_article["AC - 3.1.7"] = compte_bpe(
        t_ebp, t_ptech, t_adresse, t_cable, 96, "CHAMBRE", statut
    )
    dict_article["AC - 3.1.8"] = compte_bpe(
        t_ebp, t_ptech, t_adresse, t_cable, 108, "CHAMBRE", statut
    )
    dict_article["AC - 3.1.9"] = compte_bpe(
        t_ebp, t_ptech, t_adresse, t_cable, 144, "CHAMBRE", statut
    )
    dict_article["AC - 3.1.10"] = compte_bpe(
        t_ebp, t_ptech, t_adresse, t_cable, 288, "CHAMBRE", statut
    )
    dict_article["AC - 3.1.11"] = compte_bpe(
        t_ebp, t_ptech, t_adresse, t_cable, 432, "CHAMBRE", statut
    )
    dict_article["AC - 3.1.12"] = compte_bpe(
        t_ebp, t_ptech, t_adresse, t_cable, 576, "CHAMBRE", statut
    )
    dict_article["AC - 3.1.13"] = compte_bpe(
        t_ebp, t_ptech, t_adresse, t_cable, 720, "CHAMBRE", statut
    )
    dict_article["AC - 4.1.1"] = compte_pbo(
        t_ebp, t_ptech, t_adresse, t_cable, 6, "CHAMBRE", statut
    )
    dict_article["AC - 4.1.3"] = compte_pbo(
        t_ebp, t_ptech, t_adresse, t_cable, 12, "CHAMBRE", statut
    )
    # BPE sur facade
    dict_article["AC - 3.2.1"] = (
        compte_bpe(t_ebp, t_ptech, t_adresse, t_cable, 6, "FACADE", statut)
        + compte_bpe(t_ebp, t_ptech, t_adresse, t_cable, 6, "ANCRAGE FACADE", statut)
        + compte_bpe(t_ebp, t_ptech, t_adresse, t_cable, 6, "POTELET", statut)
    )
    dict_article["AC - 3.2.2"] = (
        compte_bpe(t_ebp, t_ptech, t_adresse, t_cable, 12, "FACADE", statut)
        + compte_bpe(t_ebp, t_ptech, t_adresse, t_cable, 12, "ANCRAGE FACADE", statut)
        + compte_bpe(t_ebp, t_ptech, t_adresse, t_cable, 12, "POTELET", statut)
    )
    dict_article["AC - 3.2.3"] = (
        compte_bpe(t_ebp, t_ptech, t_adresse, t_cable, 24, "FACADE", statut)
        + compte_bpe(t_ebp, t_ptech, t_adresse, t_cable, 24, "ANCRAGE FACADE", statut)
        + compte_bpe(t_ebp, t_ptech, t_adresse, t_cable, 24, "POTELET", statut)
    )
    dict_article["AC - 3.2.4"] = (
        compte_bpe(t_ebp, t_ptech, t_adresse, t_cable, 36, "FACADE", statut)
        + compte_bpe(t_ebp, t_ptech, t_adresse, t_cable, 36, "ANCRAGE FACADE", statut)
        + compte_bpe(t_ebp, t_ptech, t_adresse, t_cable, 36, "POTELET", statut)
    )
    dict_article["AC - 3.2.5"] = (
        compte_bpe(t_ebp, t_ptech, t_adresse, t_cable, 48, "FACADE", statut)
        + compte_bpe(t_ebp, t_ptech, t_adresse, t_cable, 48, "ANCRAGE FACADE", statut)
        + compte_bpe(t_ebp, t_ptech, t_adresse, t_cable, 48, "POTELET", statut)
    )
    dict_article["AC - 3.2.6"] = (
        compte_bpe(t_ebp, t_ptech, t_adresse, t_cable, 72, "FACADE", statut)
        + compte_bpe(t_ebp, t_ptech, t_adresse, t_cable, 72, "ANCRAGE FACADE", statut)
        + compte_bpe(t_ebp, t_ptech, t_adresse, t_cable, 72, "POTELET", statut)
    )
    dict_article["AC - 3.2.7"] = (
        compte_bpe(t_ebp, t_ptech, t_adresse, t_cable, 96, "FACADE", statut)
        + compte_bpe(t_ebp, t_ptech, t_adresse, t_cable, 96, "ANCRAGE FACADE", statut)
        + compte_bpe(t_ebp, t_ptech, t_adresse, t_cable, 96, "POTELET", statut)
    )
    dict_article["AC - 3.2.8"] = (
        compte_bpe(t_ebp, t_ptech, t_adresse, t_cable, 108, "FACADE", statut)
        + compte_bpe(t_ebp, t_ptech, t_adresse, t_cable, 108, "ANCRAGE FACADE", statut)
        + compte_bpe(t_ebp, t_ptech, t_adresse, t_cable, 108, "POTELET", statut)
    )
    dict_article["AC - 3.2.9"] = (
        compte_bpe(t_ebp, t_ptech, t_adresse, t_cable, 144, "FACADE", statut)
        + compte_bpe(t_ebp, t_ptech, t_adresse, t_cable, 144, "ANCRAGE FACADE", statut)
        + compte_bpe(t_ebp, t_ptech, t_adresse, t_cable, 144, "POTELET", statut)
    )
    dict_article["AC - 4.2.1"] = (
        compte_pbo(t_ebp, t_ptech, t_adresse, t_cable, 6, "FACADE", statut)
        + compte_pbo(t_ebp, t_ptech, t_adresse, t_cable, 6, "ANCRAGE FACADE", statut)
        + compte_pbo(t_ebp, t_ptech, t_adresse, t_cable, 6, "POTELET", statut)
    )
    dict_article["AC - 4.2.3"] = (
        compte_pbo(t_ebp, t_ptech, t_adresse, t_cable, 12, "FACADE", statut)
        + compte_pbo(t_ebp, t_ptech, t_adresse, t_cable, 12, "ANCRAGE FACADE", statut)
        + compte_pbo(t_ebp, t_ptech, t_adresse, t_cable, 12, "POTELET", statut)
    )
    # BPE sur POTEAU
    dict_article["AC - 3.3.1"] = compte_bpe(
        t_ebp, t_ptech, t_adresse, t_cable, 6, "APPUI", statut
    )
    dict_article["AC - 3.3.2"] = compte_bpe(
        t_ebp, t_ptech, t_adresse, t_cable, 12, "APPUI", statut
    )
    dict_article["AC - 3.3.3"] = compte_bpe(
        t_ebp, t_ptech, t_adresse, t_cable, 24, "APPUI", statut
    )
    dict_article["AC - 3.3.4"] = compte_bpe(
        t_ebp, t_ptech, t_adresse, t_cable, 36, "APPUI", statut
    )
    dict_article["AC - 3.3.5"] = compte_bpe(
        t_ebp, t_ptech, t_adresse, t_cable, 48, "APPUI", statut
    )
    dict_article["AC - 3.3.6"] = compte_bpe(
        t_ebp, t_ptech, t_adresse, t_cable, 72, "APPUI", statut
    )
    dict_article["AC - 3.3.7"] = compte_bpe(
        t_ebp, t_ptech, t_adresse, t_cable, 96, "APPUI", statut
    )
    dict_article["AC - 3.3.8"] = compte_bpe(
        t_ebp, t_ptech, t_adresse, t_cable, 108, "APPUI", statut
    )
    dict_article["AC - 3.3.9"] = compte_bpe(
        t_ebp, t_ptech, t_adresse, t_cable, 144, "APPUI", statut
    )
    dict_article["AC - 4.3.1"] = compte_pbo(
        t_ebp, t_ptech, t_adresse, t_cable, 6, "APPUI", statut
    )
    dict_article["AC - 4.3.3"] = compte_pbo(
        t_ebp, t_ptech, t_adresse, t_cable, 12, "APPUI", statut
    )
    # BPE sur IMMEUBLE
    if not transport:
        dict_article["AC - 3.4.1"] = compte_bpe(
            t_ebp, t_ptech, t_adresse, t_cable, 6, "IMMEUBLE", statut
        )
        dict_article["AC - 3.4.2"] = compte_bpe(
            t_ebp, t_ptech, t_adresse, t_cable, 12, "IMMEUBLE", statut
        )
        dict_article["AC - 3.4.3"] = compte_bpe(
            t_ebp, t_ptech, t_adresse, t_cable, 24, "IMMEUBLE", statut
        )
        dict_article["AC - 3.4.4"] = compte_bpe(
            t_ebp, t_ptech, t_adresse, t_cable, 36, "IMMEUBLE", statut
        )
        dict_article["AC - 3.4.5"] = compte_bpe(
            t_ebp, t_ptech, t_adresse, t_cable, 48, "IMMEUBLE", statut
        )
        dict_article["AC - 3.4.6"] = compte_bpe(
            t_ebp, t_ptech, t_adresse, t_cable, 72, "IMMEUBLE", statut
        )
        dict_article["AC - 3.4.7"] = compte_bpe(
            t_ebp, t_ptech, t_adresse, t_cable, 96, "IMMEUBLE", statut
        )
        dict_article["AC - 3.4.8"] = compte_bpe(
            t_ebp, t_ptech, t_adresse, t_cable, 108, "IMMEUBLE", statut
        )
        dict_article["AC - 3.4.9"] = compte_bpe(
            t_ebp, t_ptech, t_adresse, t_cable, 144, "IMMEUBLE", statut
        )
        dict_article["AC - 4.4.1"] = compte_pbo(
            t_ebp, t_ptech, t_adresse, t_cable, 6, "IMMEUBLE", statut
        )
        dict_article["AC - 4.4.3"] = compte_pbo(
            t_ebp, t_ptech, t_adresse, t_cable, 12, "IMMEUBLE", statut
        )
    dict_article["AC - 3"] = compte_boites_sans_support(
        t_ebp, t_ptech, t_adresse, transport, statut
    )
    # Comptage des raccordements et piquage
    result = compte_raccordement(t_cable, t_ebp, statut)
    dict_derivation = result[0]
    dict_piquage = result[1]
    dict_joint_droit = result[2]
    dict_alignement = result[3]
    # RACC100
    dict_article["AC - 6.1.1"] = dict_joint_droit[6]
    dict_article["AC - 6.1.2"] = dict_joint_droit[12]
    dict_article["AC - 6.1.3"] = dict_joint_droit[24]
    dict_article["AC - 6.1.4"] = dict_joint_droit[36]
    dict_article["AC - 6.1.5"] = dict_joint_droit[48]
    dict_article["AC - 6.1.6"] = dict_joint_droit[72]
    dict_article["AC - 6.1.9"] = dict_joint_droit[144]
    dict_article["AC - 6.1.10"] = dict_joint_droit[288]
    dict_article["AC - 6.1.11"] = dict_joint_droit[432]
    dict_article["AC - 6.1.12"] = dict_joint_droit[576]
    dict_article["AC - 6.1.13"] = dict_joint_droit[720]
    # RACC200
    dict_article["AC - 6.1.14"] = dict_derivation[6]
    dict_article["AC - 6.1.15"] = dict_derivation[12]
    dict_article["AC - 6.1.16"] = dict_derivation[24]
    dict_article["AC - 6.1.17"] = dict_derivation[36]
    dict_article["AC - 6.1.18"] = dict_derivation[48]
    dict_article["AC - 6.1.19"] = dict_derivation[72]
    dict_article["AC - 6.1.22"] = dict_derivation[144]
    dict_article["AC - 6.1.23"] = dict_derivation[288]
    dict_article["AC - 6.1.24"] = dict_derivation[432]
    dict_article["AC - 6.1.25"] = dict_derivation[576]
    dict_article["AC - 6.1.26"] = dict_derivation[720]
    # RACC300
    dict_article["AC - 6.2.1"] = dict_piquage[6]
    dict_article["AC - 6.2.2"] = dict_piquage[12]
    dict_article["AC - 6.2.3"] = dict_piquage[24]
    dict_article["AC - 6.2.4"] = dict_piquage[36]
    dict_article["AC - 6.2.5"] = dict_piquage[48]
    dict_article["AC - 6.2.6"] = dict_piquage[72]
    dict_article["AC - 6.2.9"] = dict_piquage[144]
    dict_article["AC - 6.2.10"] = dict_piquage[288]
    dict_article["AC - 6.2.11"] = dict_piquage[432]
    dict_article["AC - 6.2.12"] = dict_piquage[576]

    # Raccordement optique des modules optiques
    # AC - 5.3
    site_name = t_site.name()
    t_cable.removeSelection()
    t_cable.selectByExpression(
        f"cb_statut = '{statut}' and (intersects(buffer(start_point($geometry),0.1), aggregate( '{site_name}','collect',$geometry,{st_typelog} in ('NRO', 'SRO'))) or intersects(buffer(end_point($geometry),0.1), aggregate( '{site_name}','collect',$geometry,{st_typelog} in ('NRO', 'SRO'))))"
    )
    print(
        f"cb_statut = '{statut}' and (intersects(buffer(start_point($geometry),0.1), aggregate( '{site_name}','collect',$geometry,{st_typelog} in ('NRO', 'SRO'))) or intersects(buffer(end_point($geometry),0.1), aggregate( '{site_name}','collect',$geometry,{st_typelog} in ('NRO', 'SRO'))))"
    )
    nb36 = 0
    nb48 = 0
    nb72 = 0
    nb144 = 0
    for cable in t_cable.selectedFeatures():
        if int(re.findall("\d+", str(cable["cb_capafo"]))[0]) <= 36:
            nb36 += 1
        elif int(re.findall("\d+", str(cable["cb_capafo"]))[0]) == 48:
            nb48 += 1
        elif int(re.findall("\d+", str(cable["cb_capafo"]))[0]) == 72:
            nb72 += 1
        elif int(re.findall("\d+", str(cable["cb_capafo"]))[0]) >= 144:
            nb144 += int(re.findall("\d+", str(cable["cb_capafo"]))[0]) // 144
    dict_article["AC - 6.3.1"] = nb36
    dict_article["AC - 6.3.2"] = nb48
    dict_article["AC - 6.3.3"] = nb72
    dict_article["AC - 6.3.4"] = nb144

    # Les mesures
    t_ebp.selectByExpression(
        f"bp_typelog like 'PB%' and bp_typephy = 'B006' and bp_statut = '{statut}'"
    )
    dict_article["AC - 8.3.1"] = t_ebp.selectedFeatureCount()
    t_ebp.selectByExpression(
        f"bp_typelog like 'PB%' and bp_typephy = 'B012' and bp_statut = '{statut}'"
    )
    dict_article["AC - 8.3.2"] = t_ebp.selectedFeatureCount()
    # Chambre à créer
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and TYPE_STRUC = 'CHAMBRE' and pt_avct = 'C' and pt_nature = 'L0T'"
    )
    dict_article["AC - 7.6.1.1"] = t_ptech.selectedFeatureCount()
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and TYPE_STRUC = 'CHAMBRE' and pt_avct = 'C' and pt_nature = 'L1T'"
    )
    dict_article["AC - 7.6.1.3"] = t_ptech.selectedFeatureCount()
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and TYPE_STRUC = 'CHAMBRE' and pt_avct = 'C' and pt_nature = 'L2T'"
    )
    dict_article["AC - 7.6.1.5"] = t_ptech.selectedFeatureCount()
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and TYPE_STRUC = 'CHAMBRE' and pt_avct = 'C' and pt_nature = 'L3T'"
    )
    dict_article["AC - 7.6.1.7"] = t_ptech.selectedFeatureCount()
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and TYPE_STRUC = 'CHAMBRE' and pt_avct = 'C' and pt_nature = 'L4T'"
    )
    dict_article["AC - 7.6.1.9"] = t_ptech.selectedFeatureCount()
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and TYPE_STRUC = 'CHAMBRE' and pt_avct = 'C' and pt_nature = 'L5T'"
    )
    dict_article["AC - 7.6.1.10"] = t_ptech.selectedFeatureCount()
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and TYPE_STRUC = 'CHAMBRE' and pt_avct = 'C' and pt_nature = 'L6T'"
    )
    dict_article["AC - 7.6.1.11"] = t_ptech.selectedFeatureCount()
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and TYPE_STRUC = 'CHAMBRE' and pt_avct = 'C' and pt_nature = 'L1C'"
    )
    dict_article["AC - 7.6.1.12"] = t_ptech.selectedFeatureCount()
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and TYPE_STRUC = 'CHAMBRE' and pt_avct = 'C' and pt_nature = 'L2C'"
    )
    dict_article["AC - 7.6.1.13"] = t_ptech.selectedFeatureCount()
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and TYPE_STRUC = 'CHAMBRE' and pt_avct = 'C' and pt_nature = 'K1C'"
    )
    dict_article["AC - 7.6.1.14"] = t_ptech.selectedFeatureCount()
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and TYPE_STRUC = 'CHAMBRE' and pt_avct = 'C' and pt_nature = 'K2C'"
    )
    dict_article["AC - 7.6.1.15"] = t_ptech.selectedFeatureCount()
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and TYPE_STRUC = 'CHAMBRE' and pt_avct = 'C' and pt_nature = 'K3C'"
    )
    dict_article["AC - 7.6.1.16"] = t_ptech.selectedFeatureCount()
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and TYPE_STRUC = 'CHAMBRE' and pt_avct = 'C' and pt_nature = 'L3C'"
    )
    dict_article["AV1 - 3.2"] = t_ptech.selectedFeatureCount()
    # Tranchée tradi
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and (cm_remblai like '%TT1' or cm_remblai in ('Tradi 01','TRADI 01'))"
    )
    dict_article["AC - 7.3.1.1"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and (cm_remblai like '%TT2' or cm_remblai like '%T02' or cm_remblai in ('Tradi 02', 'TRADI 02'))"
    )
    dict_article["AC - 7.3.1.2"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and (cm_remblai like '%TT3' or cm_remblai in ('Tradi 03', 'TRADI 03'))"
    )
    dict_article["AC - 7.3.1.3"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and (cm_remblai like '%TT4' or cm_remblai in ('Tradi 04', 'TRADI 04'))"
    )
    dict_article["AC - 7.3.1.4"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and (cm_remblai like '%TT5' or cm_remblai in ('Tradi 05', 'TRADI 05'))"
    )
    dict_article["AC - 7.3.1.5"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and (cm_remblai like '%TT6' or cm_remblai in ('Tradi 06', 'TRADI 06'))"
    )
    dict_article["AC - 7.3.1.6"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and (cm_remblai like '%TT7' or cm_remblai in ('Tradi 07', 'TRADI 07'))"
    )
    dict_article["AC - 7.3.1.7"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and (cm_remblai like '%TT8' or cm_remblai in ('Tradi 08', 'TRADI 08'))"
    )
    dict_article["AC - 7.3.1.8"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and (cm_remblai like '%TT9' or cm_remblai in ('Tradi 09', 'TRADI 09'))"
    )
    dict_article["AC - 7.3.1.9"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and (cm_remblai like '%TT10' or cm_remblai in ('Tradi 10', 'TRADI 10'))"
    )
    dict_article["AC - 7.3.1.10"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and (cm_remblai like '%TT11' or cm_remblai like 'Tradi 11')"
    )
    dict_article["AC - 7.3.1.11"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    # Tranchée meca
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and (cm_remblai like '%TC1' or cm_remblai like 'Meca 01')"
    )
    dict_article["AC - 7.3.2.1"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and (cm_remblai like '%TC2' or cm_remblai like 'Meca 02')"
    )
    dict_article["AC - 7.3.2.2"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and (cm_remblai like '%TC3' or cm_remblai like 'Meca 03')"
    )
    dict_article["AC - 7.3.2.3"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and (cm_remblai like '%TC4' or cm_remblai like 'Meca 04')"
    )
    dict_article["AC - 7.3.2.4"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and (cm_remblai like '%TC5' or cm_remblai like 'Meca 05')"
    )
    dict_article["AC - 7.3.2.5"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and (cm_remblai like '%TC6' or cm_remblai like 'Meca 06')"
    )
    dict_article["AC - 7.3.2.6"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and (cm_remblai like '%TC7' or cm_remblai like 'Meca 07')"
    )
    dict_article["AC - 7.3.2.7"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and (cm_remblai like '%TC8' or cm_remblai like 'Meca 08')"
    )
    dict_article["AC - 7.3.2.8"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and (cm_remblai like '%TC9' or cm_remblai like 'Meca 09')"
    )
    dict_article["AC - 7.3.2.9"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and (cm_remblai like '%TC10' or cm_remblai like 'Meca 10')"
    )
    dict_article["AC - 7.3.2.10"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and (cm_remblai like '%SPEC1' or cm_remblai like 'Spec 10')"
    )
    dict_article["AC - 7.3.2.17"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and (cm_remblai like '%SPEC3' or cm_remblai like 'Spec 10')"
    )
    dict_article["AC - 7.3.2.18"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    # Avenant
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and cm_remblai like '%TT1_D'"
    )
    dict_article["AV1 - 1.1.1"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and cm_remblai like '%TT2_D'"
    )
    dict_article["AV1 - 1.1.2"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and cm_remblai like '%TT3_D'"
    )
    dict_article["AV1 - 1.1.3"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and cm_remblai like '%TT4_D'"
    )
    dict_article["AV1 - 1.1.4"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and cm_remblai like '%TT5_D'"
    )
    dict_article["AV1 - 1.1.5"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and cm_remblai like '%TT6_D'"
    )
    dict_article["AV1 - 1.1.6"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and (cm_remblai like '%TT7_D'  or cm_remblai like '%TD07D' or cm_remblai like '%T07D')"
    )
    dict_article["AV1 - 1.1.7"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and cm_remblai like '%TT8_D'"
    )
    dict_article["AV1 - 1.1.8"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and cm_remblai like '%TT9_D'"
    )
    dict_article["AV1 - 1.1.9"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and cm_remblai like '%TT10_D'"
    )
    dict_article["AV1 - 1.1.10"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and cm_remblai like '%TT11_D'"
    )
    dict_article["AV1 - 1.1.11"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and (cm_remblai like '%TT12_D' or cm_remblai like '%T12D')"
    )
    dict_article["AV1 - 1.1.12"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and cm_remblai like '%TT15_D'"
    )
    dict_article["AV1 - 1.1.15"] = sum(
        [cm["cm_long"] for cm in t_cheminement.selectedFeatures()]
    )
    return dict_article


def calcul_lineaire_cable(dict_couche, pose, capacite, statut="REC"):
    t_cable = dict_couche["t_cable"]
    t_cheminement = dict_couche["t_cheminement"]
    # t_cable.selectByExpression("TYPE is NULL")
    if False:  # t_cable.selectedFeatureCount() == 0:
        longueur_cable(t_cable, pose, capacite, statut)
    else:
        # Calcul avec les cheminements
        t_cable.selectByExpression(
            f"regexp_substr( cb_capafo, '\\\\d+') = {capacite} and cb_statut = '{statut}'"
        )
        longueur = 0
        print("selection", capacite, t_cable.selectedFeatureCount())
        for cable in t_cable.selectedFeatures():
            aerien = False
            immeuble = False
            conduite = False
            t_cheminement.selectByExpression(
                f"within($geometry, buffer(geom_from_wkt('{cable.geometry().asWkt()}'), 0.3))"
            )
            for cheminement in t_cheminement.selectedFeatures():
                if cheminement["cm_typ_imp"] in ["AERIEN", "0", "1", "2", 0, 1, 2]:
                    aerien = True
                elif cheminement["cm_typ_imp"] in ["IMMEUBLE", "3", 3]:
                    immeuble = True
                elif cheminement["cm_typ_imp"] in ["CONDUITE", "7", 7]:
                    conduite = True
            if aerien:
                if pose in ("AER"):
                    longueur += float(str(cable["cb_lgreel"]).replace(",", "."))
            else:
                if immeuble and not conduite:
                    if pose in ("IMB"):
                        longueur += float(str(cable["cb_lgreel"]).replace(",", "."))
                else:
                    if pose in ("SOUT"):
                        longueur += float(str(cable["cb_lgreel"]).replace(",", "."))
        return longueur


def compte_bpe(t_ebp, t_ptech, t_adresse, t_cable, capacite, pose, statut="REC"):
    compt = 0
    # On compte les BPE selon le plus gros cable
    t_ebp.selectByExpression(
        f"bp_typelog in ('BPE', 'PEC', 'PEP') and bp_statut = '{statut}'"
    )
    for ebp in t_ebp.selectedFeatures():
        capamax = int(re.findall("\d+", ebp["bp_typephy"])[0])
        if capamax == capacite:
            t_ptech.selectByExpression(
                f"intersects(buffer($geometry, 0.2),  geom_from_wkt('{ebp.geometry().asWkt()}'))"
            )
            for ptech in t_ptech.selectedFeatures():
                if ptech["TYPE_STRUC"] == pose:
                    compt += 1
                    break
            if t_ptech.selectedFeatureCount() == 0 and pose == "IMMEUBLE":
                t_adresse.selectByExpression(
                    f"intersects(buffer($geometry, 0.2),  geom_from_wkt('{ebp.geometry().asWkt()}'))"
                )
                if t_adresse.selectedFeatureCount() > 0:
                    compt += 1
    return compt


def compte_pbo(t_ebp, t_ptech, t_adresse, t_cable, capacite, pose, statut="REC"):
    compt = 0
    # On compte les PBO selon les prises
    if capacite == 6:
        t_ebp.selectByExpression(
            f"bp_typelog like 'PB%' and bp_typephy = 'B006' and bp_statut = '{statut}'"
        )
    elif capacite == 12:
        t_ebp.selectByExpression(
            f"bp_typelog like 'PB%' and bp_typephy = 'B012' and bp_statut = '{statut}'"
        )
    else:
        t_ebp.removeSelection()
    for ebp in t_ebp.selectedFeatures():
        t_ptech.selectByExpression(
            f"intersects(buffer($geometry, 0.2),  geom_from_wkt('{ebp.geometry().asWkt()}'))"
        )
        for ptech in t_ptech.selectedFeatures():
            if ptech["TYPE_STRUC"] == pose:
                compt += 1
                break
        if t_ptech.selectedFeatureCount() == 0 and pose == "IMMEUBLE":
            t_adresse.selectByExpression(
                f"intersects(buffer($geometry, 0.2),  geom_from_wkt('{ebp.geometry().asWkt()}'))"
            )
            if t_adresse.selectedFeatureCount() > 0:
                compt += 1
        elif t_ptech.selectedFeatureCount() == 0:
            print(ebp["BPE_NOM"], "pas de ptech")
    return compt


def compte_raccordement(t_cable, t_ebp, statut):
    # On initialise les dictionnaires
    dict_raccordement = {}
    dict_piquage = {}
    dict_joint_droit = {}
    dict_alignement = {}

    capa = [6, 12, 24, 36, 48, 72, 144, 288, 432, 576, 720]
    for elem in capa:
        dict_piquage[elem] = 0
        dict_raccordement[elem] = 0
        dict_joint_droit[elem] = 0
        dict_alignement[elem] = 0

    t_ebp.selectAll()
    for ebp in t_ebp.selectedFeatures():
        liste_cable = []
        t_cable.selectByExpression(
            f"EQ_A = '{ebp['BPE_NOM']}' OR EQ_B = '{ebp['BPE_NOM']}' or EQ_A = '{ebp['PBE_CODE']}' or EQ_B = '{ebp['PBE_CODE']}'"
        )
        for cable in t_cable.selectedFeatures():
            liste_cable.append(cable)
        # S'il n'y a qu'un seul cable
        if len(liste_cable) <= 1:
            # Si sur une boite il n'y a qu'un seul cable sortant, alors on considère que c'est un alignement
            if ebp["bp_typelog"] in ["BPE", "PEC", "PEP"]:
                for cable in liste_cable:
                    if cable["cb_statut"] == statut:
                        dict_alignement[
                            int(re.findall("\d+", str(cable["cb_capafo"]))[0])
                        ] += 1
            else:
                # Sinon c'est une fin cable que l'on compte en piquage de la taille du boitier
                for cable in liste_cable:
                    if cable["cb_statut"] == statut:
                        capa = 6
                        if ebp["bp_typephy"] == "B012":
                            capa = 12
                        dict_piquage[capa] += 1
        # S'il y a deux cables
        elif len(liste_cable) == 2:
            print(
                liste_cable[0]["CODE"],
                liste_cable[0]["cb_capafo"],
                re.findall("\d+", str(liste_cable[0]["cb_capafo"])),
            )
            # Si les cables ont la même capa, c'est un joint droit
            if (
                re.findall("\d+", str(liste_cable[0]["cb_capafo"]))[0]
                == re.findall("\d+", str(liste_cable[1]["cb_capafo"]))[0]
            ):
                # Si c'est une BPE
                if ebp["bp_typelog"] in ["BPE", "PEC", "PEP"]:
                    if liste_cable[0]["cb_statut"] == statut:
                        dict_joint_droit[
                            int(re.findall("\d+", str(liste_cable[0]["cb_capafo"]))[0])
                        ] += 1
                # Sinon c'est un piquage de la taille du cable
                else:
                    if liste_cable[0]["cb_statut"] == statut:
                        capa = max(
                            int(re.findall("\d+", str(liste_cable[0]["cb_capafo"]))[0]),
                            int(re.findall("\d+", str(liste_cable[1]["cb_capafo"]))[0]),
                        )
                        dict_piquage[capa] += 1
            # Sinon c'est une derivation du plus petit
            else:
                if liste_cable[0]["cb_statut"] == statut:
                    capa = min(
                        int(re.findall("\d+", str(liste_cable[0]["cb_capafo"]))[0]),
                        int(re.findall("\d+", str(liste_cable[1]["cb_capafo"]))[0]),
                    )
                    dict_raccordement[capa] += 1

        else:
            liste_capa = [
                int(re.findall("\d+", str(cable["cb_capafo"]))[0])
                for cable in liste_cable
            ]
            capamax = max(liste_capa)
            nb_capamax = liste_capa.count(capamax)
            if nb_capamax > 1:
                compteur = 0
                for cable in liste_cable:
                    if (
                        int(re.findall("\d+", str(cable["cb_capafo"]))[0]) == capamax
                        and compteur < 2
                    ):
                        compteur += 1
                        if compteur < 2:
                            if cable["cb_statut"] == statut:
                                dict_piquage[
                                    int(re.findall("\d+", str(cable["cb_capafo"]))[0])
                                ] += 1
                    else:
                        if cable["cb_statut"] == statut:
                            dict_raccordement[
                                int(re.findall("\d+", str(cable["cb_capafo"]))[0])
                            ] += 1
            else:
                compteur = 0
                for cable in liste_cable:
                    if (
                        int(re.findall("\d+", str(cable["cb_capafo"]))[0]) == capamax
                        and compteur < 1
                    ):
                        compteur += 1
                    else:
                        if cable["cb_statut"] == statut:
                            dict_raccordement[
                                int(re.findall("\d+", str(cable["cb_capafo"]))[0])
                            ] += 1
    return [dict_raccordement, dict_piquage, dict_joint_droit, dict_alignement]


def compte_boites_sans_support(t_ebp, t_ptech, t_adresse, transport, statut):
    compt = 0
    t_ebp.selectByExpression(f"bp_statut = '{statut}'")
    for ebp in t_ebp.selectedFeatures():
        t_ptech.selectByExpression(
            f"intersects(buffer($geometry, 0.2),  geom_from_wkt('{ebp.geometry().asWkt()}'))"
        )
        if not transport:
            t_adresse.selectByExpression(
                f"intersects(buffer($geometry, 0.2),  geom_from_wkt('{ebp.geometry().asWkt()}'))"
            )
            if (
                t_ptech.selectedFeatureCount() == 0
                and t_adresse.selectedFeatureCount() == 0
            ):
                compt += 1
        else:
            if t_ptech.selectedFeatureCount() == 0:
                compt += 1

    return compt


def tete_de_cable(nb_cable):
    jusque_1 = 0
    jusque_3 = 0
    jusque_5 = nb_cable // 5
    reste = nb_cable % 5
    if reste == 0:
        pass
    elif reste == 1:
        jusque_1 = 1
    elif reste < 4:
        jusque_3 = 1
    else:
        jusque_5 += 1
    return jusque_1, jusque_3, jusque_5


def longueur_cable(t_cable, pose, capacite, statut="DOE"):
    t_cable.selectByExpression(
        f"cb_statut = '{statut}' and to_int(cb_capafo) = {capacite} and TYPE ='{pose}'"
    )
    return ceil(
        sum(
            [
                float(str(cable["cb_lgreel"]).replace(",", "."))
                for cable in t_cable.selectedFeatures()
            ]
        )
    )


def calcul_longueur_pose(t_cable, t_cheminement, statut="DOE"):
    dict_pose = {
        "aerien": 0,
        "facade": 0,
        "immeuble": 0,
        "libre": 0,
        "occupe": 0,
    }
    t_cable.selectByExpression(f"cb_statut = '{statut}'")
    for cable in t_cable.selectedFeatures():
        facade = 0
        aerien = 0
        immeuble = 0
        libre = 0
        occupe = 0
        t_cheminement.selectByExpression(
            f"within($geometry, buffer(geom_from_wkt('{cable.geometry().asWkt()}'), 0.3))"
        )
        for cheminement in t_cheminement.selectedFeatures():
            if cheminement["cm_typ_imp"] in ["AERIEN", "0", "1"]:
                aerien += float(str(cheminement["cm_long"]).replace(",", "."))
            elif cheminement["cm_typ_imp"] in ["FACADE", "2"]:
                facade += float(str(cheminement["cm_long"]).replace(",", "."))
            elif cheminement["cm_typ_imp"] in ["IMMEUBLE", "3"]:
                immeuble += float(str(cheminement["cm_long"]).replace(",", "."))
            elif cheminement["cm_typ_imp"] in ["CONDUITE", "7"]:
                if cheminement["cm_avct"] in ["CREATION", "C"]:
                    libre += float(str(cheminement["cm_long"]).replace(",", "."))
                else:
                    occupe += float(str(cheminement["cm_long"]).replace(",", "."))
        if aerien + facade + immeuble + libre + occupe == 0:
            dict_pose["occupe"] += float(str(cable["cb_lgreel"]).replace(",", "."))
        else:
            coeff = float(str(cable["cb_lgreel"]).replace(",", ".")) / (
                aerien + facade + immeuble + libre + occupe
            )
            dict_pose["aerien"] += coeff * aerien
            dict_pose["facade"] += coeff * facade
            dict_pose["immeuble"] += coeff * immeuble
            dict_pose["libre"] += coeff * libre
            dict_pose["occupe"] += coeff * occupe
    return dict_pose

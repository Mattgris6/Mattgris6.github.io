from math import ceil
from .fonctionsNonGrace13 import (
    calcul_longueur_pose,
    compte_boites,
    compte_raccordement,
    tete_de_cable,
    longueur_cable,
)


def remplir_dictionnaire_3(
    transport, t_cable, t_ptech, t_ebp, t_cheminement, t_adresse, t_site, statut
):
    dict_article = {}
    if statut == "REC":
        dict_article["AC - 1.1"] = 1
    # Fourniture Poteaux créés en bois
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and TYPE_STRUC= 'APPUI' and PROPRIETAI = 'A CREER' and (pt_nature is null or pt_nature LIKE 'B%6%') "
    )
    dict_article["AC - 2.9.1.1.1"] = t_ptech.selectedFeatureCount()
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and TYPE_STRUC= 'APPUI' and PROPRIETAI = 'A CREER' and (pt_nature LIKE 'B%7%') "
    )
    dict_article["AC - 2.9.1.1.2"] = t_ptech.selectedFeatureCount()
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and TYPE_STRUC= 'APPUI' and PROPRIETAI = 'A CREER' and (pt_nature LIKE 'B%8%') "
    )
    dict_article["AC - 2.9.1.1.3"] = t_ptech.selectedFeatureCount()
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and TYPE_STRUC= 'APPUI' and PROPRIETAI = 'A CREER' and (pt_nature LIKE 'B%9%' or pt_nature LIKE 'B%0%') "
    )
    dict_article["AC - 2.9.1.1.4"] = t_ptech.selectedFeatureCount()
    # Fourniture Poteaux créés en metal
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and TYPE_STRUC= 'APPUI' and PROPRIETAI = 'A CREER' and (pt_nature LIKE 'M%6%')"
    )
    dict_article["AC - 2.9.1.2.1"] = t_ptech.selectedFeatureCount()
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and TYPE_STRUC= 'APPUI' and PROPRIETAI = 'A CREER' and (pt_nature LIKE 'M%7%')"
    )
    dict_article["AC - 2.9.1.2.2"] = t_ptech.selectedFeatureCount()
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and TYPE_STRUC= 'APPUI' and PROPRIETAI = 'A CREER' and (pt_nature LIKE 'M%8%')"
    )
    dict_article["AC - 2.9.1.2.3"] = t_ptech.selectedFeatureCount()
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and TYPE_STRUC= 'APPUI' and PROPRIETAI = 'A CREER' and (pt_nature LIKE 'M%9%' or pt_nature LIKE 'M%0%')"
    )
    dict_article["AC - 2.9.1.2.4"] = t_ptech.selectedFeatureCount()
    # Pose poteaux bois
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and TYPE_STRUC= 'APPUI' and PROPRIETAI = 'A CREER' and (pt_nature is null or pt_nature LIKE 'B%')"
    )
    dict_article["AC - 2.9.2.1.1"] = t_ptech.selectedFeatureCount()
    # Pose poteaux METAL
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and TYPE_STRUC= 'APPUI' and PROPRIETAI = 'A CREER' and (pt_nature LIKE 'M%')"
    )
    dict_article["AC - 2.9.2.1.2"] = t_ptech.selectedFeatureCount()
    # Armement
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and TYPE_STRUC= 'APPUI' and (PROPRIETAI <> 'ENEDIS')"
    )
    dict_article["AC - 2.9.2.9.1"] = t_ptech.selectedFeatureCount()
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and TYPE_STRUC= 'APPUI' and (PROPRIETAI = 'ENEDIS')"
    )
    dict_article["AC - 2.9.2.9.3"] = t_ptech.selectedFeatureCount()
    # GC
    t_cheminement.selectByExpression(f"cm_remblai is not NULL")
    gc_total = sum([cm["cm_long"] for cm in t_cheminement.selectedFeatures()])
    dict_article["AC - 2.3"] = gc_total
    # Les longueurs de cable
    if transport:
        dict_article["AC - 3.1.1.6"] = longueur_cable(t_cable, "CONDUITE", 36, statut)
        dict_article["AC - 3.1.1.8"] = longueur_cable(t_cable, "CONDUITE", 48, statut)
        dict_article["AC - 3.1.1.10"] = longueur_cable(t_cable, "CONDUITE", 72, statut)
        dict_article["AC - 3.1.1.16"] = longueur_cable(t_cable, "CONDUITE", 144, statut)
        dict_article["AC - 3.1.1.17"] = longueur_cable(t_cable, "CONDUITE", 288, statut)
        dict_article["AC - 3.1.1.18"] = longueur_cable(t_cable, "CONDUITE", 432, statut)
        dict_article["AC - 3.1.1.19"] = longueur_cable(t_cable, "CONDUITE", 576, statut)
        dict_article["AC - 3.1.1.20"] = longueur_cable(t_cable, "CONDUITE", 720, statut)
        # AERIEN
        dict_article["AC - 3.1.2.6"] = longueur_cable(t_cable, "AERIEN", 36, statut)
        dict_article["AC - 3.1.2.8"] = longueur_cable(t_cable, "AERIEN", 48, statut)
        dict_article["AC - 3.1.2.10"] = longueur_cable(t_cable, "AERIEN", 72, statut)
        dict_article["AC - 3.1.2.16"] = longueur_cable(t_cable, "AERIEN", 144, statut)
    else:
        # Calcul des longueurs de cable par capa et par support en modulo 6
        # CABL100:
        dict_article["AC - 3.1.1.1"] = longueur_cable(t_cable, "CONDUITE", 6, statut)
        dict_article["AC - 3.1.1.2"] = longueur_cable(t_cable, "CONDUITE", 12, statut)
        dict_article["AC - 3.1.1.3"] = longueur_cable(t_cable, "CONDUITE", 24, statut)
        dict_article["AC - 3.1.1.5"] = longueur_cable(t_cable, "CONDUITE", 36, statut)
        dict_article["AC - 3.1.1.7"] = longueur_cable(t_cable, "CONDUITE", 48, statut)
        dict_article["AC - 3.1.1.9"] = longueur_cable(t_cable, "CONDUITE", 72, statut)
        dict_article["AC - 3.1.1.15"] = longueur_cable(t_cable, "CONDUITE", 144, statut)
        dict_article["AC - 3.1.1.17"] = longueur_cable(t_cable, "CONDUITE", 288, statut)
        dict_article["AC - 3.1.1.18"] = longueur_cable(t_cable, "CONDUITE", 432, statut)
        dict_article["AC - 3.1.1.19"] = longueur_cable(t_cable, "CONDUITE", 576, statut)
        dict_article["AC - 3.1.1.20"] = longueur_cable(t_cable, "CONDUITE", 720, statut)
        # CABL300:[6]
        dict_article["AC - 3.1.2.1"] = longueur_cable(
            t_cable, "AERIEN", 6, statut
        ) + longueur_cable(t_cable, "FACADE", 6, statut)
        dict_article["AC - 3.1.2.2"] = longueur_cable(
            t_cable, "AERIEN", 12, statut
        ) + longueur_cable(t_cable, "FACADE", 12, statut)
        dict_article["AC - 3.1.2.3"] = longueur_cable(
            t_cable, "AERIEN", 24, statut
        ) + longueur_cable(t_cable, "FACADE", 24, statut)
        dict_article["AC - 3.1.2.5"] = longueur_cable(
            t_cable, "AERIEN", 36, statut
        ) + longueur_cable(t_cable, "FACADE", 36, statut)
        dict_article["AC - 3.1.2.7"] = longueur_cable(
            t_cable, "AERIEN", 48, statut
        ) + longueur_cable(t_cable, "FACADE", 48, statut)
        dict_article["AC - 3.1.2.9"] = longueur_cable(
            t_cable, "AERIEN", 72, statut
        ) + longueur_cable(t_cable, "FACADE", 72, statut)
        dict_article["AC - 3.1.2.15"] = longueur_cable(
            t_cable, "AERIEN", 144, statut
        ) + longueur_cable(t_cable, "FACADE", 144, statut)
        # Immeuble
        dict_article["AC - 3.1.4.1"] = longueur_cable(t_cable, "IMMEUBLE", 6, statut)
        dict_article["AC - 3.1.4.2"] = longueur_cable(t_cable, "IMMEUBLE", 12, statut)
        dict_article["AC - 3.1.4.3"] = longueur_cable(t_cable, "IMMEUBLE", 24, statut)
        dict_article["AC - 3.1.4.5"] = longueur_cable(t_cable, "IMMEUBLE", 36, statut)
        dict_article["AC - 3.1.4.7"] = longueur_cable(t_cable, "IMMEUBLE", 48, statut)
        dict_article["AC - 3.1.4.9"] = longueur_cable(t_cable, "IMMEUBLE", 72, statut)
        dict_article["AC - 3.1.4.15"] = longueur_cable(t_cable, "IMMEUBLE", 144, statut)

    # Longueur par type de pose
    longueur_pose = calcul_longueur_pose(t_cable, t_cheminement, statut)
    dict_article["AC - 3.2.1"] = ceil(longueur_pose["libre"])
    dict_article["AC - 3.2.2"] = ceil(longueur_pose["occupe"])
    dict_article["AC - 3.2.5"] = ceil(longueur_pose["aerien"])
    dict_article["AC - 3.2.11"] = ceil(longueur_pose["facade"])
    dict_article["AC - 3.2.12"] = ceil(longueur_pose["immeuble"])
    # Comptage des BPE
    # BPE en chambre
    dict_article["AC - 3.4.1.1"] = compte_boites(
        t_ebp, t_ptech, t_adresse, t_cable, 6, "CHAMBRE", statut
    )
    dict_article["AC - 3.4.1.2"] = compte_boites(
        t_ebp, t_ptech, t_adresse, t_cable, 12, "CHAMBRE", statut
    )
    dict_article["AC - 3.4.1.3"] = compte_boites(
        t_ebp, t_ptech, t_adresse, t_cable, 24, "CHAMBRE", statut
    )
    dict_article["AC - 3.4.1.4"] = compte_boites(
        t_ebp, t_ptech, t_adresse, t_cable, 36, "CHAMBRE", statut
    )
    dict_article["AC - 3.4.1.5"] = compte_boites(
        t_ebp, t_ptech, t_adresse, t_cable, 48, "CHAMBRE", statut
    )
    dict_article["AC - 3.4.1.6"] = compte_boites(
        t_ebp, t_ptech, t_adresse, t_cable, 72, "CHAMBRE", statut
    )
    dict_article["AC - 3.4.1.9"] = compte_boites(
        t_ebp, t_ptech, t_adresse, t_cable, 144, "CHAMBRE", statut
    )
    dict_article["AC - 3.4.1.10"] = compte_boites(
        t_ebp, t_ptech, t_adresse, t_cable, 288, "CHAMBRE", statut
    )
    dict_article["AC - 3.4.1.11"] = compte_boites(
        t_ebp, t_ptech, t_adresse, t_cable, 432, "CHAMBRE", statut
    )
    dict_article["AC - 3.4.1.12"] = compte_boites(
        t_ebp, t_ptech, t_adresse, t_cable, 576, "CHAMBRE", statut
    )
    dict_article["AC - 3.4.1.13"] = compte_boites(
        t_ebp, t_ptech, t_adresse, t_cable, 720, "CHAMBRE", statut
    )
    # BPE sur facade
    dict_article["AC - 3.4.2.1"] = (
        compte_boites(t_ebp, t_ptech, t_adresse, t_cable, 6, "FACADE", statut)
        + compte_boites(t_ebp, t_ptech, t_adresse, t_cable, 6, "ANCRAGE FACADE", statut)
        + compte_boites(t_ebp, t_ptech, t_adresse, t_cable, 6, "POTELET", statut)
    )
    dict_article["AC - 3.4.2.2"] = (
        compte_boites(t_ebp, t_ptech, t_adresse, t_cable, 12, "FACADE", statut)
        + compte_boites(
            t_ebp, t_ptech, t_adresse, t_cable, 12, "ANCRAGE FACADE", statut
        )
        + compte_boites(t_ebp, t_ptech, t_adresse, t_cable, 12, "POTELET", statut)
    )
    dict_article["AC - 3.4.2.3"] = (
        compte_boites(t_ebp, t_ptech, t_adresse, t_cable, 24, "FACADE", statut)
        + compte_boites(
            t_ebp, t_ptech, t_adresse, t_cable, 24, "ANCRAGE FACADE", statut
        )
        + compte_boites(t_ebp, t_ptech, t_adresse, t_cable, 24, "POTELET", statut)
    )
    dict_article["AC - 3.4.2.4"] = (
        compte_boites(t_ebp, t_ptech, t_adresse, t_cable, 36, "FACADE", statut)
        + compte_boites(
            t_ebp, t_ptech, t_adresse, t_cable, 36, "ANCRAGE FACADE", statut
        )
        + compte_boites(t_ebp, t_ptech, t_adresse, t_cable, 36, "POTELET", statut)
    )
    dict_article["AC - 3.4.2.5"] = (
        compte_boites(t_ebp, t_ptech, t_adresse, t_cable, 48, "FACADE", statut)
        + compte_boites(
            t_ebp, t_ptech, t_adresse, t_cable, 48, "ANCRAGE FACADE", statut
        )
        + compte_boites(t_ebp, t_ptech, t_adresse, t_cable, 48, "POTELET", statut)
    )
    dict_article["AC - 3.4.2.6"] = (
        compte_boites(t_ebp, t_ptech, t_adresse, t_cable, 72, "FACADE", statut)
        + compte_boites(
            t_ebp, t_ptech, t_adresse, t_cable, 72, "ANCRAGE FACADE", statut
        )
        + compte_boites(t_ebp, t_ptech, t_adresse, t_cable, 72, "POTELET", statut)
    )
    dict_article["AC - 3.4.2.9"] = (
        compte_boites(t_ebp, t_ptech, t_adresse, t_cable, 144, "FACADE", statut)
        + compte_boites(
            t_ebp, t_ptech, t_adresse, t_cable, 144, "ANCRAGE FACADE", statut
        )
        + compte_boites(t_ebp, t_ptech, t_adresse, t_cable, 144, "POTELET", statut)
    )
    # BPE sur POTEAU
    dict_article["AC - 3.4.3.1"] = compte_boites(
        t_ebp, t_ptech, t_adresse, t_cable, 6, "APPUI", statut
    )
    dict_article["AC - 3.4.3.2"] = compte_boites(
        t_ebp, t_ptech, t_adresse, t_cable, 12, "APPUI", statut
    )
    dict_article["AC - 3.4.3.3"] = compte_boites(
        t_ebp, t_ptech, t_adresse, t_cable, 24, "APPUI", statut
    )
    dict_article["AC - 3.4.3.4"] = compte_boites(
        t_ebp, t_ptech, t_adresse, t_cable, 36, "APPUI", statut
    )
    dict_article["AC - 3.4.3.5"] = compte_boites(
        t_ebp, t_ptech, t_adresse, t_cable, 48, "APPUI", statut
    )
    dict_article["AC - 3.4.3.6"] = compte_boites(
        t_ebp, t_ptech, t_adresse, t_cable, 72, "APPUI", statut
    )
    dict_article["AC - 3.4.3.9"] = compte_boites(
        t_ebp, t_ptech, t_adresse, t_cable, 144, "APPUI", statut
    )
    dict_article["AC - 3.4.3.10"] = compte_boites(
        t_ebp, t_ptech, t_adresse, t_cable, 288, "APPUI", statut
    )
    # BPE sur IMMEUBLE
    dict_article["AC - 3.4.4.1"] = compte_boites(
        t_ebp, t_ptech, t_adresse, t_cable, 6, "IMMEUBLE", statut
    )
    dict_article["AC - 3.4.4.2"] = compte_boites(
        t_ebp, t_ptech, t_adresse, t_cable, 12, "IMMEUBLE", statut
    )
    dict_article["AC - 3.4.4.3"] = compte_boites(
        t_ebp, t_ptech, t_adresse, t_cable, 24, "IMMEUBLE", statut
    )
    dict_article["AC - 3.4.4.4"] = compte_boites(
        t_ebp, t_ptech, t_adresse, t_cable, 36, "IMMEUBLE", statut
    )
    dict_article["AC - 3.4.4.5"] = compte_boites(
        t_ebp, t_ptech, t_adresse, t_cable, 48, "IMMEUBLE", statut
    )
    dict_article["AC - 3.4.4.6"] = compte_boites(
        t_ebp, t_ptech, t_adresse, t_cable, 72, "IMMEUBLE", statut
    )
    dict_article["AC - 3.4.4.9"] = compte_boites(
        t_ebp, t_ptech, t_adresse, t_cable, 144, "IMMEUBLE", statut
    )

    # Comptage des raccordements et piquage
    result = compte_raccordement(t_cable, t_ebp, statut)
    dict_derivation = result[0]
    dict_piquage = result[1]
    dict_joint_droit = result[2]
    dict_alignement = result[3]
    # RACC100
    dict_article["AC - 3.6.1.1"] = dict_joint_droit[6]
    dict_article["AC - 3.6.1.2"] = dict_joint_droit[12]
    dict_article["AC - 3.6.1.3"] = dict_joint_droit[24]
    dict_article["AC - 3.6.1.4"] = dict_joint_droit[36]
    dict_article["AC - 3.6.1.5"] = dict_joint_droit[48]
    dict_article["AC - 3.6.1.6"] = dict_joint_droit[72]
    dict_article["AC - 3.6.1.9"] = dict_joint_droit[144]
    dict_article["AC - 3.6.1.10"] = dict_joint_droit[288]
    dict_article["AC - 3.6.1.11"] = dict_joint_droit[432]
    dict_article["AC - 3.6.1.12"] = dict_joint_droit[576]
    dict_article["AC - 3.6.1.13"] = dict_joint_droit[720]
    # RACC200
    dict_article["AC - 3.6.1.14"] = dict_derivation[6]
    dict_article["AC - 3.6.1.15"] = dict_derivation[12]
    dict_article["AC - 3.6.1.16"] = dict_derivation[24]
    dict_article["AC - 3.6.1.17"] = dict_derivation[36]
    dict_article["AC - 3.6.1.18"] = dict_derivation[48]
    dict_article["AC - 3.6.1.19"] = dict_derivation[72]
    dict_article["AC - 3.6.1.22"] = dict_derivation[144]
    dict_article["AC - 3.6.1.23"] = dict_derivation[288]
    dict_article["AC - 3.6.1.24"] = dict_derivation[432]
    dict_article["AC - 3.6.1.25"] = dict_derivation[576]
    dict_article["AC - 3.6.1.26"] = dict_derivation[720]
    # RACC300
    dict_article["AC - 3.6.2.1"] = dict_piquage[6]
    dict_article["AC - 3.6.2.2"] = dict_piquage[12]
    dict_article["AC - 3.6.2.3"] = dict_piquage[24]
    dict_article["AC - 3.6.2.4"] = dict_piquage[36]
    dict_article["AC - 3.6.2.5"] = dict_piquage[48]
    dict_article["AC - 3.6.2.6"] = dict_piquage[72]
    dict_article["AC - 3.6.2.9"] = dict_piquage[144]
    dict_article["AC - 3.6.2.10"] = dict_piquage[288]
    dict_article["AC - 3.6.2.11"] = dict_piquage[432]
    dict_article["AC - 3.6.2.12"] = dict_piquage[576]

    # Raccordement optique des modules optiques
    # AC - 5.3
    if transport:
        t_cable.removeSelection()
        t_cable.selectByExpression(
            f"cb_statut = '{statut}' and (EQ_A LIKE 'NRO%' or EQ_B LIKE 'NRO%')"
        )
        # Pour les tetes de cable au NRO, il n'y a que du 144
        capa_total = sum(
            [int(cable["cb_capafo"]) for cable in t_cable.selectedFeatures()]
        )
        dict_article["AC - 3.5.1.1"] = ceil(capa_total / 144)
        nb36 = 0
        nb48 = 0
        nb72 = 0
        nb144 = 0
        for cable in t_cable.selectedFeatures():
            if int(cable["cb_capafo"]) <= 36:
                nb36 += 1
            elif int(cable["cb_capafo"]) == 48:
                nb48 += 1
            elif int(cable["cb_capafo"]) == 72:
                nb72 += 1
            elif int(cable["cb_capafo"]) >= 144:
                nb144 += int(cable["cb_capafo"]) // 144
        nb72 = tete_de_cable(nb36 + nb48 + nb72)
        nb144 = tete_de_cable(nb144)
        dict_article["AC - 3.6.3.7"] = nb72[0]
        dict_article["AC - 3.6.3.8"] = nb72[1]
        dict_article["AC - 3.6.3.9"] = nb72[2]
        dict_article["AC - 3.6.3.10"] = nb144[0]
        dict_article["AC - 3.6.3.11"] = nb144[1]
        dict_article["AC - 3.6.3.12"] = nb144[2]
        # On va chercher le nombre de module de 36 à chaque SRO
        nb36 = 0
        t_cable.selectByExpression(
            f"cb_statut = '{statut}' and (EQ_A LIKE 'SRO%' or EQ_B LIKE 'SRO%')"
        )
        capa_sro = sum([cable["cb_capafo"] for cable in t_cable.selectedFeatures()])
        nb36 += ceil(capa_sro / 36)
        if capa_sro > 1:
            nbmesures = capa_sro / 2 - 1
        else:
            nbmesures = 0
        nb36 = tete_de_cable(nb36)
        dict_article["AC - 3.6.3.1"] = nb36[0]
        dict_article["AC - 3.6.3.2"] = nb36[1]
        dict_article["AC - 3.6.3.3"] = nb36[2]
        # Mesures
        t_site.selectByExpression(f"st_typelog = 'SRO'")
        if statut == "REC":
            dict_article["AC - 4.2.1.1"] = t_site.selectedFeatureCount()
        dict_article["AC - 4.2.1.2"] = nbmesures
    else:
        t_cable.removeSelection()
        t_cable.selectByExpression(f"cb_statut = '{statut}' and EQ_A LIKE 'SRO%'")
        nb36 = 0
        nb48 = 0
        nb72 = 0
        nb144 = 0
        for cable in t_cable.selectedFeatures():
            if int(cable["cb_capafo"]) <= 36:
                nb36 += 1
            elif int(cable["cb_capafo"]) == 48:
                nb48 += 1
            elif int(cable["cb_capafo"]) == 72:
                nb72 += 1
            elif int(cable["cb_capafo"]) >= 144:
                nb144 += int(cable["cb_capafo"]) // 144
        dict_article["AC - 3.6.3.1"] = tete_de_cable(nb36)[0]
        dict_article["AC - 3.6.3.2"] = tete_de_cable(nb36)[1]
        dict_article["AC - 3.6.3.3"] = tete_de_cable(nb36)[2]
        dict_article["AC - 3.6.3.4"] = tete_de_cable(nb48)[0]
        dict_article["AC - 3.6.3.5"] = tete_de_cable(nb48)[1]
        dict_article["AC - 3.6.3.6"] = tete_de_cable(nb48)[2]
        dict_article["AC - 3.6.3.7"] = tete_de_cable(nb72)[0]
        dict_article["AC - 3.6.3.8"] = tete_de_cable(nb72)[1]
        dict_article["AC - 3.6.3.9"] = tete_de_cable(nb72)[2]
        dict_article["AC - 3.6.3.10"] = tete_de_cable(nb144)[0]
        dict_article["AC - 3.6.3.11"] = tete_de_cable(nb144)[1]
        dict_article["AC - 3.6.3.12"] = tete_de_cable(nb144)[2]
        # Les mesures
        t_ebp.selectByExpression(
            f"cb_statut = '{statut}' and bp_typelog like 'PB%' and NB_PRISES < 6"
        )
        dict_article["AC - 4.2.3.1"] = t_ebp.selectedFeatureCount()
        t_ebp.selectByExpression(
            f"cb_statut = '{statut}' and bp_typelog like 'PB%' and NB_PRISES > 5"
        )
        dict_article["AC - 4.2.3.2"] = t_ebp.selectedFeatureCount()
    return dict_article

import os
from qgis.core import QgsProject, QgsCoordinateReferenceSystem, QgsVectorLayer, Qgis
from qgis.utils import iface
from qgis.PyQt.QtWidgets import QProgressBar, QMessageBox
import processing
from math import ceil
import datetime
from .fonctions_generales import recherche_txt, insert_colonne

VERSION_QGIS = int(Qgis.QGIS_VERSION.split("-")[0].split(".")[1])


def lancement_AB(dlg, lot, openpyxl):
    enregistrer = dlg.enregistrer.filePath()
    transport = dlg.transport.isChecked()
    pdfinal = dlg.checkPDFinal.isChecked()
    # On affiche un message
    progressMessageBar = iface.messageBar().createMessage(
        "Patience! Le chiffrage est en cours de préparation..."
    )
    progress = QProgressBar()
    progress.setMaximum(100)
    progressMessageBar.layout().addWidget(progress)
    iface.messageBar().pushWidget(progressMessageBar)
    progress.setValue(0)
    # On va chercher les couches
    t_adresse = ""
    layers = QgsProject.instance().mapLayers().values()
    for layer in layers:
        if layer.name() == "t_adresse":
            t_adresse = layer
    if not verif_table(t_adresse, "t_adresse"):
        QMessageBox.warning(
            None,
            "Erreur",
            f"Impossible de trouver la couche t_adresse. Veuillez l'ajouter au projet.",
        )
        return False
    myfilepath = t_adresse.dataProvider().dataSourceUri()
    repertoire_dlg = os.path.split(myfilepath)[0]
    # On va chercher les fichiers dans le DLG
    # Les csv
    uri = f"file:///{repertoire_dlg}/t_cable_patch201.csv?delimiter=%s" % (";")
    t_cable_patch = QgsVectorLayer(uri, "t_cable_patch201", "delimitedtext")
    ajouter(t_cable_patch)
    #
    uri = f"file:///{repertoire_dlg}/t_zpbo_patch201.csv?delimiter=%s" % (";")
    t_zpbo_patch201 = QgsVectorLayer(uri, "t_zpbo_patch201", "delimitedtext")
    ajouter(t_zpbo_patch201)
    #
    uri = f"file:///{repertoire_dlg}/t_cable.csv?delimiter=%s" % (";")
    t_cable = QgsVectorLayer(uri, "t_cable", "delimitedtext")
    ajouter(t_cable)
    #
    uri = f"file:///{repertoire_dlg}/t_ptech.csv?delimiter=%s" % (";")
    t_ptech = QgsVectorLayer(uri, "t_ptech", "delimitedtext")
    ajouter(t_ptech)
    #
    uri = f"file:///{repertoire_dlg}/t_ebp.csv?delimiter=%s" % (";")
    t_ebp = QgsVectorLayer(uri, "t_ebp", "delimitedtext")
    ajouter(t_ebp)
    #
    uri = f"file:///{repertoire_dlg}/t_sitetech.csv?delimiter=%s" % (";")
    t_sitetech = QgsVectorLayer(uri, "t_sitetech", "delimitedtext")
    ajouter(t_sitetech)
    #
    uri = f"file:///{repertoire_dlg}/t_reference.csv?delimiter=%s" % (";")
    t_reference = QgsVectorLayer(uri, "t_reference", "delimitedtext")
    ajouter(t_reference)
    #
    uri = f"file:///{repertoire_dlg}/t_cab_cond.csv?delimiter=%s" % (";")
    t_cab_cond = QgsVectorLayer(uri, "t_cab_cond", "delimitedtext")
    ajouter(t_cab_cond)
    #
    uri = f"file:///{repertoire_dlg}/t_cond_chem.csv?delimiter=%s" % (";")
    t_cond_chem = QgsVectorLayer(uri, "t_cond_chem", "delimitedtext")
    ajouter(t_cond_chem)
    #
    uri = f"file:///{repertoire_dlg}/t_conduite.csv?delimiter=%s" % (";")
    t_conduite = QgsVectorLayer(uri, "t_conduite", "delimitedtext")
    ajouter(t_conduite)
    #
    uri = f"file:///{repertoire_dlg}/t_suf.csv?delimiter=%s" % (";")
    t_suf = QgsVectorLayer(uri, "t_suf", "delimitedtext")
    ajouter(t_suf)
    #
    uri = f"file:///{repertoire_dlg}/t_cassette.csv?delimiter=%s" % (";")
    t_cassette = QgsVectorLayer(uri, "t_cassette", "delimitedtext")
    ajouter(t_cassette)
    #
    uri = f"file:///{repertoire_dlg}/t_position.csv?delimiter=%s" % (";")
    t_position = QgsVectorLayer(uri, "t_position", "delimitedtext")
    ajouter(t_position)
    # Les shp
    t_noeud = QgsVectorLayer(repertoire_dlg + r"/t_noeud.shp", "t_noeud", "ogr")
    ajouter(t_noeud)
    t_zpbo = QgsVectorLayer(repertoire_dlg + r"/t_zpbo.shp", "t_zpbo", "ogr")
    ajouter(t_zpbo)
    t_adresse = QgsVectorLayer(repertoire_dlg + r"/t_adresse.shp", "t_adresse", "ogr")
    ajouter(t_adresse)
    t_cheminement = QgsVectorLayer(
        repertoire_dlg + r"/t_cheminement.shp", "t_cheminement", "ogr"
    )
    ajouter(t_cheminement)
    # On va chercher le fichier BDC indiqué par l'utilisateur
    # fichierBDC_path = dlg.fichier_bdc.filePath()
    if not pdfinal:
        if lot == "A - SOGETREL":
            fichierBDC_path = (
                os.path.abspath(os.path.dirname(__file__))
                + r"/CHIFFRAGE LOT A SOGETREL.xlsx"
            )
        elif lot == "B - RESONANCE":
            fichierBDC_path = (
                os.path.abspath(os.path.dirname(__file__))
                + r"/CHIFFRAGE LOT B RESONANCE.xlsx"
            )
        elif lot == "2 - RESONANCE":
            fichierBDC_path = (
                os.path.abspath(os.path.dirname(__file__))
                + r"/CHIFFRAGE LOT 2 RESONANCE.xlsx"
            )
        elif lot == "3 - SOGETREL (GraceTHD)":
            fichierBDC_path = (
                os.path.abspath(os.path.dirname(__file__))
                + r"/CHIFFRAGE LOT 3 SOGETREL.xlsx"
            )
        fichierBDC = openpyxl.load_workbook(fichierBDC_path)
        # On l'enregistre dans le répertoire choisi par l'utilisateur
        chemin_sauvegarde = enregistrer + "\BDC_FMP.xlsx"
    else:
        if len(dlg.fichierDecompte.filePath()) > 0:
            fichierBDC = openpyxl.load_workbook(dlg.fichierDecompte.filePath())
            # On l'enregistre dans le répertoire choisi par l'utilisateur
            chemin_sauvegarde = enregistrer + "\MOE_Projet_de_Decompte_General_BDC.xlsx"
        else:
            QMessageBox.information(
                None,
                "Erreur",
                "Veuillez renseigner un fchier de décompte final.",
            )
            return False
    try:
        fichierBDC.save(chemin_sauvegarde)
    except:
        QMessageBox.information(
            None,
            "Erreur",
            "Erreur lors de l'enregistrement. Un fichier du même nom est déjà ouvert? Veuillez le fermer avant de lancer l'outil.",
        )
        return False
    # La table des prises
    # ("requete prise avant", datetime.datetime.now())
    if t_suf.featureCount() == 0:
        requete = "select t_zpbo.zp_code, zp_bp_code as bp_code, sum(ad_nbprhab + ad_nbprpro) as nb_prise, bp_statut, bp_typelog from t_zpbo, t_zpbo_patch201, t_adresse, t_ebp where t_zpbo.zp_code = t_zpbo_patch201.zp_code and t_zpbo_patch201.zp_bp_code=t_ebp.bp_code and st_within(t_adresse.geometry, t_zpbo.geometry) group by t_zpbo.zp_code, zp_bp_code"
    else:
        requete = "select t_zpbo.zp_code, zp_bp_code as bp_code, count(sf_code) as nb_prise, bp_statut, bp_typelog from t_zpbo, t_zpbo_patch201, t_ebp left join t_suf on sf_zp_code=t_zpbo.zp_code where t_zpbo.zp_code = t_zpbo_patch201.zp_code and t_zpbo_patch201.zp_bp_code=t_ebp.bp_code group by t_zpbo.zp_code, zp_bp_code"
    alg_params = {
        "INPUT_DATASOURCES": [],
        "INPUT_GEOMETRY_CRS": QgsCoordinateReferenceSystem("EPSG:2154"),
        "INPUT_GEOMETRY_FIELD": "",
        "INPUT_GEOMETRY_TYPE": 1,
        "INPUT_QUERY": requete,
        "INPUT_UID_FIELD": "",
        "OUTPUT": "TEMPORARY_OUTPUT",
    }
    t_nbprise = processing.run("qgis:executesql", alg_params)["OUTPUT"]
    # print("requete prise apres", datetime.datetime.now())
    # On lance les dictionnaires
    if lot == "2 - RESONANCE" or lot == "3 - SOGETREL (GraceTHD)":
        dict_rec_article = remplir_dictionnaire_2(
            transport,
            t_cable,
            t_ptech,
            t_ebp,
            t_nbprise,
            t_cable_patch,
            t_sitetech,
            t_cheminement,
            "REC",
        )
        dict_doe_article = remplir_dictionnaire_2(
            transport,
            t_cable,
            t_ptech,
            t_ebp,
            t_nbprise,
            t_cable_patch,
            t_sitetech,
            t_cheminement,
            "DOE",
        )
        dict_exe_article = remplir_dictionnaire_2(
            transport,
            t_cable,
            t_ptech,
            t_ebp,
            t_nbprise,
            t_cable_patch,
            t_sitetech,
            t_cheminement,
            "EXE",
        )
    else:
        dict_rec_article = remplir_dictionnaire_AB(
            transport,
            t_cable,
            t_ptech,
            t_ebp,
            t_nbprise,
            t_cable_patch,
            t_sitetech,
            t_cheminement,
            "REC",
        )
        dict_doe_article = remplir_dictionnaire_AB(
            transport,
            t_cable,
            t_ptech,
            t_ebp,
            t_nbprise,
            t_cable_patch,
            t_sitetech,
            t_cheminement,
            "REC",
        )
        dict_exe_article = remplir_dictionnaire_AB(
            transport,
            t_cable,
            t_ptech,
            t_ebp,
            t_nbprise,
            t_cable_patch,
            t_sitetech,
            t_cheminement,
            "EXE",
        )
    feuilleBDC = fichierBDC.worksheets[0]
    if not pdfinal:
        # On remplit l'excel
        colonne = 6
        ligne_depart = 7
        nrow = feuilleBDC.max_row
        for ligne in range(ligne_depart, nrow + 1):
            feuilleBDC.cell(
                row=ligne,
                column=colonne,
                value=dict_rec_article.get(feuilleBDC.cell(row=ligne, column=1).value, 0) + dict_doe_article.get(feuilleBDC.cell(row=ligne, column=1).value, 0),
            )
            feuilleBDC.cell(
                row=ligne,
                column=colonne + 1,
                value=dict_exe_article.get(feuilleBDC.cell(row=ligne, column=1).value),
            )
    else:
        # On insert les deux premières colonnes
        q_col, q_row = recherche_txt(feuilleBDC, "Quantité calculé par le MOE")
        if not q_col:
            q_col, q_row = recherche_txt(feuilleBDC, "Numéro du BDC")
            insert_colonne(feuilleBDC, q_col)
            feuilleBDC.cell(
                row=q_row,
                column=q_col + 1,
                value="Quantité calculé par le MOE",
            )
            feuilleBDC.cell(
                row=q_row,
                column=q_col + 2,
                value="Montant calculé MOE",
            )
            q_col += 1
        # On insert les deux dernières
        z_col, z_row = recherche_txt(feuilleBDC, "Quantité des travaux non exécutés")
        if not z_col:
            z_col, z_row = recherche_txt(feuilleBDC, "Quantité restante")
            insert_colonne(feuilleBDC, z_col)
            feuilleBDC.cell(
                row=z_row,
                column=z_col + 1,
                value="Quantité des travaux non exécutés",
            )
            feuilleBDC.cell(
                row=z_row,
                column=z_col + 2,
                value="Montant des travaux non exécuté",
            )
            z_col += 1
        qbdc_col, qbdc_row = recherche_txt(feuilleBDC, "Quantité du BDC")
        pu_col, pu_row = recherche_txt(feuilleBDC, "P.U. HT")
        l_qbdc_col = openpyxl.utils.get_column_letter(qbdc_col)
        l_pu_col = openpyxl.utils.get_column_letter(pu_col)
        l_q_col = openpyxl.utils.get_column_letter(q_col)
        l_m_col = openpyxl.utils.get_column_letter(q_col + 1)
        l_qt_col = openpyxl.utils.get_column_letter(z_col)
        l_mt_col = openpyxl.utils.get_column_letter(z_col + 1)
        # On remplit l'excel
        article_col, article_row = recherche_txt(feuilleBDC, "Article du BDC")
        colonne = q_col
        ligne_depart = q_row + 1
        nrow = feuilleBDC.max_row
        for ligne in range(ligne_depart, nrow + 1):
            if len(feuilleBDC.cell(row=ligne, column=article_col + 1).value or "") > 0:
                feuilleBDC.cell(
                    row=ligne,
                    column=colonne,
                    value=dict_rec_article.get(
                        feuilleBDC.cell(row=ligne, column=article_col).value
                    ),
                )
                feuilleBDC.cell(
                    row=ligne,
                    column=colonne + 1,
                    value=f"={l_q_col}{ligne}*{l_pu_col}{ligne}",
                )
                feuilleBDC.cell(
                    row=ligne,
                    column=z_col,
                    value=f"==IF({l_qbdc_col}{ligne}=0,0,{l_qbdc_col}{ligne}-{l_q_col}{ligne})",
                )
                feuilleBDC.cell(
                    row=ligne,
                    column=z_col + 1,
                    value=f"={l_qt_col}{ligne}*{l_pu_col}{ligne}",
                )

    fichierBDC.save(chemin_sauvegarde)
    iface.messageBar().clearWidgets()
    iface.messageBar().pushMessage(
        "Bravo!", "L'excel de chiffrage est prêt", level=3, duration=180
    )


def verif_table(t_table, t_name):
    if t_table == "":
        return False
    else:
        return True


def remplir_dictionnaire_AB(
    transport,
    t_cable,
    t_ptech,
    t_ebp,
    t_nbprise,
    t_cable_patch,
    t_sitetech,
    t_cheminement,
    statut,
):
    dict_article = {}
    print("debut du calcul des articles", datetime.datetime.now())
    # Chambres créées
    # L1T
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and pt_etiquet like 'C2117%' and pt_nature = 'L1T'"
    )
    dict_article["AC-3421"] = t_ptech.selectedFeatureCount()
    # L2T
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and pt_etiquet like 'C2117%' and pt_nature = 'L2T'"
    )
    dict_article["AC-3422"] = t_ptech.selectedFeatureCount()
    # L3T
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and pt_etiquet like 'C2117%' and pt_nature = 'L3T'"
    )
    dict_article["AC-3423"] = t_ptech.selectedFeatureCount()
    # L4T
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and pt_etiquet like 'C2117%' and pt_nature = 'L4T'"
    )
    dict_article["AC-3424"] = t_ptech.selectedFeatureCount()
    # L5T
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and pt_etiquet like 'C2117%' and pt_nature = 'L5T'"
    )
    dict_article["AC-3425"] = t_ptech.selectedFeatureCount()
    # L2C
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and pt_etiquet like 'C2117%' and pt_nature = 'L2C'"
    )
    dict_article["AC-3426"] = t_ptech.selectedFeatureCount()
    # L3C
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and pt_etiquet like 'C2117%' and pt_nature = 'L3C'"
    )
    dict_article["AC-3427"] = t_ptech.selectedFeatureCount()
    # K1C
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and pt_etiquet like 'C2117%' and pt_nature = 'K1C'"
    )
    dict_article["AC-3428"] = t_ptech.selectedFeatureCount()
    # K2C
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and pt_etiquet like 'C2117%' and pt_nature = 'K2C'"
    )
    dict_article["AC-3429"] = t_ptech.selectedFeatureCount()
    # print("fin chambres", datetime.datetime.now())
    # GC
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and cm_remblai is not NULL"
    )
    gc_total = sum([cm["cm_long"] for cm in t_cheminement.selectedFeatures()])
    dict_article["AC-33"] = gc_total
    # Poteaux créés en bois
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and pt_typephy = 'A' and regexp_match(pt_codeext ,'A21\\\\d{{4}}') and (pt_nature is null or pt_nature = 'PBOI')"
    )
    dict_article["AC-3511"] = t_ptech.selectedFeatureCount()
    # Poteaux créés en metal
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and pt_typephy = 'A' and regexp_match(pt_codeext ,'A21\\\\d{{4}}') and pt_nature = 'PMET'"
    )
    dict_article["AC-3512"] = t_ptech.selectedFeatureCount()
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and pt_typephy = 'A' and regexp_match(pt_codeext ,'A21\\\\d{{4}}') and pt_nature = 'PIND'"
    )
    dict_article["AC-3514"] = t_ptech.selectedFeatureCount()
    # Calcul des longueurs de cable par capa et par support
    # print("avant calcul longueur", datetime.datetime.now())
    longueur_reelle = calcul_longueur(statut, t_cable, t_ptech)
    # print("après calcul longueur", datetime.datetime.now())
    """#Cable conduite modulo 6:
    dict_article['AC-4121'] = ceil(longueur_reelle['SOUTERRAIN'][6][6])
    dict_article['AC-4122'] = ceil(longueur_reelle['SOUTERRAIN'][12][6])
    dict_article['AC-4123'] = ceil(longueur_reelle['SOUTERRAIN'][24][6])
    dict_article['AC-4124'] = ceil(longueur_reelle['SOUTERRAIN'][36][6])
    dict_article['AC-4125'] = ceil(longueur_reelle['SOUTERRAIN'][48][6])
    dict_article['AC-4126'] = ceil(longueur_reelle['SOUTERRAIN'][72][6])
    dict_article['AC-4127'] = ceil(longueur_reelle['SOUTERRAIN'][144][6])
    #Cable conduite modulo 12:
    dict_article['AC-4131'] = ceil(longueur_reelle['SOUTERRAIN'][36][12])
    dict_article['AC-4132'] = ceil(longueur_reelle['SOUTERRAIN'][72][12])
    dict_article['AC-4133'] = ceil(longueur_reelle['SOUTERRAIN'][144][12])
    dict_article['AC-4134'] = ceil(longueur_reelle['SOUTERRAIN'][288][12])
    dict_article['AC-4135'] = ceil(longueur_reelle['SOUTERRAIN'][432][12])
    dict_article['AC-4136'] = ceil(longueur_reelle['SOUTERRAIN'][576][12])
    dict_article['AC-4137'] = ceil(longueur_reelle['SOUTERRAIN'][720][12])
    #Cable aerien/facade modulo 6:
    dict_article['AC-4141'] = ceil(longueur_reelle['AERIEN'][6][6])
    dict_article['AC-4142'] = ceil(longueur_reelle['AERIEN'][12][6])
    dict_article['AC-4143'] = ceil(longueur_reelle['AERIEN'][24][6])
    dict_article['AC-4144'] = ceil(longueur_reelle['AERIEN'][36][6])
    dict_article['AC-4145'] = ceil(longueur_reelle['AERIEN'][48][6])
    dict_article['AC-4146'] = ceil(longueur_reelle['AERIEN'][72][6])
    dict_article['AC-4147'] = ceil(longueur_reelle['AERIEN'][144][6])
    #Cable mixte modulo 12:
    dict_article['AC-4161'] = ceil(longueur_reelle['AERIEN'][36][12])
    dict_article['AC-4162'] = ceil(longueur_reelle['AERIEN'][72][12])
    dict_article['AC-4163'] = ceil(longueur_reelle['AERIEN'][144][12])
    dict_article['AC-4164'] = ceil(longueur_reelle['AERIEN'][288][12])
    dict_article['AC-4165'] = ceil(longueur_reelle['AERIEN'][432][12])
    dict_article['AC-4166'] = ceil(longueur_reelle['AERIEN'][576][12])
    dict_article['AC-4167'] = ceil(longueur_reelle['AERIEN'][720][12])"""
    # Cable mixte modulo 6:
    dict_article["AC-4151"] = ceil(longueur_reelle["AERIEN"][6][6]) + ceil(
        longueur_reelle["SOUTERRAIN"][6][6]
    )
    dict_article["AC-4152"] = ceil(longueur_reelle["AERIEN"][12][6]) + ceil(
        longueur_reelle["SOUTERRAIN"][12][6]
    )
    dict_article["AC-4153"] = ceil(longueur_reelle["AERIEN"][24][6]) + ceil(
        longueur_reelle["SOUTERRAIN"][24][6]
    )
    dict_article["AC-4154"] = ceil(longueur_reelle["AERIEN"][36][6]) + ceil(
        longueur_reelle["SOUTERRAIN"][36][6]
    )
    dict_article["AC-4155"] = ceil(longueur_reelle["AERIEN"][48][6]) + ceil(
        longueur_reelle["SOUTERRAIN"][48][6]
    )
    dict_article["AC-4156"] = ceil(longueur_reelle["AERIEN"][72][6]) + ceil(
        longueur_reelle["SOUTERRAIN"][72][6]
    )
    dict_article["AC-4157"] = ceil(longueur_reelle["AERIEN"][144][6]) + ceil(
        longueur_reelle["SOUTERRAIN"][144][6]
    )
    # Cable mixte modulo 12:
    dict_article["AC-4161"] = ceil(longueur_reelle["AERIEN"][36][12]) + ceil(
        longueur_reelle["SOUTERRAIN"][36][12]
    )
    dict_article["AC-4162"] = ceil(longueur_reelle["AERIEN"][72][12]) + ceil(
        longueur_reelle["SOUTERRAIN"][72][12]
    )
    dict_article["AC-4163"] = ceil(longueur_reelle["AERIEN"][144][12]) + ceil(
        longueur_reelle["SOUTERRAIN"][144][12]
    )
    dict_article["AC-4164"] = ceil(longueur_reelle["AERIEN"][288][12]) + ceil(
        longueur_reelle["SOUTERRAIN"][288][12]
    )
    dict_article["AC-4165"] = ceil(longueur_reelle["AERIEN"][432][12]) + ceil(
        longueur_reelle["SOUTERRAIN"][432][12]
    )
    dict_article["AC-4166"] = ceil(longueur_reelle["AERIEN"][576][12]) + ceil(
        longueur_reelle["SOUTERRAIN"][576][12]
    )
    dict_article["AC-4167"] = ceil(longueur_reelle["AERIEN"][720][12]) + ceil(
        longueur_reelle["SOUTERRAIN"][720][12]
    )
    # Cable immeuble modulo 6
    dict_article["AC-4171"] = ceil(longueur_reelle["IMMEUBLE"][6][6])
    dict_article["AC-4172"] = ceil(longueur_reelle["IMMEUBLE"][12][6])
    dict_article["AC-4173"] = ceil(longueur_reelle["IMMEUBLE"][24][6])
    dict_article["AC-4174"] = ceil(longueur_reelle["IMMEUBLE"][36][6])
    dict_article["AC-4175"] = ceil(longueur_reelle["IMMEUBLE"][48][6])
    dict_article["AC-4176"] = ceil(longueur_reelle["IMMEUBLE"][72][6])
    # Cable immeuble modulo 12
    dict_article["AC-4181"] = ceil(longueur_reelle["IMMEUBLE"][144][6]) + ceil(
        longueur_reelle["IMMEUBLE"][144][12]
    )
    dict_article["AC-4182"] = ceil(longueur_reelle["IMMEUBLE"][288][12])
    dict_article["AC-4183"] = ceil(longueur_reelle["IMMEUBLE"][432][12])
    dict_article["AC-4184"] = ceil(longueur_reelle["IMMEUBLE"][576][12])
    dict_article["AC-4185"] = ceil(longueur_reelle["IMMEUBLE"][720][12])
    # Longueur par type de pose
    dict_article["AC-421"] = ceil(longueur_reelle["pvc"])
    dict_article["AC-422"] = ceil(longueur_reelle["pehd"])
    dict_article["AC-423"] = ceil(longueur_reelle["aerien"])
    dict_article["AC-425"] = ceil(longueur_reelle["facade"])
    dict_article["AC-426"] = ceil(longueur_reelle["immeuble"])
    # print("fin longueurs", datetime.datetime.now())
    # Comptage des BPE
    # BPE en chambre
    dict_article["AC-4311"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 6, "CHAMBRE", f"('{statut}')"
    )
    dict_article["AC-4312"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 12, "CHAMBRE", f"('{statut}')"
    )
    dict_article["AC-4313"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 24, "CHAMBRE", f"('{statut}')"
    )
    dict_article["AC-4314"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 36, "CHAMBRE", f"('{statut}')"
    )
    dict_article["AC-4315"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 48, "CHAMBRE", f"('{statut}')"
    )
    dict_article["AC-4316"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 72, "CHAMBRE", f"('{statut}')"
    )
    dict_article["AC-4317"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 144, "CHAMBRE", f"('{statut}')"
    )
    dict_article["AC-4318"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 288, "CHAMBRE", f"('{statut}')"
    )
    dict_article["AC-4319"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 432, "CHAMBRE", f"('{statut}')"
    )
    dict_article["AC-43191"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 576, "CHAMBRE", f"('{statut}')"
    )
    dict_article["AC-43192"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 720, "CHAMBRE", f"('{statut}')"
    )
    # BPE sur poteaux/facade
    dict_article["AC-4321"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 6, "FACADE", f"('{statut}')"
    ) + compte_bpe(t_cable_patch, t_cable, t_ebp, t_ptech, 6, "POTEAU", f"('{statut}')")
    dict_article["AC-4322"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 12, "FACADE", f"('{statut}')"
    ) + compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 12, "POTEAU", f"('{statut}')"
    )
    dict_article["AC-4323"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 24, "FACADE", f"('{statut}')"
    ) + compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 24, "POTEAU", f"('{statut}')"
    )
    dict_article["AC-4324"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 36, "FACADE", f"('{statut}')"
    ) + compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 36, "POTEAU", f"('{statut}')"
    )
    dict_article["AC-4325"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 48, "FACADE", f"('{statut}')"
    ) + compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 48, "POTEAU", f"('{statut}')"
    )
    dict_article["AC-4326"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 72, "FACADE", f"('{statut}')"
    ) + compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 72, "POTEAU", f"('{statut}')"
    )
    dict_article["AC-4327"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 144, "FACADE", f"('{statut}')"
    ) + compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 144, "POTEAU", f"('{statut}')"
    )
    # BPE sur IMMEUBLE
    dict_article["AC-4331"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 6, "IMMEUBLE", f"('{statut}')"
    )
    dict_article["AC-4332"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 12, "IMMEUBLE", f"('{statut}')"
    )
    dict_article["AC-4333"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 24, "IMMEUBLE", f"('{statut}')"
    )
    dict_article["AC-4334"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 36, "IMMEUBLE", f"('{statut}')"
    )
    dict_article["AC-4335"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 48, "IMMEUBLE", f"('{statut}')"
    )
    dict_article["AC-4336"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 72, "IMMEUBLE", f"('{statut}')"
    )
    dict_article["AC-4337"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 144, "IMMEUBLE", f"('{statut}')"
    )

    # Comptage des PBO
    dict_article["AC-4341"] = compte_pbo(
        t_ebp, t_ptech, 6, "CHAMBRE", t_nbprise, f"('{statut}')"
    )
    dict_article["AC-4342"] = compte_pbo(
        t_ebp, t_ptech, 12, "CHAMBRE", t_nbprise, f"('{statut}')"
    )
    dict_article["AC-4343"] = compte_pbo(
        t_ebp, t_ptech, 6, "FACADE", t_nbprise, f"('{statut}')"
    ) + compte_pbo(t_ebp, t_ptech, 6, "POTEAU", t_nbprise, f"('{statut}')")
    dict_article["AC-4344"] = compte_pbo(
        t_ebp, t_ptech, 12, "FACADE", t_nbprise, f"('{statut}')"
    ) + compte_pbo(t_ebp, t_ptech, 12, "POTEAU", t_nbprise, f"('{statut}')")
    dict_article["AC-4345"] = compte_pbo(
        t_ebp, t_ptech, 6, "IMMEUBLE", t_nbprise, f"('{statut}')"
    )
    dict_article["AC-4346"] = compte_pbo(
        t_ebp, t_ptech, 12, "IMMEUBLE", t_nbprise, f"('{statut}')"
    )

    # Comptage des raccordements et piquage
    result = compte_raccordement(
        t_cable, t_ebp, t_cable_patch, t_nbprise, f"('{statut}')"
    )
    dict_derivation = result[0]
    dict_piquage = result[1]
    dict_joint_droit = result[2]
    dict_alignement = result[3]
    # RACC100
    dict_article["AC-4511"] = dict_joint_droit[6]
    dict_article["AC-4512"] = dict_joint_droit[12]
    dict_article["AC-4513"] = dict_joint_droit[24]
    dict_article["AC-4514"] = dict_joint_droit[36]
    dict_article["AC-4515"] = dict_joint_droit[48]
    dict_article["AC-4516"] = dict_joint_droit[72]
    dict_article["AC-4517"] = dict_joint_droit[144]
    dict_article["AC-4518"] = dict_joint_droit[288]
    dict_article["AC-4519"] = dict_joint_droit[432]
    dict_article["AC-45191"] = dict_joint_droit[576]
    dict_article["AC-45192"] = dict_joint_droit[720]
    # RACC200
    dict_article["AC-4521"] = dict_derivation[6]
    dict_article["AC-4522"] = dict_derivation[12]
    dict_article["AC-4523"] = dict_derivation[24]
    dict_article["AC-4524"] = dict_derivation[36]
    dict_article["AC-4525"] = dict_derivation[48]
    dict_article["AC-4526"] = dict_derivation[72]
    dict_article["AC-4527"] = dict_derivation[144]
    dict_article["AC-4528"] = dict_derivation[288]
    dict_article["AC-4529"] = dict_derivation[432]
    dict_article["AC-45291"] = dict_derivation[576]
    dict_article["AC-45292"] = dict_derivation[720]
    # RACC300
    dict_article["AC-4531"] = dict_piquage[6]
    dict_article["AC-4532"] = dict_piquage[12]
    dict_article["AC-4533"] = dict_piquage[24]
    dict_article["AC-4534"] = dict_piquage[36]
    dict_article["AC-4535"] = dict_piquage[48]
    dict_article["AC-4536"] = dict_piquage[72]
    dict_article["AC-4537"] = dict_piquage[144]
    dict_article["AC-4538"] = dict_piquage[288]
    dict_article["AC-4539"] = dict_piquage[432]
    dict_article["AC-45391"] = dict_piquage[576]
    # RACC300
    dict_article["AC-4541"] = dict_alignement[6]
    dict_article["AC-4542"] = dict_alignement[12]
    dict_article["AC-4543"] = dict_alignement[24]
    dict_article["AC-4544"] = dict_alignement[36]
    dict_article["AC-4545"] = dict_alignement[48]
    dict_article["AC-4546"] = dict_alignement[72]
    dict_article["AC-4547"] = dict_alignement[144]

    # Raccordement optique des modules optiques
    # AC - 45
    t_cable.removeSelection()
    t_sitetech.selectByExpression(f"st_typelog = 'SRO' or st_typelog = 'NRO'")
    for site in t_sitetech.selectedFeatures():
        nd_code = site["st_nd_code"]
        if VERSION_QGIS >= 34:
            t_cable.selectByExpression(
                f"(cb_nd1 = '{nd_code}' or cb_nd2 = '{nd_code}') and cb_statut in ('{statut}')",
                behavior=QgsVectorLayer.SelectBehavior.AddToSelection,
            )
        else:
            t_cable.selectByExpression(
                f"(cb_nd1 = '{nd_code}' or cb_nd2 = '{nd_code}') and cb_statut in ('{statut}')",
                behavior=1,
            )
    nb36 = 0
    nb48 = 0
    nb72 = 0
    nb144 = 0
    for cable in t_cable.selectedFeatures():
        if int(cable["cb_capafo"]) <= 36:
            nb36 += 1
        elif int(cable["cb_capafo"]) == 48:
            nb48 += 1
        elif int(cable["cb_capafo"]) == 72:
            nb72 += 1
        elif int(cable["cb_capafo"]) >= 144:
            nb144 += int(cable["cb_capafo"]) // 144
    dict_article["AC-4551"] = nb36
    dict_article["AC-4552"] = nb48
    dict_article["AC-4553"] = nb72
    dict_article["AC-4554"] = nb144

    # Les mesures et equipements optiques
    if transport:
        t_cable.removeSelection()
        t_sitetech.selectByExpression(f"st_typelog = 'NRO'")
        for site in t_sitetech.selectedFeatures():
            nd_code = site["st_nd_code"]
            if VERSION_QGIS >= 34:
                t_cable.selectByExpression(
                    f"(cb_nd1 = '{nd_code}' or cb_nd2 = '{nd_code}') and cb_statut in ('{statut}')",
                    behavior=QgsVectorLayer.SelectBehavior.AddToSelection,
                )
            else:
                t_cable.selectByExpression(
                    f"(cb_nd1 = '{nd_code}' or cb_nd2 = '{nd_code}') and cb_statut in ('{statut}')",
                    behavior=1,
                )
        capa_totale = sum([cable["cb_capafo"] for cable in t_cable.selectedFeatures()])
        nb144 = ceil(capa_totale / 144)
        dict_article["AC-4411"] = nb144
        # dict_article['AC-4412'] = nb144
        # Mesures
        dict_article["AC-5212"] = capa_totale / 2
        t_sitetech.selectByExpression(f"st_typelog = 'SRO'")
        dict_article["AC-5211"] = t_sitetech.selectedFeatureCount()
        # On va chercher le nombre de module de 36 à chaque SRO
        nb36 = 0
        for site in t_sitetech.selectedFeatures():
            nd_code = site["st_nd_code"]
            t_cable.selectByExpression(
                f"(cb_nd1 = '{nd_code}' or cb_nd2 = '{nd_code}') and cb_statut in ('{statut}')"
            )
            capa_sro = sum([cable["cb_capafo"] for cable in t_cable.selectedFeatures()])
            nb36 += ceil(capa_sro / 36)
        # dict_article['AC-4432'] = nb36
    else:
        # Equipements
        t_sitetech.selectByExpression(f"st_typelog = 'SRO'")
        # On va chercher le nombre de module de 144 à chaque SRO
        nb144 = 0
        for site in t_sitetech.selectedFeatures():
            nd_code = site["st_nd_code"]
            t_cable.selectByExpression(
                f"(cb_nd1 = '{nd_code}' or cb_nd2 = '{nd_code}') and cb_statut in ('{statut}')"
            )
            capa_sro = sum([cable["cb_capafo"] for cable in t_cable.selectedFeatures()])
            nb144 += ceil(capa_sro / 144)
        # dict_article['AC-4433'] = nb144
        # Mesures
        t_nbprise.selectByExpression(f"bp_statut = '{statut}' and bp_typelog = 'PBO'")
        dict_article["AC-5221"] = t_nbprise.selectedFeatureCount()
        t_nbprise.selectByExpression(
            f"bp_statut = '{statut}' and bp_typelog = 'PBO' and nb_prise < 6"
        )
        dict_article["AC-5222"] = t_nbprise.selectedFeatureCount() * 6
        t_nbprise.selectByExpression(
            f"bp_statut = '{statut}' and bp_typelog = 'PBO' and nb_prise > 5"
        )
        dict_article["AC-5222"] += t_nbprise.selectedFeatureCount() * 12
    return dict_article


def remplir_dictionnaire_2(
    transport,
    t_cable,
    t_ptech,
    t_ebp,
    t_nbprise,
    t_cable_patch,
    t_sitetech,
    t_cheminement,
    statut,
):
    dict_article = {}
    # Installation de chantier
    dict_article["AC - 1.1"] = 1
    # Fourniture Poteaux créés en bois
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and pt_typephy = 'A' and regexp_match(pt_codeext ,'A21\\\\d{{4}}') and (pt_nature is null or pt_nature = 'PBOI') and (pt_a_haut = 6 or pt_a_haut is null)"
    )
    dict_article["AC - 2.9.1.1.1"] = t_ptech.selectedFeatureCount()
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and pt_typephy = 'A' and regexp_match(pt_codeext ,'A21\\\\d{{4}}') and (pt_nature is null or pt_nature = 'PBOI') and (pt_a_haut = 7)"
    )
    dict_article["AC - 2.9.1.1.2"] = t_ptech.selectedFeatureCount()
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and pt_typephy = 'A' and regexp_match(pt_codeext ,'A21\\\\d{{4}}') and (pt_nature is null or pt_nature = 'PBOI') and (pt_a_haut = 8)"
    )
    dict_article["AC - 2.9.1.1.3"] = t_ptech.selectedFeatureCount()
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and pt_typephy = 'A' and regexp_match(pt_codeext ,'A21\\\\d{{4}}') and (pt_nature is null or pt_nature = 'PBOI') and (pt_a_haut >= 10)"
    )
    dict_article["AC - 2.9.1.1.4"] = t_ptech.selectedFeatureCount()
    # Fourniture Poteaux créés en metal
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and pt_typephy = 'A' and regexp_match(pt_codeext ,'A21\\\\d{{4}}') and (pt_nature = 'PMET' or pt_nature = 'PIND') and (pt_a_haut = 6 or pt_a_haut is null)"
    )
    dict_article["AC - 2.9.1.2.1"] = t_ptech.selectedFeatureCount()
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and pt_typephy = 'A' and regexp_match(pt_codeext ,'A21\\\\d{{4}}') and (pt_nature = 'PMET' or pt_nature = 'PIND') and (pt_a_haut = 7)"
    )
    dict_article["AC - 2.9.1.2.2"] = t_ptech.selectedFeatureCount()
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and pt_typephy = 'A' and regexp_match(pt_codeext ,'A21\\\\d{{4}}') and (pt_nature = 'PMET' or pt_nature = 'PIND') and (pt_a_haut = 8)"
    )
    dict_article["AC - 2.9.1.2.3"] = t_ptech.selectedFeatureCount()
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and pt_typephy = 'A' and regexp_match(pt_codeext ,'A21\\\\d{{4}}') and (pt_nature = 'PMET' or pt_nature = 'PIND') and (pt_a_haut >= 10)"
    )
    dict_article["AC - 2.9.1.2.4"] = t_ptech.selectedFeatureCount()
    # Pose Poteaux créés en bois
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and pt_typephy = 'A' and regexp_match(pt_codeext ,'A21\\\\d{{4}}') and (pt_nature is null or pt_nature = 'PBOI')"
    )
    dict_article["AC - 2.9.2.1.1"] = t_ptech.selectedFeatureCount()
    # Pose Poteaux créés en metal
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and pt_typephy = 'A' and regexp_match(pt_codeext ,'A21\\\\d{{4}}') and (pt_nature = 'PMET' or pt_nature = 'PIND')"
    )
    dict_article["AC - 2.9.2.1.2"] = t_ptech.selectedFeatureCount()
    # Armement poteaux
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and pt_typephy = 'A' and pt_prop in ('OR210000000001', 'OR390000000001', 'OR710000000571', 'OR000000000001', 'OR215000000150', 'OR000000000005')"
    )
    dict_article["AC - 2.9.2.9.1"] = t_ptech.selectedFeatureCount()
    t_ptech.selectByExpression(
        f"pt_statut = '{statut}' and pt_typephy = 'A' and pt_prop in ('OR000000000002')"
    )
    dict_article["AC - 2.9.2.9.3"] = t_ptech.selectedFeatureCount()
    # GC
    t_cheminement.selectByExpression(
        f"cm_statut = '{statut}' and cm_remblai is not NULL"
    )
    gc_total = sum([cm["cm_long"] for cm in t_cheminement.selectedFeatures()])
    dict_article["AC - 2.3"] = gc_total
    # Calcul des longueurs de cable par capa et par support
    longueur_reelle = calcul_longueur(statut, t_cable, t_ptech)
    # Cable conduite modulo 6:
    dict_article["AC - 3.1.1.1"] = ceil(longueur_reelle["SOUTERRAIN"][6][6])
    dict_article["AC - 3.1.1.2"] = ceil(longueur_reelle["SOUTERRAIN"][12][6])
    dict_article["AC - 3.1.1.3"] = ceil(longueur_reelle["SOUTERRAIN"][24][6])
    dict_article["AC - 3.1.1.5"] = ceil(longueur_reelle["SOUTERRAIN"][36][6])
    dict_article["AC - 3.1.1.7"] = ceil(longueur_reelle["SOUTERRAIN"][48][6])
    dict_article["AC - 3.1.1.9"] = ceil(longueur_reelle["SOUTERRAIN"][72][6])
    dict_article["AC - 3.1.1.15"] = ceil(longueur_reelle["SOUTERRAIN"][144][6])
    # Cable conduite modulo 12:
    dict_article["AC - 3.1.1.6"] = ceil(longueur_reelle["SOUTERRAIN"][36][12])
    dict_article["AC - 3.1.1.10"] = ceil(longueur_reelle["SOUTERRAIN"][72][12])
    dict_article["AC - 3.1.1.16"] = ceil(longueur_reelle["SOUTERRAIN"][144][12])
    dict_article["AC - 3.1.1.17"] = ceil(longueur_reelle["SOUTERRAIN"][288][12])
    dict_article["AC - 3.1.1.18"] = ceil(longueur_reelle["SOUTERRAIN"][432][12])
    dict_article["AC - 3.1.1.19"] = ceil(longueur_reelle["SOUTERRAIN"][576][12])
    dict_article["AC - 3.1.1.20"] = ceil(longueur_reelle["SOUTERRAIN"][720][12])
    # Cable aerien/facade modulo 6:
    dict_article["AC - 3.1.2.1"] = ceil(longueur_reelle["AERIEN"][6][6])
    dict_article["AC - 3.1.2.2"] = ceil(longueur_reelle["AERIEN"][12][6])
    dict_article["AC - 3.1.2.3"] = ceil(longueur_reelle["AERIEN"][24][6])
    dict_article["AC - 3.1.2.5"] = ceil(longueur_reelle["AERIEN"][36][6])
    dict_article["AC - 3.1.2.7"] = ceil(longueur_reelle["AERIEN"][48][6])
    dict_article["AC - 3.1.2.9"] = ceil(longueur_reelle["AERIEN"][72][6])
    dict_article["AC - 3.1.2.15"] = ceil(longueur_reelle["AERIEN"][144][6])
    # Cable mixte modulo 12:
    dict_article["AC - 3.1.2.6"] = ceil(longueur_reelle["AERIEN"][36][12])
    dict_article["AC - 3.1.2.10"] = ceil(longueur_reelle["AERIEN"][72][12])
    dict_article["AC - 3.1.2.16"] = ceil(longueur_reelle["AERIEN"][144][12])
    # Cable immeuble modulo 6
    dict_article["AC - 3.1.4.1"] = ceil(longueur_reelle["IMMEUBLE"][6][6])
    dict_article["AC - 3.1.4.2"] = ceil(longueur_reelle["IMMEUBLE"][12][6])
    dict_article["AC - 3.1.4.3"] = ceil(longueur_reelle["IMMEUBLE"][24][6])
    dict_article["AC - 3.1.4.5"] = ceil(longueur_reelle["IMMEUBLE"][36][6])
    dict_article["AC - 3.1.4.7"] = ceil(longueur_reelle["IMMEUBLE"][48][6])
    dict_article["AC - 3.1.4.9"] = ceil(longueur_reelle["IMMEUBLE"][72][6])
    dict_article["AC - 3.1.4.15"] = ceil(longueur_reelle["IMMEUBLE"][144][6])
    # Cable immeuble modulo 12
    dict_article["AC - 3.1.4.6"] = ceil(longueur_reelle["IMMEUBLE"][36][12])
    dict_article["AC - 3.1.4.8"] = ceil(longueur_reelle["IMMEUBLE"][48][12])
    dict_article["AC - 3.1.4.10"] = ceil(longueur_reelle["IMMEUBLE"][72][12])
    dict_article["AC - 3.1.4.16"] = ceil(longueur_reelle["IMMEUBLE"][144][12])
    dict_article["AC - 3.1.4.17"] = ceil(longueur_reelle["IMMEUBLE"][288][12])
    dict_article["AC - 3.1.4.18"] = ceil(longueur_reelle["IMMEUBLE"][432][12])
    dict_article["AC - 3.1.4.19"] = ceil(longueur_reelle["IMMEUBLE"][576][12])
    dict_article["AC - 3.1.4.20"] = ceil(longueur_reelle["IMMEUBLE"][720][12])
    # Longueur par type de pose
    dict_article["AC - 3.2.2"] = ceil(longueur_reelle["pvc"])
    dict_article["AC - 3.2.3"] = ceil(longueur_reelle["pehd"])
    dict_article["AC - 3.2.5"] = ceil(longueur_reelle["aerien"])
    dict_article["AC - 3.2.11"] = ceil(longueur_reelle["facade"]) + ceil(
        longueur_reelle["immeuble"]
    )
    # Comptage des BPE
    # BPE en chambre
    dict_article["AC - 3.4.1.1"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 6, "CHAMBRE", f"('{statut}')"
    ) + compte_pbo(t_ebp, t_ptech, 6, "CHAMBRE", t_nbprise, f"('{statut}')")
    dict_article["AC - 3.4.1.2"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 12, "CHAMBRE", f"('{statut}')"
    ) + compte_pbo(t_ebp, t_ptech, 12, "CHAMBRE", t_nbprise, f"('{statut}')")
    dict_article["AC - 3.4.1.3"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 24, "CHAMBRE", f"('{statut}')"
    )
    dict_article["AC - 3.4.1.4"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 36, "CHAMBRE", f"('{statut}')"
    )
    dict_article["AC - 3.4.1.5"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 48, "CHAMBRE", f"('{statut}')"
    )
    dict_article["AC - 3.4.1.6"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 72, "CHAMBRE", f"('{statut}')"
    )
    dict_article["AC - 3.4.1.9"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 144, "CHAMBRE", f"('{statut}')"
    )
    dict_article["AC - 3.4.1.10"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 288, "CHAMBRE", f"('{statut}')"
    )
    dict_article["AC - 3.4.1.11"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 432, "CHAMBRE", f"('{statut}')"
    )
    dict_article["AC - 3.4.1.12"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 576, "CHAMBRE", f"('{statut}')"
    )
    dict_article["AC - 3.4.1.13"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 720, "CHAMBRE", f"('{statut}')"
    )
    # BPE sur facade
    dict_article["AC - 3.4.2.1"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 6, "FACADE", f"('{statut}')"
    ) + compte_pbo(t_ebp, t_ptech, 6, "FACADE", t_nbprise, f"('{statut}')")
    dict_article["AC - 3.4.2.2"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 12, "FACADE", f"('{statut}')"
    ) + compte_pbo(t_ebp, t_ptech, 12, "FACADE", t_nbprise, f"('{statut}')")
    dict_article["AC - 3.4.2.3"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 24, "FACADE", f"('{statut}')"
    )
    dict_article["AC - 3.4.2.4"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 36, "FACADE", f"('{statut}')"
    )
    dict_article["AC - 3.4.2.5"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 48, "FACADE", f"('{statut}')"
    )
    dict_article["AC - 3.4.2.6"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 72, "FACADE", f"('{statut}')"
    )
    dict_article["AC - 3.4.2.9"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 144, "FACADE", f"('{statut}')"
    )
    # Boites sur poteau
    dict_article["AC - 3.4.3.1"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 6, "POTEAU", f"('{statut}')"
    ) + compte_pbo(t_ebp, t_ptech, 6, "POTEAU", t_nbprise, f"('{statut}')")
    dict_article["AC - 3.4.3.2"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 12, "POTEAU", f"('{statut}')"
    ) + compte_pbo(t_ebp, t_ptech, 12, "POTEAU", t_nbprise, f"('{statut}')")
    dict_article["AC - 3.4.3.3"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 24, "POTEAU", f"('{statut}')"
    )
    dict_article["AC - 3.4.3.4"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 36, "POTEAU", f"('{statut}')"
    )
    dict_article["AC - 3.4.3.5"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 48, "POTEAU", f"('{statut}')"
    )
    dict_article["AC - 3.4.3.6"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 72, "POTEAU", f"('{statut}')"
    )
    dict_article["AC - 3.4.3.9"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 144, "POTEAU", f"('{statut}')"
    )
    dict_article["AC - 3.4.3.10"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 288, "POTEAU", f"('{statut}')"
    )
    # BPE sur IMMEUBLE
    dict_article["AC - 3.4.4.1"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 6, "IMMEUBLE", f"('{statut}')"
    ) + compte_pbo(t_ebp, t_ptech, 6, "IMMEUBLE", t_nbprise, f"('{statut}')")
    dict_article["AC - 3.4.4.2"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 12, "IMMEUBLE", f"('{statut}')"
    ) + compte_pbo(t_ebp, t_ptech, 12, "IMMEUBLE", t_nbprise, f"('{statut}')")
    dict_article["AC - 3.4.4.3"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 24, "IMMEUBLE", f"('{statut}')"
    )
    dict_article["AC - 3.4.4.4"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 36, "IMMEUBLE", f"('{statut}')"
    )
    dict_article["AC - 3.4.4.5"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 48, "IMMEUBLE", f"('{statut}')"
    )
    dict_article["AC - 3.4.4.6"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 72, "IMMEUBLE", f"('{statut}')"
    )
    dict_article["AC - 3.4.4.9"] = compte_bpe(
        t_cable_patch, t_cable, t_ebp, t_ptech, 144, "IMMEUBLE", f"('{statut}')"
    )

    # Comptage des raccordements et piquage
    result = compte_raccordement(
        t_cable, t_ebp, t_cable_patch, t_nbprise, f"('{statut}')"
    )
    dict_derivation = result[0]
    dict_piquage = result[1]
    dict_joint_droit = result[2]
    dict_alignement = result[3]
    # RACC100
    dict_article["AC - 3.6.1.1"] = dict_joint_droit[6]
    dict_article["AC - 3.6.1.2"] = dict_joint_droit[12]
    dict_article["AC - 3.6.1.3"] = dict_joint_droit[24]
    dict_article["AC - 3.6.1.4"] = dict_joint_droit[36]
    dict_article["AC - 3.6.1.5"] = dict_joint_droit[48]
    dict_article["AC - 3.6.1.6"] = dict_joint_droit[72]
    dict_article["AC - 3.6.1.9"] = dict_joint_droit[144]
    dict_article["AC - 3.6.1.10"] = dict_joint_droit[288]
    dict_article["AC - 3.6.1.11"] = dict_joint_droit[432]
    dict_article["AC - 3.6.1.12"] = dict_joint_droit[576]
    dict_article["AC - 3.6.1.13"] = dict_joint_droit[720]
    # RACC200
    dict_article["AC - 3.6.1.14"] = dict_derivation[6]
    dict_article["AC - 3.6.1.15"] = dict_derivation[12]
    dict_article["AC - 3.6.1.16"] = dict_derivation[24]
    dict_article["AC - 3.6.1.17"] = dict_derivation[36]
    dict_article["AC - 3.6.1.18"] = dict_derivation[48]
    dict_article["AC - 3.6.1.19"] = dict_derivation[72]
    dict_article["AC - 3.6.1.22"] = dict_derivation[144]
    dict_article["AC - 3.6.1.23"] = dict_derivation[288]
    dict_article["AC - 3.6.1.24"] = dict_derivation[432]
    dict_article["AC - 3.6.1.25"] = dict_derivation[576]
    dict_article["AC - 3.6.1.26"] = dict_derivation[720]
    # RACC300
    dict_article["AC - 3.6.2.1"] = dict_piquage[6]
    dict_article["AC - 3.6.2.2"] = dict_piquage[12]
    dict_article["AC - 3.6.2.3"] = dict_piquage[24]
    dict_article["AC - 3.6.2.4"] = dict_piquage[36]
    dict_article["AC - 3.6.2.5"] = dict_piquage[48]
    dict_article["AC - 3.6.2.6"] = dict_piquage[72]
    dict_article["AC - 3.6.2.9"] = dict_piquage[144]
    dict_article["AC - 3.6.2.10"] = dict_piquage[288]
    dict_article["AC - 3.6.2.11"] = dict_piquage[432]
    dict_article["AC - 3.6.2.12"] = dict_piquage[576]

    # Les mesures et equipements optiques
    if transport:
        t_cable.removeSelection()
        t_sitetech.selectByExpression(f"st_typelog = 'NRO'")
        for site in t_sitetech.selectedFeatures():
            nd_code = site["st_nd_code"]
            if VERSION_QGIS >= 34:
                t_cable.selectByExpression(
                    f"(cb_nd1 = '{nd_code}' or cb_nd2 = '{nd_code}') and cb_statut in ('{statut}')",
                    behavior=1,
                )
            else:
                t_cable.selectByExpression(
                    f"(cb_nd1 = '{nd_code}' or cb_nd2 = '{nd_code}') and cb_statut in ('{statut}')",
                    behavior=QgsVectorLayer.SelectBehavior.AddToSelection,
                )
        nb36 = 0
        nb48 = 0
        nb72 = 0
        nb144 = 0
        for cable in t_cable.selectedFeatures():
            if int(cable["cb_capafo"]) <= 36:
                nb36 += 1
            elif int(cable["cb_capafo"]) == 48:
                nb48 += 1
            elif int(cable["cb_capafo"]) == 72:
                nb72 += 1
            elif int(cable["cb_capafo"]) >= 144:
                nb144 += int(cable["cb_capafo"]) // 144
        nb72 = tete_de_cable(nb36 + nb48 + nb72)
        nb144 = tete_de_cable(nb144)
        dict_article["AC - 3.6.3.7"] = nb72[0]
        dict_article["AC - 3.6.3.8"] = nb72[1]
        dict_article["AC - 3.6.3.9"] = nb72[2]
        dict_article["AC - 3.6.3.10"] = nb144[0]
        dict_article["AC - 3.6.3.11"] = nb144[1]
        dict_article["AC - 3.6.3.12"] = nb144[2]
        # On va chercher le nombre de module de 36 à chaque SRO
        nb36 = 0
        t_sitetech.selectByExpression(f"st_typelog = 'SRO'")
        for site in t_sitetech.selectedFeatures():
            nd_code = site["st_nd_code"]
            t_cable.selectByExpression(
                f"(cb_nd1 = '{nd_code}' or cb_nd2 = '{nd_code}') and cb_statut in ('{statut}')"
            )
            capa_sro = sum([cable["cb_capafo"] for cable in t_cable.selectedFeatures()])
            nb36 += ceil(capa_sro / 36)
            nbmesures = capa_sro / 2 - 1
        nb36 = tete_de_cable(nb36)
        dict_article["AC - 3.6.3.1"] = nb36[0]
        dict_article["AC - 3.6.3.2"] = nb36[1]
        dict_article["AC - 3.6.3.3"] = nb36[2]
        # Mesures
        dict_article["AC - 4.2.1.1"] = t_sitetech.selectedFeatureCount()
        dict_article["AC - 4.2.1.2"] = nbmesures
    else:
        # Equipements
        t_sitetech.selectByExpression(f"st_typelog = 'SRO'")
        # On va chercher le nombre de module de 144 à chaque SRO
        nb144 = 0
        for site in t_sitetech.selectedFeatures():
            nd_code = site["st_nd_code"]
            t_cable.selectByExpression(
                f"(cb_nd1 = '{nd_code}' or cb_nd2 = '{nd_code}') and cb_statut in ('{statut}')"
            )
        nb36 = 0
        nb48 = 0
        nb72 = 0
        nb144 = 0
        for cable in t_cable.selectedFeatures():
            if int(cable["cb_capafo"]) <= 36:
                nb36 += 1
            elif int(cable["cb_capafo"]) == 48:
                nb48 += 1
            elif int(cable["cb_capafo"]) == 72:
                nb72 += 1
            elif int(cable["cb_capafo"]) >= 144:
                nb144 += int(cable["cb_capafo"]) // 144
        nb36 = tete_de_cable(nb36)
        nb48 = tete_de_cable(nb48)
        nb72 = tete_de_cable(nb72)
        nb144 = tete_de_cable(nb144)
        dict_article["AC - 3.6.3.1"] = nb36[0]
        dict_article["AC - 3.6.3.2"] = nb36[1]
        dict_article["AC - 3.6.3.3"] = nb36[2]
        dict_article["AC - 3.6.3.4"] = nb48[0]
        dict_article["AC - 3.6.3.5"] = nb48[1]
        dict_article["AC - 3.6.3.6"] = nb48[2]
        dict_article["AC - 3.6.3.7"] = nb72[0]
        dict_article["AC - 3.6.3.8"] = nb72[1]
        dict_article["AC - 3.6.3.9"] = nb72[2]
        dict_article["AC - 3.6.3.10"] = nb144[0]
        dict_article["AC - 3.6.3.11"] = nb144[1]
        dict_article["AC - 3.6.3.12"] = nb144[2]
        # Mesures
        t_nbprise.selectByExpression(
            f"bp_statut = '{statut}' and bp_typelog = 'PBO' and nb_prise < 6"
        )
        dict_article["AC - 4.2.3.1"] = t_nbprise.selectedFeatureCount() * 6
        t_nbprise.selectByExpression(
            f"bp_statut = '{statut}' and bp_typelog = 'PBO' and nb_prise > 5"
        )
        dict_article["AC - 4.2.3.2"] = t_nbprise.selectedFeatureCount() * 12
    return dict_article


def calcul_longueur(statut, t_cable, t_ptech):
    longueur_reelle = {}
    # Pour les modes de pose
    longueur_reelle["pvc"] = 0
    longueur_reelle["pehd"] = 0
    longueur_reelle["aerien"] = 0
    longueur_reelle["facade"] = 0
    longueur_reelle["immeuble"] = 0
    # Pour les cables par capa:
    liste_type_cable = ["AERIEN", "SOUTERRAIN", "IMMEUBLE"]
    liste_capa = [6, 12, 24, 36, 48, 72, 96, 108, 144, 288, 432, 576, 720]
    for elem in liste_type_cable:
        longueur_reelle[elem] = {}
        for capa in liste_capa:
            longueur_reelle[elem][capa] = {6: 0, 12: 0}
    # On parcourt les cables pour répartir leur longueur
    t_cable.selectByExpression(f"cb_statut = '{statut}'")
    for cable in t_cable.selectedFeatures():
        cb_lgreel = float(str(cable["cb_lgreel"]).replace(",", ".")) or 0
        capa = cable["cb_capafo"]
        modulo = cable["cb_modulo"]
        facade = 0
        aerien = 0
        pvc = 0
        pehd = 0
        immeuble = 0
        # La table des cable-cheminement
        # print("avant requete t_cb_cm", datetime.datetime.now(), datetime.datetime.now())
        # Exécuter SQL
        alg_params = {
            "INPUT_DATASOURCES": [],
            "INPUT_GEOMETRY_CRS": QgsCoordinateReferenceSystem("EPSG:2154"),
            "INPUT_GEOMETRY_FIELD": "",
            "INPUT_GEOMETRY_TYPE": 1,
            "INPUT_QUERY": (
                f"select cb_code, cb_capafo, cb_lgreel, t_cab_cond.cc_cd_code, t_conduite.cd_prop, t_conduite.cd_type, t_cheminement.cm_code,t_cheminement.cm_typ_imp, t_conduite.cd_type, length(t_cheminement.geometry) as cm_longueur, t_cheminement.geometry "
                f"from t_cable, t_cab_cond, t_conduite, t_cond_chem, t_cheminement "
                f"where t_cab_cond.cc_cb_code = t_cable.cb_code and t_conduite.cd_code = t_cab_cond.cc_cd_code and t_cond_chem.dm_cd_code = t_conduite.cd_code and t_cheminement.cm_code=t_cond_chem.dm_cm_code and t_cable.cb_code = '{cable['cb_code']}'"
            ),
            "INPUT_UID_FIELD": "",
            "OUTPUT": "TEMPORARY_OUTPUT",
        }
        t_cb_cm = processing.run("qgis:executesql", alg_params)["OUTPUT"]
        # print("après requete t_cb_cm", datetime.datetime.now())
        # print(cable.id(), ' : ', cable.geometry().length(), ' - ', sum([entite.geometry().length() for entite in t_cheminement.selectedFeatures()]))
        # On sélectionne en fonction de la pose souhaitée
        t_cb_cm.selectByExpression("cm_typ_imp in (0,1,2)")
        if t_cb_cm.selectedFeatureCount() > 0:
            longueur_reelle["AERIEN"][capa][modulo] += cb_lgreel

        else:
            t_cb_cm.selectByExpression("cm_typ_imp in (4, 5, 6, 7, 8, 9)")
            if t_cb_cm.selectedFeatureCount() > 0:
                longueur_reelle["SOUTERRAIN"][capa][modulo] += cb_lgreel
            else:
                t_cb_cm.selectByExpression("cm_typ_imp in (3)")
                if t_cb_cm.selectedFeatureCount() > 0:
                    longueur_reelle["IMMEUBLE"][capa][modulo] += cb_lgreel
                else:
                    t_ptech.selectByExpression(f"pt_nd_code = '{cable['cb_nd1']}'")
                    for ptech in t_ptech.selectedFeatures():
                        if ptech["pt_typephy"] == "A":
                            longueur_reelle["AERIEN"][capa][modulo] += cb_lgreel
                        elif ptech["pt_typephy"] == "F":
                            longueur_reelle["AERIEN"][capa][modulo] += cb_lgreel
                        elif ptech["pt_typephy"] == "I":
                            longueur_reelle["IMMEUBLE"][capa][modulo] += cb_lgreel
                        else:
                            longueur_reelle["SOUTERRAIN"][capa][modulo] += cb_lgreel
                    if t_ptech.selectedFeatureCount() == 0:
                        longueur_reelle["IMMEUBLE"][capa][modulo] += cb_lgreel
        for cb_cm in t_cb_cm.getFeatures():
            if cb_cm["cm_typ_imp"] == "2":
                facade += cb_cm["cm_longueur"] or 0
            elif cb_cm["cm_typ_imp"] in ["0", "1"]:
                aerien += cb_cm["cm_longueur"] or 0
            elif cb_cm["cm_typ_imp"] == "3":
                immeuble += cb_cm["cm_longueur"] or 0
            else:
                if cb_cm["cd_type"] == "PEHD":
                    pehd += cb_cm["cm_longueur"] or 0
                else:
                    pvc += cb_cm["cm_longueur"] or 0
        total_cm = facade + aerien + immeuble + pvc + pehd
        if total_cm > 0:
            longueur_reelle["facade"] += facade * cb_lgreel / total_cm
            longueur_reelle["aerien"] += aerien * cb_lgreel / total_cm
            longueur_reelle["immeuble"] += immeuble * cb_lgreel / total_cm
            longueur_reelle["pvc"] += pvc * cb_lgreel / total_cm
            longueur_reelle["pehd"] += pehd * cb_lgreel / total_cm
        else:
            t_ptech.selectByExpression(f"pt_nd_code = '{cable['cb_nd1']}'")
            for ptech in t_ptech.selectedFeatures():
                if ptech["pt_typephy"] == "A":
                    longueur_reelle["aerien"] += cb_lgreel
                elif ptech["pt_typephy"] == "F":
                    longueur_reelle["facade"] += cb_lgreel
                elif ptech["pt_typephy"] == "I":
                    longueur_reelle["immeuble"] += cb_lgreel
                else:
                    longueur_reelle["pvc"] += cb_lgreel
            if t_ptech.selectedFeatureCount() == 0:
                longueur_reelle["immeuble"] += cb_lgreel

    return longueur_reelle


def compte_bpe(
    t_cable_patch201, t_cable, t_ebp, t_ptech, capacite, pose, statut="('REC','EXE')"
):
    dict_pt_typephy = {"A": "POTEAU", "C": "CHAMBRE", "F": "FACADE", "I": "IMMEUBLE"}
    nb_boite = 0
    # On sélectionne les BPE
    # t_ebp.selectByExpression("bp_statut = 'EXE' and bp_typelog = 'BPE' and (bp_avct = 'C' or bp_avct is null or bp_avct = '')")
    t_ebp.selectByExpression(
        f"bp_typelog = 'BPE' and bp_statut in {statut} and bp_avct in ('E', 'C')"
    )
    for ebp in t_ebp.selectedFeatures():
        type_ptech = "IMMEUBLE"
        # On va chercher le type de ptech
        t_ptech.selectByExpression("pt_code = '" + (ebp["bp_pt_code"] or "") + "'")
        for ptech in t_ptech.selectedFeatures():
            type_ptech = dict_pt_typephy[ptech["pt_typephy"]]
            break
        # On va chercher la capa du plus gros cable qui arrive à cette boite

        try:
            capamax = int(ebp["bp_typephy"][-3:])
        except:
            capamax = 0
            t_cable_patch201.selectByExpression(
                f"cb_bp1 = '{ebp['bp_code']}' or cb_bp2 = '{ebp['bp_code']}'"
            )
            for c in t_cable_patch201.selectedFeatures():
                t_cable.selectByExpression(f"cb_code = '{c['cb_code']}'")
                for cb in t_cable.selectedFeatures():
                    if int(cb["cb_capafo"]) > capamax:
                        capamax = int(cb["cb_capafo"])
        if capacite == capamax and type_ptech == pose:
            nb_boite += 1
    return nb_boite


def compte_pbo(t_ebp, t_ptech, capacite, pose, t_nbprise, statut="('REC','EXE')"):
    dict_pt_typephy = {"A": "POTEAU", "C": "CHAMBRE", "F": "FACADE", "I": "IMMEUBLE"}
    nb_boite = 0
    # On sélectionne les PBO
    # t_ebp.selectByExpression("bp_statut = 'EXE' and bp_typelog like 'PBO%' and (bp_avct = 'C' or bp_avct is null or bp_avct = '')")
    t_ebp.selectByExpression(
        f"bp_typelog like 'PBO%' and bp_statut in {statut} and bp_avct in ('E', 'C')"
    )
    for ebp in t_ebp.selectedFeatures():
        type_ptech = "IMMEUBLE"
        nb_prise = 0
        # On va chercher le type de ptech
        t_ptech.selectByExpression("pt_code = '" + (ebp["bp_pt_code"] or "") + "'")
        for ptech in t_ptech.selectedFeatures():
            type_ptech = dict_pt_typephy[ptech["pt_typephy"]]
            break
        t_nbprise.selectByExpression("bp_code = '" + ebp["bp_code"] + "'")
        for nbprise in t_nbprise.selectedFeatures():
            nb_prise = nbprise["nb_prise"]
            # print(ebp["bp_code"], "prise : ", nb_prise)
        if capacite == 6 and nb_prise < 6 and pose == type_ptech:
            nb_boite += 1
        elif capacite == 12 and nb_prise >= 6 and pose == type_ptech:
            nb_boite += 1
    return nb_boite


def compte_raccordement(
    t_cable, t_ebp, t_cable_patch, t_nbprise, statut="('REC','EXE')"
):
    # On initialise les dictionnaires
    dict_raccordement = {}
    dict_piquage = {}
    dict_joint_droit = {}
    dict_alignement = {}
    dict_cable = {}
    capa = [6, 12, 24, 36, 48, 72, 96, 108, 144, 288, 432, 576, 720]
    for elem in capa:
        dict_piquage[elem] = 0
        dict_raccordement[elem] = 0
        dict_joint_droit[elem] = 0
        dict_alignement[elem] = 0
    # On va chercher les types d'épissures dans t_position
    # print("avant requete racc", datetime.datetime.now())
    requete = f"select cs_bp_code, ps_fonct from (select * from t_position where ps_fonct = 'PA') as t_position, t_cassette where ps_cs_code = cs_code group by cs_bp_code, ps_fonct"
    alg_params = {
        "INPUT_DATASOURCES": [],
        "INPUT_GEOMETRY_CRS": QgsCoordinateReferenceSystem("EPSG:2154"),
        "INPUT_GEOMETRY_FIELD": "",
        "INPUT_GEOMETRY_TYPE": 1,
        "INPUT_QUERY": requete,
        "INPUT_UID_FIELD": "",
        "OUTPUT": "TEMPORARY_OUTPUT",
    }
    t_passage = processing.run("qgis:executesql", alg_params)["OUTPUT"]
    # print("apres requete racc", datetime.datetime.now())
    # On sélectionne les BPE
    t_ebp.selectByExpression("bp_avct in ('E', 'C') or bp_avct is NULL")
    for ebp in t_ebp.selectedFeatures():
        # On va chercher les types d'épissures dans t_position
        """print('avant requete racc', datetime.datetime.now())
        requete = f"select cs_bp_code, ps_fonct from (select * from t_position where ps_fonct = 'PA') as t_position, (select * from t_cassette where cs_bp_code = '{ebp['bp_code']}') as t_cassette where ps_cs_code = cs_code group by cs_bp_code, ps_fonct"
        alg_params = {
            'INPUT_DATASOURCES': [],
            'INPUT_GEOMETRY_CRS': QgsCoordinateReferenceSystem('EPSG:2154'),
            'INPUT_GEOMETRY_FIELD': '',
            'INPUT_GEOMETRY_TYPE': 1,
            'INPUT_QUERY': requete,
            'INPUT_UID_FIELD': '',
            'OUTPUT': 'TEMPORARY_OUTPUT'
        }
        t_passage = processing.run('qgis:executesql', alg_params)['OUTPUT']
        print('apres requete racc', datetime.datetime.now())"""
        t_passage.selectByExpression(f"cs_bp_code = '{ebp['bp_code']}'")
        nbpassage = t_passage.selectedFeatureCount()
        liste_cable = []
        t_cable_patch.selectByExpression(
            "cb_bp1 = '" + ebp["bp_code"] + "' or cb_bp2 = '" + ebp["bp_code"] + "'"
        )
        for cable_patch in t_cable_patch.selectedFeatures():
            t_cable.selectByExpression(
                f"cb_code = '{cable_patch['cb_code']}' and (cb_avct in ('E', 'C') or cb_avct is NULL)"
            )
            for cable in t_cable.selectedFeatures():
                liste_cable.append(cable)
        if len(liste_cable) == 1:
            # Si c'est un PBO, c'est un fin de cable
            if ebp["bp_typelog"] == "PBO" and ebp["bp_statut"] in statut:
                capacite = 6
                t_nbprise.selectByExpression(f"bp_code = '{ebp['bp_code']}'")
                for nbprise in t_nbprise.selectedFeatures():
                    if nbprise["nb_prise"] >= 6:
                        capacite = 12
                dict_piquage[capacite] += 1
            # Si c'est une BPE, c'est un alignement de la taille du cable
            elif ebp["bp_typelog"] == "BPE" and ebp["bp_statut"] in statut:
                capacite = liste_cable[0]["cb_capafo"]
                dict_alignement[capacite] += 1
        elif len(liste_cable) == 2:
            if ebp["bp_typelog"] == "BPE" and ebp["bp_statut"] in statut:
                # Si c'est une BPE avec deux capacités identiques, c'est un joint droit de la taille du cable
                if liste_cable[0]["cb_capafo"] == liste_cable[1]["cb_capafo"]:
                    dict_joint_droit[liste_cable[0]["cb_capafo"]] += 1
                # Sinon c'est une dérivation de la taille du cable le plus petit
                else:
                    capamin = min(
                        liste_cable[0]["cb_capafo"], liste_cable[1]["cb_capafo"]
                    )
                    dict_raccordement[capamin] += 1
            elif ebp["bp_typelog"] == "PBO" and ebp["bp_statut"] in statut:
                # Si c'est un PBO avec deux capacités de cable différentes, c'est une dérivation du plus petit
                if liste_cable[0]["cb_capafo"] != liste_cable[1]["cb_capafo"]:
                    capamin = min(
                        liste_cable[0]["cb_capafo"], liste_cable[1]["cb_capafo"]
                    )
                    dict_raccordement[capamin] += 1
                # Sinon c'est un piquage en ligne de la taille du cable s'il y a du passage, ou joint droit s'il n'y a pas de passage
                else:
                    if nbpassage > 0:
                        # Si la capa est supérieure à 12, alors on le met dans 6
                        if liste_cable[0]["cb_capafo"] > 48:
                            dict_piquage[6] += 1
                        else:
                            dict_piquage[liste_cable[0]["cb_capafo"]] += 1
                    else:
                        dict_joint_droit[liste_cable[0]["cb_capafo"]] += 1
        elif len(liste_cable) > 2:
            liste_capa = [cable["cb_capafo"] for cable in liste_cable]
            capamax = max(liste_capa)
            nb_capamax = liste_capa.count(capamax)
            if nb_capamax > 1:
                compteur = 0
                for cable in liste_cable:
                    if cable["cb_capafo"] == capamax and compteur < 2:
                        compteur += 1
                        if cable["cb_statut"] in statut and compteur < 2:
                            # S'il y a su passage, c'est du piquage
                            if nbpassage > 0:
                                # Si la capa est supérieure à 12, alors on le met dans 6
                                if cable["cb_capafo"] > 48:
                                    dict_piquage[6] += 1
                                else:
                                    dict_piquage[cable["cb_capafo"]] += 1
                            else:
                                dict_joint_droit[cable["cb_capafo"]] += 1
                    elif cable["cb_statut"] in statut:
                        dict_raccordement[cable["cb_capafo"]] += 1
            else:
                compteur = 0
                for cable in liste_cable:
                    if cable["cb_capafo"] == capamax and compteur < 1:
                        compteur += 1
                    elif cable["cb_statut"] in statut:
                        dict_raccordement[cable["cb_capafo"]] += 1
    return [dict_raccordement, dict_piquage, dict_joint_droit, dict_alignement]


def ajouter(couche):
    if not QgsProject.instance().mapLayersByName(couche.name()):
        QgsProject.instance().addMapLayer(couche)


def tete_de_cable(nb_cable):
    jusque_1 = 0
    jusque_3 = 0
    jusque_5 = nb_cable // 5
    reste = nb_cable % 5
    if reste == 0:
        pass
    elif reste == 1:
        jusque_1 = 1
    elif reste < 4:
        jusque_3 = 1
    else:
        jusque_5 += 1
    return jusque_1, jusque_3, jusque_5

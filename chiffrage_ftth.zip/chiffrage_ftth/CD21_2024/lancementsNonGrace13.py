import os
from qgis.core import QgsProject
from qgis.utils import iface
from qgis.PyQt.QtWidgets import QProgressBar, QMessageBox
from .dictionnaire_lot1 import remplir_dictionnaire_1
from .dictionnaire_lot3 import remplir_dictionnaire_3
from .fonctionsNonGrace13 import verif_table
from .fonctions_generales import recherche_txt, insert_colonne


def lancement_13(dlg, lot, openpyxl):
    enregistrer = dlg.enregistrer.filePath()
    transport = dlg.transport.isChecked()
    pdfinal = dlg.checkPDFinal.isChecked()
    # On affiche un message
    progressMessageBar = iface.messageBar().createMessage(
        "Patience! Le chiffrage est en cours de préparation..."
    )
    progress = QProgressBar()
    progress.setMaximum(100)
    progressMessageBar.layout().addWidget(progress)
    iface.messageBar().pushWidget(progressMessageBar)
    progress.setValue(0)
    # Initialisation des valeurs
    t_adresse = ""
    t_cable = ""
    t_ebp = ""
    t_ptech = ""
    t_cheminement = ""
    t_zsro = ""
    t_zpbo = ""
    t_site = ""
    layers = QgsProject.instance().mapLayers().values()
    layerList = [""]
    for layer in layers:
        layerList.append(layer.name())
        if layer.name() == "Prises" or layer.name() == "t_adresse":
            t_adresse = layer
        elif layer.name() == "Cables" or layer.name() == "t_cable":
            t_cable = layer
        elif layer.name() == "Boites" or layer.name() == "t_ebp":
            t_ebp = layer
        elif layer.name() == "Point_tech" or layer.name() == "t_ptech":
            t_ptech = layer
        elif layer.name() == "Infra" or layer.name() == "t_cheminement":
            t_cheminement = layer
        elif layer.name() == "ZASRO" or layer.name() == "t_zsro":
            t_zsro = layer
        elif layer.name() == "ZAPBO" or layer.name() == "t_zpbo":
            t_zpbo = layer
        elif layer.name() == "ZPEC" or layer.name() == "t_zpec":
            t_zpec = layer
        elif "SITE" in layer.name() or layer.name() == "t_sitetech":
            t_site = layer
    if transport:
        if not verif_table(t_site, "SITE"):
            QMessageBox.warning(
                None,
                "Erreur",
                f"Impossible de trouver la couche SITE. Veuillez l'ajouter au projet.",
            )
            return False
    else:
        if not verif_table(t_adresse, "Prises"):
            QMessageBox.warning(
                None,
                "Erreur",
                f"Impossible de trouver la couche Prises. Veuillez l'ajouter au projet.",
            )
            return False
    if not verif_table(t_cable, "Cables"):
        QMessageBox.warning(
            None,
            "Erreur",
            f"Impossible de trouver la couche Cables. Veuillez l'ajouter au projet.",
        )
        return False
    if not verif_table(t_cheminement, "Infra"):
        QMessageBox.warning(
            None,
            "Erreur",
            f"Impossible de trouver la couche Infra. Veuillez l'ajouter au projet.",
        )
        return False
    if not verif_table(t_ptech, "Point_tech"):
        QMessageBox.warning(
            None,
            "Erreur",
            f"Impossible de trouver la couche Point_tech. Veuillez l'ajouter au projet.",
        )
        return False
    if not verif_table(t_ebp, "Boites"):
        QMessageBox.warning(
            None,
            "Erreur",
            f"Impossible de trouver la couche Boites. Veuillez l'ajouter au projet.",
        )
        return False
    # On va chercher le fichier BDC indiqué par l'utilisateur
    if not pdfinal:
        if lot == "3 - SOGETREL":
            fichierBDC_path = (
                os.path.abspath(os.path.dirname(__file__))
                + r"/CHIFFRAGE LOT 3 SOGETREL.xlsx"
            )
        elif lot == "1 - EIFFAGE":
            fichierBDC_path = (
                os.path.abspath(os.path.dirname(__file__))
                + r"/CHIFFRAGE LOT 1 EIFFAGE.xlsx"
            )
        fichierBDC = openpyxl.load_workbook(fichierBDC_path)
        # On l'enregistre dans le répertoire choisi par l'utilisateur
        chemin_sauvegarde = enregistrer + "\BDC_FMP.xlsx"
    else:
        if len(dlg.fichierDecompte.filePath()) > 0:
            fichierBDC = openpyxl.load_workbook(dlg.fichierDecompte.filePath())
            # On l'enregistre dans le répertoire choisi par l'utilisateur
            chemin_sauvegarde = enregistrer + "\MOE_Projet_de_Decompte_General_BDC.xlsx"
        else:
            QMessageBox.information(
                None,
                "Erreur",
                "Veuillez renseigner un fchier de décompte final.",
            )
            return False
    try:
        fichierBDC.save(chemin_sauvegarde)
    except:
        fichierBDC.close()
        QMessageBox.information(
            None,
            "Erreur",
            "Erreur lors de l'enregistrement. Un fichier du même nom est déjà ouvert? Veuillez le fermer avant de lancer l'outil.",
        )
        return False
    if lot == "1 - EIFFAGE":
        dict_rec_article = remplir_dictionnaire_1(
            transport, t_cable, t_ptech, t_ebp, t_cheminement, t_adresse, t_site, "REC"
        )
        dict_exe_article = remplir_dictionnaire_1(
            transport, t_cable, t_ptech, t_ebp, t_cheminement, t_adresse, t_site, "EXE"
        )
    elif lot == "3 - SOGETREL":
        dict_doe_article = remplir_dictionnaire_3(
            transport, t_cable, t_ptech, t_ebp, t_cheminement, t_adresse, t_site, "DOE"
        )
        dict_exe_article = remplir_dictionnaire_3(
            transport, t_cable, t_ptech, t_ebp, t_cheminement, t_adresse, t_site, "EXE"
        )
        dict_rec_article = remplir_dictionnaire_3(
            transport, t_cable, t_ptech, t_ebp, t_cheminement, t_adresse, t_site, "REC"
        )
    # On remplit l'excel
    feuilleBDC = fichierBDC.worksheets[0]
    if not pdfinal:
        colonne = 6
        ligne_depart = 3
        nrow = feuilleBDC.max_row
        for ligne in range(ligne_depart, nrow + 1):
            if lot == "3 - SOGETREL":
                feuilleBDC.cell(
                    row=ligne,
                    column=colonne,
                    value=dict_rec_article.get(
                        feuilleBDC.cell(row=ligne, column=1).value, 0
                    )
                    + dict_doe_article.get(
                        feuilleBDC.cell(row=ligne, column=1).value, 0
                    )
                    or None,
                )
            else:
                feuilleBDC.cell(
                    row=ligne,
                    column=colonne,
                    value=dict_rec_article.get(
                        feuilleBDC.cell(row=ligne, column=1).value
                    ),
                )
            feuilleBDC.cell(
                row=ligne,
                column=colonne + 1,
                value=dict_exe_article.get(feuilleBDC.cell(row=ligne, column=1).value),
            )
    else:
        # On insert les deux premières colonnes
        q_col, q_row = recherche_txt(feuilleBDC, "Quantité calculé par le MOE")
        if not q_col:
            q_col, q_row = recherche_txt(feuilleBDC, "Numéro du BDC")
            insert_colonne(feuilleBDC, q_col)
            feuilleBDC.cell(
                row=q_row,
                column=q_col + 1,
                value="Quantité calculé par le MOE",
            )
            feuilleBDC.cell(
                row=q_row,
                column=q_col + 2,
                value="Montant calculé MOE",
            )
            q_col += 1
        # On insert les deux dernières
        z_col, z_row = recherche_txt(feuilleBDC, "Quantité des travaux non exécutés")
        if not z_col:
            z_col, z_row = recherche_txt(feuilleBDC, "Quantité restante")
            insert_colonne(feuilleBDC, z_col)
            feuilleBDC.cell(
                row=z_row,
                column=z_col + 1,
                value="Quantité des travaux non exécutés",
            )
            feuilleBDC.cell(
                row=z_row,
                column=z_col + 2,
                value="Montant des travaux non exécuté",
            )
            z_col += 1
        qbdc_col, qbdc_row = recherche_txt(feuilleBDC, "Quantité du BDC")
        pu_col, pu_row = recherche_txt(feuilleBDC, "P.U. HT")
        l_qbdc_col = openpyxl.utils.get_column_letter(qbdc_col)
        l_pu_col = openpyxl.utils.get_column_letter(pu_col)
        l_q_col = openpyxl.utils.get_column_letter(q_col)
        l_m_col = openpyxl.utils.get_column_letter(q_col + 1)
        l_qt_col = openpyxl.utils.get_column_letter(z_col)
        l_mt_col = openpyxl.utils.get_column_letter(z_col + 1)
        # On remplit l'excel
        article_col, article_row = recherche_txt(feuilleBDC, "Article du BDC")
        colonne = q_col
        ligne_depart = q_row + 1
        nrow = feuilleBDC.max_row
        for ligne in range(ligne_depart, nrow + 1):
            if len(feuilleBDC.cell(row=ligne, column=article_col + 1).value or "") > 0:
                # print("ligne", ligne)
                if lot == "3 - SOGETREL":
                    feuilleBDC.cell(
                        row=ligne,
                        column=colonne,
                        value=dict_rec_article.get(
                            feuilleBDC.cell(row=ligne, column=article_col).value, 0
                        )
                        + dict_doe_article.get(
                            feuilleBDC.cell(row=ligne, column=article_col).value, 0
                        )
                        or None,
                    )
                else:
                    feuilleBDC.cell(
                        row=ligne,
                        column=colonne,
                        value=dict_rec_article.get(
                            feuilleBDC.cell(row=ligne, column=article_col).value
                        ),
                    )
                feuilleBDC.cell(
                    row=ligne,
                    column=colonne + 1,
                    value=f"={l_q_col}{ligne}*{l_pu_col}{ligne}",
                )
                feuilleBDC.cell(
                    row=ligne,
                    column=z_col,
                    value=f"==IF({l_qbdc_col}{ligne}=0,0,{l_qbdc_col}{ligne}-{l_q_col}{ligne})",
                )
                feuilleBDC.cell(
                    row=ligne,
                    column=z_col + 1,
                    value=f"={l_qt_col}{ligne}*{l_pu_col}{ligne}",
                )

    fichierBDC.save(chemin_sauvegarde)
    fichierBDC.close()
    iface.messageBar().clearWidgets()
    iface.messageBar().pushMessage(
        "Bravo!", "L'excel de chiffrage est prêt", level=3, duration=180
    )

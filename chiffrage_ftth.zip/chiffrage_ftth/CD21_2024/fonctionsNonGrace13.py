from math import ceil
import re


def tete_de_cable(nb_cable):
    jusque_1 = 0
    jusque_3 = 0
    jusque_5 = nb_cable // 5
    reste = nb_cable % 5
    if reste == 0:
        pass
    elif reste == 1:
        jusque_1 = 1
    elif reste < 4:
        jusque_3 = 1
    else:
        jusque_5 += 1
    return jusque_1, jusque_3, jusque_5


def longueur_cable(t_cable, pose, capacite, statut="DOE"):
    t_cable.selectByExpression(
        f"cb_statut = '{statut}' and to_int(cb_capafo) = {capacite} and TYPE ='{pose}'"
    )
    return ceil(
        sum(
            [
                float(str(cable["cb_lgreel"]).replace(",", "."))
                for cable in t_cable.selectedFeatures()
            ]
        )
    )


def calcul_longueur_pose(t_cable, t_cheminement, statut="DOE"):
    dict_pose = {
        "aerien": 0,
        "facade": 0,
        "immeuble": 0,
        "libre": 0,
        "occupe": 0,
    }
    t_cable.selectByExpression(f"cb_statut = '{statut}'")
    for cable in t_cable.selectedFeatures():
        facade = 0
        aerien = 0
        immeuble = 0
        libre = 0
        occupe = 0
        t_cheminement.selectByExpression(
            f"within($geometry, buffer(geom_from_wkt('{cable.geometry().asWkt()}'), 0.3))"
        )
        for cheminement in t_cheminement.selectedFeatures():
            if cheminement["cm_typ_imp"] in ["AERIEN", "0", "1"]:
                aerien += float(str(cheminement["cm_long"]).replace(",", "."))
            elif cheminement["cm_typ_imp"] in ["FACADE", "2"]:
                facade += float(str(cheminement["cm_long"]).replace(",", "."))
            elif cheminement["cm_typ_imp"] in ["IMMEUBLE", "3"]:
                immeuble += float(str(cheminement["cm_long"]).replace(",", "."))
            elif cheminement["cm_typ_imp"] in ["CONDUITE", "7"]:
                if cheminement["cm_avct"] in ["CREATION", "C"]:
                    libre += float(str(cheminement["cm_long"]).replace(",", "."))
                else:
                    occupe += float(str(cheminement["cm_long"]).replace(",", "."))
        if aerien + facade + immeuble + libre + occupe == 0:
            dict_pose["occupe"] += float(str(cable["cb_lgreel"]).replace(",", "."))
        else:
            coeff = float(str(cable["cb_lgreel"]).replace(",", ".")) / (
                aerien + facade + immeuble + libre + occupe
            )
            dict_pose["aerien"] += coeff * aerien
            dict_pose["facade"] += coeff * facade
            dict_pose["immeuble"] += coeff * immeuble
            dict_pose["libre"] += coeff * libre
            dict_pose["occupe"] += coeff * occupe
    return dict_pose


def compte_boites(t_ebp, t_ptech, t_adresse, t_cable, capacite, pose, statut):
    compt = 0
    # On compte les PBO selon les prises
    if capacite == 6:
        t_ebp.selectByExpression(
            f"cb_statut = '{statut}' and bp_typelog like 'PB%' and NB_PRISES < 6"
        )
    elif capacite == 12:
        t_ebp.selectByExpression(
            f"cb_statut = '{statut}' and bp_typelog like 'PB%' and NB_PRISES > 5"
        )
    else:
        t_ebp.removeSelection()
    for ebp in t_ebp.selectedFeatures():
        t_ptech.selectByExpression(
            f"intersects(buffer($geometry, 0.01),  geom_from_wkt('{ebp.geometry().asWkt()}'))"
        )
        for ptech in t_ptech.selectedFeatures():
            if ptech["TYPE_STRUC"] == pose:
                compt += 1
                break
        if t_ptech.selectedFeatureCount() == 0 and pose == "IMMEUBLE":
            t_adresse.selectByExpression(
                f"intersects(buffer($geometry, 0.01),  geom_from_wkt('{ebp.geometry().asWkt()}'))"
            )
            if t_adresse.selectedFeatureCount() > 0:
                compt += 1
    # On compte les BPE selon le plus gros cable
    t_ebp.selectByExpression(
        f"cb_statut = '{statut}' and bp_typelog in ('BPE','PEC','PEP')"
    )
    for ebp in t_ebp.selectedFeatures():
        print("je suis bien un boitier du bon statut")
        t_cable.selectByExpression(
            f"replace(EQ_A, ' ', '') = replace('{ebp['BPE_NOM']}', ' ', '') or replace(EQ_B, ' ', '') = replace('{ebp['BPE_NOM']}', ' ', '')"
        )
        if t_cable.selectedFeatureCount() > 0:
            capamax = max(
                [
                    int(re.findall("\d+", str(cable["cb_capafo"]))[0])
                    for cable in t_cable.selectedFeatures()
                ]
            )
        else:
            capamax = int(re.findall("\d+", str(ebp["bp_typephy"]))[0])
        print("j'ai une capamax de", capamax)
        if capamax == capacite:
            t_ptech.selectByExpression(
                f"intersects(buffer($geometry, 0.01),  geom_from_wkt('{ebp.geometry().asWkt()}'))"
            )
            for ptech in t_ptech.selectedFeatures():
                if ptech["TYPE_STRUC"] == pose:
                    compt += 1
                    break
            if t_ptech.selectedFeatureCount() == 0 and pose == "IMMEUBLE":
                t_adresse.selectByExpression(
                    f"intersects(buffer($geometry, 0.01),  geom_from_wkt('{ebp.geometry().asWkt()}'))"
                )
                if t_adresse.selectedFeatureCount() > 0:
                    compt += 1
    return compt


def compte_raccordement(t_cable, t_ebp, statut):
    # On initialise les dictionnaires
    dict_raccordement = {}
    dict_piquage = {}
    dict_joint_droit = {}
    dict_alignement = {}

    capa = [6, 12, 24, 36, 48, 72, 144, 288, 432, 576, 720]
    for elem in capa:
        dict_piquage[elem] = 0
        dict_raccordement[elem] = 0
        dict_joint_droit[elem] = 0
        dict_alignement[elem] = 0

    t_ebp.selectAll()
    for ebp in t_ebp.selectedFeatures():
        liste_cable = []
        t_cable.selectByExpression(
            f"replace(EQ_A, ' ', '') = replace('{ebp['BPE_NOM']}', ' ', '') or replace(EQ_B, ' ', '') = replace('{ebp['BPE_NOM']}', ' ', '')"
        )
        for cable in t_cable.selectedFeatures():
            liste_cable.append(cable)
        # S'il n'y a qu'un seul cable
        if len(liste_cable) <= 1:
            # Si sur une boite il n'y a qu'un seul cable sortant, alors on considère que c'est un alignement
            if ebp["bp_typelog"] in ["BPE", "PEC", "PEP"]:
                for cable in liste_cable:
                    if cable["cb_statut"] == statut:
                        dict_alignement[
                            int(re.findall("\d+", str(cable["cb_capafo"]))[0])
                        ] += 1
            else:
                # Sinon c'est une fin cable que l'on compte en piquage de la taille du boitier
                for cable in liste_cable:
                    capa = 6
                    if ebp["NB_PRISES"] > 5:
                        capa = 12
                    if cable["cb_statut"] == statut:
                        dict_piquage[capa] += 1
        # S'il y a deux cables
        elif len(liste_cable) == 2:
            # Si les cables ont la même capa, c'est un joint droit
            if liste_cable[0]["cb_capafo"] == liste_cable[1]["cb_capafo"]:
                # Si c'est une BPE
                if ebp["bp_typelog"] in ["BPE", "PEC", "PEP"]:
                    if liste_cable[0]["cb_statut"] == statut:
                        dict_joint_droit[liste_cable[0]["cb_capafo"]] += 1
                # Sinon c'est un piquage de la taille du cable
                else:
                    capa = max(liste_cable[0]["cb_capafo"], liste_cable[1]["cb_capafo"])
                    if liste_cable[0]["cb_statut"] == statut:
                        dict_piquage[capa] += 1
            # Sinon c'est une derivation du plus petit
            else:
                capa = min(liste_cable[0]["cb_capafo"], liste_cable[1]["cb_capafo"])
                if liste_cable[0]["cb_statut"] == statut:
                    dict_raccordement[capa] += 1

        else:
            liste_capa = [
                int(re.findall("\d+", str(cable["cb_capafo"]))[0])
                for cable in liste_cable
            ]
            capamax = max(liste_capa)
            nb_capamax = liste_capa.count(capamax)
            if nb_capamax > 1:
                compteur = 0
                for cable in liste_cable:
                    if (
                        int(re.findall("\d+", str(cable["cb_capafo"]))[0]) == capamax
                        and compteur < 2
                    ):
                        compteur += 1
                        if compteur < 2:
                            if cable["cb_statut"] == statut:
                                dict_piquage[
                                    int(re.findall("\d+", str(cable["cb_capafo"]))[0])
                                ] += 1
                    else:
                        if cable["cb_statut"] == statut:
                            dict_raccordement[
                                int(re.findall("\d+", str(cable["cb_capafo"]))[0])
                            ] += 1
            else:
                compteur = 0
                for cable in liste_cable:
                    if (
                        int(re.findall("\d+", str(cable["cb_capafo"]))[0]) == capamax
                        and compteur < 1
                    ):
                        compteur += 1
                    else:
                        if cable["cb_statut"] == statut:
                            dict_raccordement[
                                int(re.findall("\d+", str(cable["cb_capafo"]))[0])
                            ] += 1
    return [dict_raccordement, dict_piquage, dict_joint_droit, dict_alignement]


def verif_table(t_table, t_name):
    if t_table == "":
        return False
    else:
        return True

from .fonctionsGraceAB import lancement_AB
from .lancementsNonGrace13 import lancement_13


def chiffrage_cd21(dlg, openpyxl):
    lot = dlg.lot.currentText()
    if lot in ["2 - RESONANCE", "3 - SOGETREL (GraceTHD)"]:
        lancement_AB(dlg, lot, openpyxl)
    elif lot in ["1 - EIFFAGE", "3 - SOGETREL"]:
        lancement_13(dlg, lot, openpyxl)
    elif lot in ["A - SOGETREL", "B - RESONANCE"]:
        lancement_AB(dlg, lot, openpyxl)

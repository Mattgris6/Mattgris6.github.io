from copy import copy
import re


def recherche_txt(feuilleBDC, txt):
    # Variables pour stocker la position de la cellule contenant "test"
    target_col = None
    target_row = None

    # Parcourir toutes les cellules pour trouver "Numéro du BDC"
    for row in feuilleBDC.iter_rows():
        for cell in row:
            if cell.value and txt == str(cell.value):
                target_col = cell.column
                target_row = cell.row
                break
        if target_col:
            break
    if not target_col:
        print(f"Aucune cellule contenant '{txt}' n'a été trouvée")
    return target_col, target_row


def insert_colonne(feuilleBDC, target_col):
    # Stocker toutes les formules et leurs positions
    formulas = {}
    for row in feuilleBDC.iter_rows():
        for cell in row:
            if (
                cell.column > target_col
                and isinstance(cell.value, str)
                and cell.value.startswith("=")
            ):
                formulas[(cell.row, cell.column)] = cell.value
    # Insérer deux colonnes après la colonne trouvée
    feuilleBDC.insert_cols(target_col + 1, 2)
    # Copier le style de la colonne précédente vers les deux nouvelles colonnes
    copy_column_style(
        feuilleBDC, target_col, target_col + 1
    )  # Pour la première nouvelle colonne
    copy_column_style(
        feuilleBDC, target_col, target_col + 2
    )  # Pour la deuxième nouvelle colonne
    # Mettre à jour et réappliquer les formules
    for (row, col), formula in formulas.items():
        # Ajuster la position de la cellule en fonction des colonnes insérées
        new_col = col + 2 if col > target_col else col
        # Mettre à jour la formule
        new_formula = update_formula_references(formula, target_col, 2)
        feuilleBDC.cell(row=row, column=new_col, value=new_formula)
    print(
        f"Deux colonnes ont été insérées après la colonne {feuilleBDC.cell(row=1, column=target_col).coordinate}"
    )
    print("Les formules ont été mises à jour")


def update_formula_references(formula, insert_col, num_cols):
    """Met à jour les références de colonnes dans une formule"""
    # Pattern pour trouver les références de cellules (ex: A1, $B$2, C3)
    pattern = r"(\$?)([A-Z]+)(\$?)(\d+)"

    def shift_column(match):
        dollar1, col, dollar2, row = match.groups()
        # Convertir la lettre de colonne en nombre
        col_num = 0
        for c in col:
            col_num = col_num * 26 + (ord(c.upper()) - ord("A") + 1)

        # Si la colonne est après le point d'insertion, la décaler
        if col_num > insert_col:
            col_num += num_cols

        # Reconvertir le numéro en lettres
        new_col = ""
        while col_num > 0:
            col_num, remainder = divmod(col_num - 1, 26)
            new_col = chr(ord("A") + remainder) + new_col

        return f"{dollar1}{new_col}{dollar2}{row}"

    return re.sub(pattern, shift_column, formula)


def copy_column_style(ws, source_col, target_col):
    """Copie le style d'une colonne vers une autre"""
    for row in ws.iter_rows():
        source_cell = row[source_col - 1]  # -1 car les indices commencent à 0
        target_cell = row[target_col - 1]

        if source_cell.has_style:
            target_cell._style = copy(source_cell._style)

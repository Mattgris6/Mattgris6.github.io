from qgis.core import  QgsProject, QgsLayoutExporter
import os
import shutil

def lancement(self):
    # On récupère les données du formulaire
    filtre_zone = self.dlg.filtre_zone.currentText()
    filtre_oa = self.dlg.filtre_oa.currentText()
    if filtre_oa == 'Tous les OA en un seul pdf':
        fichier_unique = True
    else:
        fichier_unique = False
    # On récupère les couches utiles
    layers = QgsProject.instance().mapLayers().values()
    for l in layers:
        if l.name() == "Ltech":
            t_ltech = l
        elif l.name() == "grappe_atlas":
            t_grappe = l
        elif l.name() == "grid":
            t_grid = l
        elif l.name() == "cadre":
            t_cadre = l
        elif l.name() == "lien":
            t_lien = l
        elif l.name() == "OA":
            t_oa = l
        elif l.name() == "SGP_Lignes_Site":
            t_ligne = l
    # On créer les dictionnaires pour récupérer les OA à partir des Ltech et le nombre de pages par OA
    dict_oa = {}
    dict_num_page = {}
    dict_increm = {}
    for ltech in t_ltech.getFeatures():
        dict_oa[ltech['ref']] = ltech['OA']
        t_grappe.selectByExpression(f"attribute(get_feature('Ltech','ref', OA_depart ),'zone')='{filtre_zone}' and attribute(get_feature('Ltech','ref', OA_depart ),'oa') = '{ltech['OA']}'")
        dict_num_page[ltech['OA']] = t_grappe.selectedFeatureCount()
    # On récupère le nombre total de page dans le cas d'un export unique
    if fichier_unique:
        # Le nombre de page test
        t_grappe.selectByExpression(f"attribute(get_feature('Ltech','ref', OA_depart ),'zone')='{filtre_zone}'")
        nb_page_total = t_grappe.selectedFeatureCount()
        # Le nombre de page OA
        liste_ltech = []
        t_lien.selectByExpression(f"zone = '{filtre_zone}'")
        for lien in t_lien.selectedFeatures():
            liste_ltech.append(lien["OA_dep"])
            liste_ltech.append(lien["OA_arr"])
        liste_oa = []
        for ltech in t_ltech.getFeatures():
            if ltech["ref"] in liste_ltech and ltech["oa"] not in liste_oa:
                liste_oa.append(ltech['OA'])
        nb_page_total += len(liste_oa) + 3
    # On dit où on veut enregistrer les exports
    # outputs_folder = r"C:/Users/MatthieuGRISON/Downloads/SGP_ATLAS - Base Grappe/Export"
    outputs_folder = self.dlg.chemin_sauvegarde.filePath()
    dict_pdf = {}
    ##################################################################################################################### 
    ##################################################################################################################### 
    # On commence avec la page de garde si on exporte tout en un seul fichier
    if fichier_unique:
        lay = QgsProject.instance().layoutManager().layoutByName('01_Atlas_Page_Garde')
        my_atlas = lay.atlas()
        my_atlas.setFilterExpression(f"grid='Masse' and OA = '{filtre_zone}'")
        my_atlas.beginRender()
        while my_atlas.next():
            # On met à jour le foliotage
            num_page = my_atlas.layout().itemById('num_page')
            num_page.setText(f"01/{str(nb_page_total).zfill(2)}")
            # On exporte la page
            atlas_layout=my_atlas.layout()
            if not os.path.exists(f"{outputs_folder}/000_PdG"):
                os.makedirs(f"{outputs_folder}/000_PdG")
            pdfpath = f"{outputs_folder}/000_PdG/00_Page de garde.pdf"                    
            exporter = QgsLayoutExporter(atlas_layout)
            exporter.exportToPdf(pdfpath,exporter.PdfExportSettings())
            dict_pdf['000_PdG'] = [pdfpath]
        my_atlas.endRender()
        # On génère la légende
        lay = QgsProject.instance().layoutManager().layoutByName('05_Legende')
        my_atlas = lay.atlas()
        my_atlas.setFilterExpression(f"grid='Schema_v' and OA = '{filtre_zone}'")
        my_atlas.beginRender()
        while my_atlas.next():
            # On met à jour le foliotage
            num_page = my_atlas.layout().itemById('num_page')
            num_page.setText(f"02/{str(nb_page_total).zfill(2)}")
            # On exporte la page
            atlas_layout=my_atlas.layout()
            if not os.path.exists(f"{outputs_folder}/001_LEG"):
                os.makedirs(f"{outputs_folder}/001_LEG")
            pdfpath = f"{outputs_folder}/001_LEG/02_Legende.pdf"                    
            exporter = QgsLayoutExporter(atlas_layout)
            exporter.exportToPdf(pdfpath,exporter.PdfExportSettings())
            dict_pdf['001_LEG'] = [pdfpath]
        my_atlas.endRender()
        #On prépare la page de garde pour conserver l'ordre dans le dict_pdf
        dict_pdf['002_PdM'] = []
    else:
        ########################################################################################################
        ########################################################################################################
        print("j'existe")
        # On fait la légende
        lay = QgsProject.instance().layoutManager().layoutByName('05_Legende_OA')
        my_atlas = lay.atlas()
        if 'Tous les OA' in filtre_oa:
            my_atlas.setFilterExpression(f"regexp_match(aggregate('Ltech', 'concatenate_unique',OA, regexp_match( concat(aggregate( 'lien','concatenate_unique',OA_dep,zone = '{filtre_zone}' ,' ; '),' ; ', aggregate( 'lien','concatenate_unique',OA_arr,zone = '{filtre_zone}',' ; ')),ref),' ; '),ref)")
        else:
            my_atlas.setFilterExpression(f"ref = '{filtre_oa}'")
        # On ajuste la symbologie des couches pour l'encartage
        # Pour les lignes
        rule=t_ligne.renderer().rootRule().children()[0]
        rule.setFilterExpression(f"ref = '{filtre_zone}'")
        # Pour les points
        rule=t_oa.renderer().rootRule().children()[0]
        rule.setFilterExpression(f"regexp_match( aggregate('Ltech', 'concatenate_unique',OA,  zone ='{filtre_zone}',' ; '), ref )")
        # On récupère l'emprise du schema
        t_grid.selectByExpression(f"OA='{filtre_zone}' and grid = 'Schema_v'")
        for grid in t_grid.selectedFeatures():
            grid_rect = grid.geometry().boundingBox()
        # On corrige l'emprise du schema
        carte_schema = my_atlas.layout().itemById('Schema')
        carte_schema.zoomToExtent(grid_rect)
        # On récupère l'emprise de la légende
        t_grid.selectByExpression(f"OA='{filtre_zone}' and grid = 'Legende'")
        for grid in t_grid.selectedFeatures():
            grid_rect = grid.geometry().boundingBox()
        # On corrige l'emprise de la légende
        carte_legende = my_atlas.layout().itemById('Legende')
        carte_legende.zoomToExtent(grid_rect)
        # On récupère l'emprise de la carte
        t_grid.selectByExpression(f"OA='{filtre_zone}' and grid = 'Masse'")
        for grid in t_grid.selectedFeatures():
            grid_rect = grid.geometry().boundingBox()
        # On corrige l'emprise de la carte
        carte_situation = my_atlas.layout().itemById('Plan de situation')
        carte_situation.zoomToExtent(grid_rect)
        # On corrige le nom de la zone
        nom_zone = my_atlas.layout().itemById('nom_zone')
        texte_zone = f"{filtre_zone.replace('L','Ligne ').replace('S', ' SUD').replace('-Z', ' - Zone ')}\nEssais de mandrinage PEHD - Plan de récolement"
        nom_zone.setText(texte_zone)
        my_atlas.beginRender()
        while my_atlas.next():
            print("je fonctionne")
            # On met à jour le foliotage
            num_page = my_atlas.layout().itemById('num_page')
            nb_de_page = dict_num_page.get(my_atlas.currentFilename(), 0) + 2
            num_page.setText(f"01/{str(nb_de_page).zfill(2)}")
            # On exporte la page
            atlas_layout=my_atlas.layout()
            if not os.path.exists(f"{outputs_folder}/{my_atlas.currentFilename()}"):
                os.makedirs(f"{outputs_folder}/{my_atlas.currentFilename()}")
            pdfpath = f"{outputs_folder}/{my_atlas.currentFilename()}/01_{my_atlas.currentFilename()}.pdf"     
            print(pdfpath)               
            exporter = QgsLayoutExporter(atlas_layout)
            exporter.exportToPdf(pdfpath,exporter.PdfExportSettings())
            dict_pdf[my_atlas.currentFilename()] = [pdfpath]
        my_atlas.endRender()
    ##################################################################################################################### 
    ##################################################################################################################### 
    # On commence avec l'atlas de OA
    if fichier_unique:
        lay = QgsProject.instance().layoutManager().layoutByName('03_Atlas_OA')
    else:
        lay = QgsProject.instance().layoutManager().layoutByName('03_Atlas_OA_Plan')
    my_atlas = lay.atlas()
    # On filtre selon les renseignements de l'utilisateur
    if 'Tous les OA' in filtre_oa:
        my_atlas.setFilterExpression(f"regexp_match(aggregate('Ltech', 'concatenate_unique',OA, regexp_match( concat(aggregate( 'lien','concatenate_unique',OA_dep,zone = '{filtre_zone}' ,' ; '),' ; ', aggregate( 'lien','concatenate_unique',OA_arr,zone = '{filtre_zone}',' ; ')),ref),' ; '),ref)")
    else:
        my_atlas.setFilterExpression(f"ref = '{filtre_oa}'")
    # On récupère l'emprise du schema
    if fichier_unique:
        t_grid.selectByExpression(f"OA='{filtre_zone}' and grid = 'Schema_v'")
        for grid in t_grid.selectedFeatures():
            grid_rect = grid.geometry().boundingBox()
        # On corrige l'emprise du schema
        carte_schema = my_atlas.layout().itemById('schema')
        carte_schema.zoomToExtent(grid_rect)
    # On corrige le nom de la zone
    nom_zone = my_atlas.layout().itemById('nom_zone')
    texte_zone = f"{filtre_zone.replace('L','Ligne ').replace('S', ' SUD').replace('-Z', ' - Zone ')}\nEssais de mandrinage PEHD - Plan de récolement"
    nom_zone.setText(texte_zone)
    # On corrige la symbologie des Ltech pour ne sélectionner que ceux de la zone choisie
    rule=t_ltech.renderer().rootRule().children()[0]
    rule.setFilterExpression(f"zone = '{filtre_zone}'")
    # On parcourt l'atlas pour imprimer chaque page, en mettant à jour le numéro de page
    my_atlas.beginRender()
    increm = 4
    while my_atlas.next():
        # On met à jour le foliotage
        num_page = my_atlas.layout().itemById('num_page')
        nb_de_page = dict_num_page.get(my_atlas.currentFilename(), 0)
        if not fichier_unique:
            num_page.setText(f"02/{str(nb_de_page + 2).zfill(2)}")
        else:
            num_page.setText(f"{str(increm).zfill(2)}/{str(nb_page_total).zfill(2)}")
            dict_increm[my_atlas.currentFilename()] = increm
            increm += nb_de_page + 1
        #On récupère l'emprise du plan
        t_grid.selectByExpression(f"OA='{my_atlas.currentFilename()}' and grid = 'OA'")
        for grid in t_grid.selectedFeatures():
            grid_rect = grid.geometry().boundingBox()
        # On corrige l'emprise du plan
        it_carte_oa = my_atlas.layout().itemById('carte_oa')
        it_carte_oa.zoomToExtent(grid_rect)
        # On ajuste l'échelle de 500 à 2000
        distance = max(grid_rect.xMaximum() - grid_rect.xMinimum(), grid_rect.yMaximum() - grid_rect.yMinimum())
        if distance < 70:
            it_carte_oa.setScale(200)
        elif distance < 150:
            it_carte_oa.setScale(500)
        elif distance < 200:
            it_carte_oa.setScale(750)
        elif distance < 300:
            it_carte_oa.setScale(1000)
        else:
            it_carte_oa.setScale(2000)
        # On met à jour l'échelle
        it_carte_oa = my_atlas.layout().itemById('carte_oa')
        echelle = round(it_carte_oa.scale())
        it_echelle = my_atlas.layout().itemById('echelle')
        it_echelle.setText(f"1/{echelle}")
        # On exporte la page
        atlas_layout=my_atlas.layout()
        if not os.path.exists(f"{outputs_folder}/{my_atlas.currentFilename()}"):
            os.makedirs(f"{outputs_folder}/{my_atlas.currentFilename()}")
        pdfpath = f"{outputs_folder}/{my_atlas.currentFilename()}/02_{my_atlas.currentFilename()}.pdf"                    
        exporter = QgsLayoutExporter(atlas_layout)
        exporter.exportToPdf(pdfpath,exporter.PdfExportSettings())
        if fichier_unique:
            dict_pdf[my_atlas.currentFilename()] = [pdfpath]
        else:
            dict_pdf[my_atlas.currentFilename()].append(pdfpath)
    my_atlas.endRender()
    # return False
    ########################################################################################################################## 
    ########################################################################################################################## 
    # On continue avec l'atlas test
    lay = QgsProject.instance().layoutManager().layoutByName('04_Atlas_Test_Vertical')
    my_atlas = lay.atlas()
    if 'Tous les OA' in filtre_oa:
        my_atlas.setFilterExpression(f"attribute(get_feature('Ltech','ref', OA_depart ),'zone')='{filtre_zone}'")
    else:
        my_atlas.setFilterExpression(f"attribute(get_feature('Ltech','ref', OA_depart ),'zone')='{filtre_zone}' and attribute(get_feature('Ltech','ref', OA_depart ),'oa') = '{filtre_oa}'")
    my_atlas.beginRender()
    oa_depart = ''
    npage = 0
    largeur_defaut = 35
    # On parcourt l'atlas
    while my_atlas.next() or npage < 4:
        # On récupère l'OA de départ dans le nom de la page
        ltech_depart = my_atlas.currentFilename().split(' vers ')[0]
        ltech_arrive = my_atlas.currentFilename().split(' vers ')[1]
        if oa_depart != dict_oa.get(ltech_depart, ''):
            oa_depart = dict_oa.get(ltech_depart, '')
            if not fichier_unique:
                npage = 3
            else:
                npage = dict_increm.get(oa_depart, 0) + 1
        else:
            npage += 1
        # On met à jour le numero de page
        num_page = my_atlas.layout().itemById('num_page')
        if not fichier_unique:
            nb_de_page = dict_num_page.get(oa_depart, 0) + 2
            num_page.setText(f"{str(npage).zfill(2)}/{str(nb_de_page).zfill(2)}")
        else:
            num_page.setText(f"{str(npage).zfill(2)}/{str(nb_page_total).zfill(2)}")
        # On ajuste l'étendue de la carte alveole de depart
        masque_dep = my_atlas.layout().itemById('masque_dep')
        t_cadre.selectByExpression(f"OA='{ltech_depart}'")
        if t_cadre.selectedFeatureCount() == 0:
            t_cadre.selectByExpression(f"OA='Information manquante'")
        for cadre in t_cadre.selectedFeatures():
            cadre_rect = cadre.geometry().boundingBox()
        if cadre_rect.xMaximum() - cadre_rect.xMinimum() > largeur_defaut:
            # On corrige
            t_grappe.selectByExpression(f"OA_depart = '{ltech_depart}' and OA_arrive = '{ltech_arrive}'")
            for grappe in t_grappe.selectedFeatures():
                grappe_rect = grappe.geometry().boundingBox()
            largeur = grappe_rect.xMaximum() - grappe_rect.xMinimum()
            if largeur > largeur_defaut:
                grappe_rect.setXMinimum(grappe_rect.xMinimum() - 1)
                grappe_rect.setXMaximum(grappe_rect.xMaximum() + 1)
                masque_dep.zoomToExtent(grappe_rect)
            else:
                marge = largeur_defaut - largeur
                if grappe_rect.xMinimum() - cadre_rect.xMinimum() < marge / 2:
                    marge_avant = grappe_rect.xMinimum() - cadre_rect.xMinimum() + 1
                    marge_apres = marge - marge_avant
                elif cadre_rect.xMaximum() - grappe_rect.xMaximum() < marge / 2:
                    marge_apres = cadre_rect.xMaximum() - grappe_rect.xMaximum() + 1
                    marge_avant = marge - marge_apres
                else:
                    marge_avant = marge / 2
                    marge_apres = marge / 2
                grappe_rect.setXMinimum(grappe_rect.xMinimum() - marge_avant)
                grappe_rect.setXMaximum(grappe_rect.xMaximum() + marge_apres)
                masque_dep.zoomToExtent(grappe_rect)
        else:
            cadre_rect.setXMinimum(cadre_rect.xMinimum() - 1)
            cadre_rect.setXMaximum(cadre_rect.xMaximum() + 1)
            cadre_rect.setYMinimum(cadre_rect.yMinimum() - 1)
            cadre_rect.setYMaximum(cadre_rect.yMaximum() + 1)
            masque_dep.zoomToExtent(cadre_rect)
        # On ajuste l'étendue de la carte alveole d'arrivee
        masque_dep = my_atlas.layout().itemById('masque_arr')
        t_cadre.selectByExpression(f"OA='{ltech_arrive}'")
        if t_cadre.selectedFeatureCount() == 0:
            t_cadre.selectByExpression(f"OA='Information manquante'")
        for cadre in t_cadre.selectedFeatures():
            cadre_rect = cadre.geometry().boundingBox()
        if cadre_rect.xMaximum() - cadre_rect.xMinimum() > largeur_defaut:
            # On corrige
            t_grappe.selectByExpression(f"OA_depart = '{ltech_arrive}' and OA_arrive = '{ltech_depart}'")
            for grappe in t_grappe.selectedFeatures():
                grappe_rect = grappe.geometry().boundingBox()
            largeur = grappe_rect.xMaximum() - grappe_rect.xMinimum()
            if largeur > largeur_defaut:
                grappe_rect.setXMinimum(grappe_rect.xMinimum() - 1)
                grappe_rect.setXMaximum(grappe_rect.xMaximum() + 1)
                masque_dep.zoomToExtent(grappe_rect)
            else:
                marge = largeur_defaut - largeur
                if grappe_rect.xMinimum() - cadre_rect.xMinimum() < marge / 2:
                    marge_avant = grappe_rect.xMinimum() - cadre_rect.xMinimum() + 1
                    marge_apres = marge - marge_avant
                elif cadre_rect.xMaximum() - grappe_rect.xMaximum() < marge / 2:
                    marge_apres = cadre_rect.xMaximum() - grappe_rect.xMaximum() + 1
                    marge_avant = marge - marge_apres
                else:
                    marge_avant = marge / 2
                    marge_apres = marge / 2
                grappe_rect.setXMinimum(grappe_rect.xMinimum() - marge_avant)
                grappe_rect.setXMaximum(grappe_rect.xMaximum() + marge_apres)
                masque_dep.zoomToExtent(grappe_rect)
        else:
            cadre_rect.setXMinimum(cadre_rect.xMinimum() - 1)
            cadre_rect.setXMaximum(cadre_rect.xMaximum() + 1)
            cadre_rect.setYMinimum(cadre_rect.yMinimum() - 1)
            cadre_rect.setYMaximum(cadre_rect.yMaximum() + 1)
            masque_dep.zoomToExtent(cadre_rect)
        # On va chercher les commentaires
        comment_arrive = ''
        t_grappe.selectByExpression(f"OA_depart = '{ltech_arrive}' and OA_arrive = '{ltech_depart}'")
        for grappe in t_grappe.selectedFeatures():
            comment_arrive = f"{grappe['comment'] or ''}\n{grappe['comment2'] or ''}\n{grappe['comment3'] or ''}\n{grappe['comment4'] or ''}"
        it_comment_arrive = my_atlas.layout().itemById('comment_arrive')
        it_comment_arrive.setText(comment_arrive)
        # On exporte la page
        if not os.path.exists(f"{outputs_folder}/{oa_depart}"):
            os.makedirs(f"{outputs_folder}/{oa_depart}")
        pdfpath = f"{outputs_folder}/{oa_depart}/{str(npage).zfill(2)}_{my_atlas.currentFilename()}.pdf"
        atlas_layout=my_atlas.layout()
        exporter = QgsLayoutExporter(atlas_layout)
        exporter.exportToPdf(pdfpath,exporter.PdfExportSettings())
        dict_pdf[oa_depart].append(pdfpath)
    my_atlas.endRender()
    ##################################################################################################################### 
    ##################################################################################################################### 
    if fichier_unique:
        # On finit avec le plan de masse si on exporte tout en un seul fichier
        # On commence par mettre à jour la couche OA avec les foliotages
        index = t_oa.fields().indexFromName('FOLIO')
        if index != -1:
            t_oa.startEditing()
            for key in dict_increm:
                f_depart = dict_increm.get(key)
                f_arrive = dict_increm.get(key) + dict_num_page.get(key, 0)
                t_oa.selectByExpression(f"ref = '{key}'")
                for oa in t_oa.selectedFeatures():
                    t_oa.changeAttributeValue(oa.id(), index, f"Folio {f_depart} à {f_arrive}")
            t_oa.commitChanges()
        # On lance l'atlas du plan masse
        lay = QgsProject.instance().layoutManager().layoutByName('02_Atlas_Masse')
        my_atlas = lay.atlas()
        my_atlas.setFilterExpression(f"grid='Masse' and OA = '{filtre_zone}'")
        my_atlas.beginRender()
        while my_atlas.next():
            # On met à jour le foliotage
            num_page = my_atlas.layout().itemById('num_page')
            num_page.setText(f"03/{str(nb_page_total).zfill(2)}")
            # On met à jour l'échelle
            it_carte_masse = my_atlas.layout().itemById('carte_masse')
            echelle = round(it_carte_masse.scale())
            it_echelle = my_atlas.layout().itemById('echelle')
            it_echelle.setText(f"1/{echelle}")
            # On exporte la page
            atlas_layout=my_atlas.layout()
            if not os.path.exists(f"{outputs_folder}/002_PdM"):
                os.makedirs(f"{outputs_folder}/002_PdM")
            pdfpath = f"{outputs_folder}/002_PdM/00_Plan de masse.pdf"                    
            exporter = QgsLayoutExporter(atlas_layout)
            exporter.exportToPdf(pdfpath,exporter.PdfExportSettings())
            dict_pdf['002_PdM'] = [pdfpath]
        my_atlas.endRender()

    # On fusionne les pdf
    if not fichier_unique:
        for oa in dict_pdf:
            merger = self.pypdf.PdfWriter()
            for pdf in dict_pdf[oa]:
                merger.append(pdf)
            pdfpath = f"{outputs_folder}/{oa}.pdf"    
            merger.write(pdfpath)
            merger.close()
            shutil.rmtree(f"{outputs_folder}/{oa}/")
    else:
        merger = self.pypdf.PdfWriter()
        for oa in dict_pdf:
            for pdf in dict_pdf[oa]:
                merger.append(pdf)
            try:
                shutil.rmtree(f"{outputs_folder}/{oa}/")
            except:
                pass
        pdfpath = f"{outputs_folder}/{filtre_zone}.pdf"    
        merger.write(pdfpath)
        merger.close()
        


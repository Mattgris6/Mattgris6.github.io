from qgis.core import  QgsProject, QgsLayoutExporter, QgsLayoutItemShape, QgsLayoutItemLabel, QgsLayoutSize, QgsUnitTypes, QgsLayoutPoint
from qgis.PyQt.QtGui import QFont, QColor
from qgis.PyQt.QtCore import Qt
import os

def lancement_synthese(self):
    outputs_folder = self.dlg.chemin_sauvegarde.filePath()
    # On récupère les couches utiles
    layers = QgsProject.instance().mapLayers().values()
    for l in layers:
        if l.name() == "lien":
            t_lien = l
        elif l.name() == "grid":
            t_grid = l
        elif l.name() == "OA_Enc copier":
            t_oa = l
    lay = QgsProject.instance().layoutManager().layoutByName('1_Synthèse')
    suppression = 1
    compteur = 0
    while suppression == 1 and compteur < 10000:
        compteur += 1
        item = lay.itemById(f'Barre{compteur}')
        try:
            lay.removeItem(item)
        except:
            suppression = 0
    y = 10
    incr = 1
    #forme = lay.layout().itemById('rectangle')
    # On sélectionne les liens de M1
    t_lien.selectByExpression(f"zone = '{self.dlg.filtre_zone.currentText()}' and catégorie = 'M1'")
    if t_lien.selectedFeatureCount() > 0:
        incr = create_label_titre(lay, " Liaisons M1", y, incr, QColor(56, 122, 193))
        y += 5
        incr, y = fonction_categorie(lay, t_lien, y, incr)
    # On sélectionne les liens de M2
    t_lien.selectByExpression(f"zone = '{self.dlg.filtre_zone.currentText()}' and catégorie = 'M2'")
    if t_lien.selectedFeatureCount() > 0:
        incr = create_label_titre(lay, " Liaisons M2", y, incr, QColor(76, 173, 169))
        y += 5
        incr, y = fonction_categorie(lay, t_lien, y, incr)
    # On sélectionne les liens de M3
    t_lien.selectByExpression(f"zone = '{self.dlg.filtre_zone.currentText()}' and catégorie = 'M3'")
    if t_lien.selectedFeatureCount() > 0:
        incr = create_label_titre(lay, " Liaisons M3", y, incr, QColor(219, 52, 219))
        y += 5
        incr, y = fonction_categorie(lay, t_lien, y, incr)
    # On sélectionne les liens de M3A
    t_lien.selectByExpression(f"zone = '{self.dlg.filtre_zone.currentText()}' and catégorie = 'M3A'")
    if t_lien.selectedFeatureCount() > 0:
        incr = create_label_titre(lay, " Liaisons M3A", y, incr, QColor(43, 152, 66))
        y += 5
        incr, y = fonction_categorie(lay, t_lien, y, incr)
    # On sélectionne les liens de M3B
    t_lien.selectByExpression(f"zone = '{self.dlg.filtre_zone.currentText()}' and catégorie = 'M3B'")
    if t_lien.selectedFeatureCount() > 0:
        incr = create_label_titre(lay, " Liaisons M3B", y, incr, QColor(255, 134, 2))
        y += 5
        incr, y = fonction_categorie(lay, t_lien, y, incr)
    # On sélectionne les liens de CFO
    t_lien.selectByExpression(f"zone = '{self.dlg.filtre_zone.currentText()}' and catégorie = 'CFO'")
    if t_lien.selectedFeatureCount() > 0:
        incr = create_label_titre(lay, " Liaisons CFO", y, incr, QColor(0, 0, 0))
        y += 5
        incr, y = fonction_categorie(lay, t_lien, y, incr)
    my_atlas = lay.atlas()
    # Pour les points, on corrige le filtre de la symbologie
    rule=t_oa.renderer().rootRule().children()[0]
    rule.setFilterExpression(f"regexp_match( aggregate('Ltech', 'concatenate_unique',OA,  zone ='{self.dlg.filtre_zone.currentText()}',' ; '), ref )")
    # On récupère l'emprise de l'encartage
    t_grid.selectByExpression(f"OA='{self.dlg.filtre_zone.currentText()}' and grid = 'Masse'")
    for grid in t_grid.selectedFeatures():
        grid_rect = grid.geometry().boundingBox()
    # On corrige l'emprise du schema
    carte_schema = my_atlas.layout().itemById('Plan de situation')
    carte_schema.zoomToExtent(grid_rect)
    my_atlas.setFilterExpression(f"grid='Schema_v' and OA = '{self.dlg.filtre_zone.currentText()}'")
    my_atlas.beginRender()
    while my_atlas.next():
        # On exporte la page
        atlas_layout=my_atlas.layout()
        pdfpath = f"{outputs_folder}/Synthese_{self.dlg.filtre_zone.currentText()}.pdf"                    
        exporter = QgsLayoutExporter(atlas_layout)
        export_settings = exporter.PdfExportSettings()
        export_settings.simplifyGeometries = False
        exporter.exportToPdf(pdfpath,export_settings)
    my_atlas.endRender()

def fonction_categorie(lay, t_lien, y, incr):
    sorted_list = sorted(t_lien.selectedFeatures(), key=lambda el: el['OA_dep'])
    couleur = QColor(242, 242, 242)
    for lien in sorted_list:
        x = 50
        total = (lien['nb_26-32'] or 0) + (lien['nb_33-40'] or 0)
        texte = f"{lien['OA_dep']} vers {lien['OA_arr']} - {round(lien['cm_long'])}m"
        incr = create_label(lay, texte, x, y, incr, couleur, 40, Qt.AlignLeft, 3)
        print(texte, total, lien['nb_26-32'], lien['nb_33-40'])
        x = 90
        if lien['nb_26-32'] or lien['nb_33-40']:
            hs = lien['HS_26-32'] + lien['HS_33-40']
            vinf = lien['V18_26-32'] + lien['V22_33-40']
            nc = lien['NC_26-32'] + lien['NC_33-40']
            f_ok = total - hs - nc - vinf
            incr = create_label(lay, f"{total} fourreaux", x, y, incr, couleur, 15, Qt.AlignLeft, 3)
            x += 15
            # Longueurs à prévoir
            l_f_ok = f_ok / total * 90
            l_hs = hs / total * 90
            l_vinf = vinf / total * 90
            l_nc = nc / total * 90
            # Pourcentages à afficher
            p_f_ok = f_ok / total * 100
            p_hs = hs / total * 100
            p_vinf = vinf / total * 100
            p_nc = nc / total * 100
            # ok
            incr = create_label(lay, f"{round(p_f_ok)}%", x, y, incr, QColor(0, 200, 50), l_f_ok, Qt.AlignCenter, 3)
            # vinf
            incr = create_label(lay, f"{round(p_vinf)}%", x + l_f_ok, y, incr, QColor(240, 209, 0), l_vinf, Qt.AlignCenter, 3)
            # nc
            incr = create_label(lay, f"{round(p_nc)}%", x + l_f_ok + l_vinf, y, incr, QColor(240, 143, 0), l_nc, Qt.AlignCenter, 3)
            # hs
            incr = create_label(lay, f"{round(p_hs)}%", x + l_f_ok + l_vinf + l_nc, y, incr, QColor(225, 0, 0), l_hs, Qt.AlignCenter, 3)
            if hs > 0:
                incr = create_label(lay, f"{hs} HS", x + l_f_ok + l_vinf + l_nc + l_hs, y, incr, QColor(255, 255, 255), 6, Qt.AlignCenter, 3)
        else:
            incr = create_label(lay, '', x, y, incr, couleur, 15, Qt.AlignCenter, 3)
            x += 15
            incr = create_label(lay, 'Lien non testé', x, y, incr, QColor(150, 150, 150), 90, Qt.AlignCenter, 3)
        y += 5
        if couleur == QColor(242, 242, 242):
            couleur = QColor(200, 200, 200)
        else:
            couleur = QColor(242, 242, 242)
    return incr, y


def create_label(lay, texte, x, y, incr, couleur, largeur, alignement, hauteur):
    label = QgsLayoutItemLabel(lay)
    label.setReferencePoint(3)
    label.setText(texte)
    label.setFont(QFont("Ms Shell Dlg 2", 5))
    if " HS" in texte:
        label.setFontColor(QColor(255, 0, 0))
    label.setHAlign(alignement)
    label.setVAlign(Qt.AlignCenter)
    label.setMinimumSize(QgsLayoutSize(largeur, hauteur, QgsUnitTypes.LayoutMillimeters))
    #label.setX(x)
    #label.setY(y + 330)
    label.attemptMove(QgsLayoutPoint(x, y+315))
    label.setBackgroundEnabled(True)
    label.setBackgroundColor(couleur)
    label.setId(f'Barre{incr}')
    lay.addLayoutItem(label)
    return incr + 1

def create_label_titre(lay, texte, y, incr, couleur):
    label = QgsLayoutItemLabel(lay)
    label.setReferencePoint(3)
    label.setText(texte)
    l_font = QFont("Ms Shell Dlg 2", 7)
    l_font.setBold(True)
    label.setFont(l_font)
    label.setFontColor(couleur)
    label.setHAlign(Qt.AlignCenter)
    label.setVAlign(Qt.AlignCenter)
    label.setMinimumSize(QgsLayoutSize(40, 5, QgsUnitTypes.LayoutMillimeters))
    #label.setX(x)
    #label.setY(y + 330)
    label.attemptMove(QgsLayoutPoint(50, y+315))
    label.setId(f'Barre{incr}')
    lay.addLayoutItem(label)
    return incr + 1

'''def create_rectangle(lay, largeur, x, y, incr):
    barre = QgsLayoutItemShape(lay)
    barre.setShapeType(1)
    barre.setMinimumSize(QgsLayoutSize(largeur, 3, QgsUnitTypes.LayoutMillimeters))
    barre.setX(x)
    barre.setY(y)
    #barre.setBackgroundEnabled(True)
    barre.setFrameStrokeColor(QColor(0, 200, 0))
    barre.setId(f'Barre{incr}')
    lay.addLayoutItem(barre)
    return barre'''